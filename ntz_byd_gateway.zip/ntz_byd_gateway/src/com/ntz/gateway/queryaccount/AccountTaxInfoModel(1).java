/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ntz.gateway.queryaccount;

/**
 *
 * @author NTZ_Admin
 */
public class AccountTaxInfoModel {
    public String system_id = "";
    public String customer_uuid = "";
    public String list_id = ""; //Normally Country Code
    public String tax_id = "";
    public String tax_type_code = "";
    
}
