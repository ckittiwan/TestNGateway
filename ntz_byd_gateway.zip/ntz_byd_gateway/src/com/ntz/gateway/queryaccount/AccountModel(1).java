/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ntz.gateway.queryaccount;

import java.util.ArrayList;

/**
 *
 * @author NTZ_Admin
 */
public class AccountModel {
    public String system_id = "";
    public String customer_uuid = "";
    public String customer_id = "";
    public String customer_name = "";
    public String customer_type = ""; //1 = Person, 2 = Company
    public String given_name = "";
    public String family_name = "";
    public String gender_code = "";
    public String birthdate = "";
   
    public String byd_gmt0_lastchange_datetime = "";
    
    
    public ArrayList<AccountAddressModel> address_list = new ArrayList();
    public ArrayList<AccountContactModel> contact_list = new ArrayList();
    public ArrayList<AccountTaxInfoModel> taxinfo_list = new ArrayList();
}
