/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ntz.gateway.queryaccount;

/**
 *
 * @author NTZ_Admin
 */
public class AccountContactModel {
    public String system_id = "";
    public String customer_uuid = "";
    public String contact_uuid = "";
    public String contact_id = "";
    public String default_indicator = "";
    public String given_name = "";
    public String family_name = "";
    public String gender_code = "";
    public String tel_no = "";
    public String address_line1 = "";
    public String address_line2 = "";
    public String address_line3 = "";
    public String address_line4 = "";
}
