/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ntz.gateway.queryaccount;

/**
 *
 * @author NTZ_Admin
 */
public class AccountAddressModel {
    public String system_id = "";
    public String customer_uuid = "";
    public String address_uuid =  "";
    public String country_code = "";
    public String city_name = "";
    public String additional_city_name = "";
    public String street_postal_code = "";
    public String street_name = "";
    public String street_prefix_name = "";
    public String additional_street_prefix_name = "";
    public String street_suffix_name = "";
    public String additional_street_suffix_name = "";
    public String address_line1 = "";
    public String address_line2 = "";
    public String address_line3 = "";
    public String address_line4 = "";
    public String house_id = "";
    public String email_uri = "";
    public String tel_no = "";
    public String fax_no = "";
    public String address_valid_from = "";
    public String address_valid_to = "";
    
    public String[] address_usage;
    
    
    
}   
