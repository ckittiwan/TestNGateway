/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ntz.gateway.queryaccount;

import com.google.gson.Gson;
import com.mysql.jdbc.PreparedStatement;
import com.ntz.byd.gateway.EmailSender;
import com.ntz.byd.gateway.ExternalRestCaller;
import com.ntz.byd.gateway.db.MySQLDB;
import com.ntz.byd.gateway.queryaccount.autogen.CustomerByElementsQueryMessageSync;
import com.ntz.byd.gateway.queryaccount.autogen.CustomerReponseCustomer;
import com.ntz.byd.gateway.queryaccount.autogen.CustomerReponseCustomerAddressInformation;
import com.ntz.byd.gateway.queryaccount.autogen.CustomerReponseCustomerContactPerson;
import com.ntz.byd.gateway.queryaccount.autogen.CustomerResponseMessageSync;
import com.ntz.byd.gateway.queryaccount.autogen.CustomerSelectionByElements;
import com.ntz.byd.gateway.queryaccount.autogen.QueryProcessingConditions;
import com.ntz.byd.gateway.queryaccount.autogen.StandardFaultMessage_Exception;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.TimeZone;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.ws.BindingProvider;

/**
 *
 * @author NTZ_Admin
 */
public class QueryAccountRunner implements Runnable {
    
    private Hashtable _systemht = null;
    private PreparedStatement insertAccountStmt = null;
    private PreparedStatement insertAccountAddressStmt = null;
    private PreparedStatement insertAccountAddressUsageStmt = null;
    private PreparedStatement insertAccountTaxInfoStmt = null;
    private PreparedStatement insertAccountContactStmt = null;
    
    public QueryAccountRunner(Hashtable hashtable) {
        _systemht = hashtable;
    }
    
    
    @Override
    public void run() { 
        MySQLDB db = null ;
        try 
        {
            String lastupdate = get_last_synz_datetime();
            /*System.out.println(lastupdate);
            Date curr_date = new Date();
            SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            df.setTimeZone(TimeZone.getTimeZone("GMT"));
            //System.out.println(df.format(curr_date));
            
            Date d = df.parse("2018-09-20 10:00:00");
            System.out.println(d);
            */
            SimpleDateFormat birthdate_format = new SimpleDateFormat("yyyy-MM-dd");
         
            CustomerByElementsQueryMessageSync requestMessage = composeQueryAccountMessage(lastupdate);
            CustomerResponseMessageSync resp = findByElements(requestMessage);
            
            ArrayList<AccountModel> account_list = new ArrayList();
            
            SimpleDateFormat df_gmt0 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            df_gmt0.setTimeZone(TimeZone.getTimeZone("GMT"));
            
            for(int i = 0 ; i  < resp.getCustomer().size(); i ++)
            {
                CustomerReponseCustomer cust = resp.getCustomer().get(i);
                AccountModel acctModel = new AccountModel();
                System.out.println("Customer ID : " +cust.getInternalID()+" , Last Update = " +  cust.getSystemAdministrativeData().getLastChangeDateTime().toGregorianCalendar().getTime());
                
                acctModel.system_id = (String) this._systemht.get("system_id");
                acctModel.customer_uuid = cust.getUUID().getValue();
                acctModel.customer_id = cust.getInternalID();
                if(cust.getOrganisation() != null)
                {
                    acctModel.customer_type = "2"; //company
                    acctModel.customer_name = cust.getOrganisation().getFirstLineName();
                }
                else
                {
                    acctModel.customer_type = "1"; //person
                    acctModel.given_name = cust.getPerson().getGivenName();
                    acctModel.family_name = cust.getPerson().getFamilyName();
                    acctModel.gender_code = cust.getPerson().getGenderCode();
                    if(cust.getPerson().getBirthDate() != null)
                        acctModel.birthdate = birthdate_format.format(cust.getPerson().getBirthDate().toGregorianCalendar().getTime());    
                }
                acctModel.byd_gmt0_lastchange_datetime = df_gmt0.format(cust.getSystemAdministrativeData().getLastChangeDateTime().toGregorianCalendar().getTime());
                
                
                
                //tax
                for(int j = 0 ; j < cust.getTaxNumber().size() ; j++)
                {
                    AccountTaxInfoModel taxinfo = new AccountTaxInfoModel();
                    taxinfo.system_id = (String) this._systemht.get("system_id");
                    taxinfo.customer_uuid = acctModel.customer_uuid ;
                    taxinfo.list_id = cust.getTaxNumber().get(j).getTaxIdentificationNumberTypeCode().getListID();
                    taxinfo.tax_type_code = cust.getTaxNumber().get(j).getTaxIdentificationNumberTypeCode().getValue();
                    taxinfo.tax_id  = cust.getTaxNumber().get(j).getPartyTaxID().getValue();
           
                    acctModel.taxinfo_list.add(taxinfo);
                }
                
                //address
                for(int j = 0 ; j < cust.getAddressInformation().size(); j++)
                {
                    CustomerReponseCustomerAddressInformation addr = cust.getAddressInformation().get(j);
                    AccountAddressModel addrModel = new AccountAddressModel();
                    addrModel.system_id = (String) this._systemht.get("system_id");
                    addrModel.customer_uuid = acctModel.customer_uuid ;
                    addrModel.address_uuid = addr.getUUID().getValue();
                    if(addr.getAddress().getPostalAddress() != null)
                    {
                        addrModel.country_code = addr.getAddress().getPostalAddress().getCountryCode();
                        addrModel.city_name = addr.getAddress().getPostalAddress().getCityName();
                        addrModel.additional_city_name =  addr.getAddress().getPostalAddress().getAdditionalCityName();
                        addrModel.street_postal_code = addr.getAddress().getPostalAddress().getStreetPostalCode();
                        addrModel.street_name = addr.getAddress().getPostalAddress().getStreetName();
                        addrModel.street_prefix_name = addr.getAddress().getPostalAddress().getStreetPrefixName();
                        addrModel.additional_street_prefix_name = addr.getAddress().getPostalAddress().getAdditionalStreetPrefixName();
                    
                        addrModel.street_suffix_name = addr.getAddress().getPostalAddress().getStreetSuffixName();
                        addrModel.additional_street_suffix_name =  addr.getAddress().getPostalAddress().getAdditionalStreetSuffixName();
                        addrModel.house_id = addr.getAddress().getPostalAddress().getHouseID();
                    }
                    
                    
                   
                    if(addr.getAddress().getEmailURI() != null)
                        addrModel.email_uri = addr.getAddress().getEmailURI().getValue();
                    
                    
                    addrModel.address_line1 = addr.getAddress().getFormattedAddress().getFormattedAddress().getFirstLineDescription();
                    addrModel.address_line2 = addr.getAddress().getFormattedAddress().getFormattedAddress().getSecondLineDescription();
                    addrModel.address_line3 = addr.getAddress().getFormattedAddress().getFormattedAddress().getThirdLineDescription();
                    addrModel.address_line4 = addr.getAddress().getFormattedAddress().getFormattedAddress().getFourthLineDescription();
                    
                    for(int k = 0; k < addr.getAddress().getTelephone().size(); k++)
                    {
                        if( addr.getAddress().getTelephone().get(k).isMobilePhoneNumberIndicator() != null  && addr.getAddress().getTelephone().get(k).isMobilePhoneNumberIndicator())
                        {
                            addrModel.tel_no =  addr.getAddress().getTelephone().get(k).getFormattedNumberDescription();
                        }
                        else
                        {
                            addrModel.fax_no = addr.getAddress().getTelephone().get(k).getFormattedNumberDescription();
                        }
                    }

                   addrModel.address_valid_from = birthdate_format.format(addr.getAddressInformationValidityPeriod().getStartDate().toGregorianCalendar().getTime());
                   addrModel.address_valid_to = birthdate_format.format(addr.getAddressInformationValidityPeriod().getEndDate().toGregorianCalendar().getTime());
                   
                   
                   //address usage
                   addrModel.address_usage = new String[addr.getAddressUsage().size()];
                   for(int k = 0 ;k < addr.getAddressUsage().size() ; k++)
                   {
                       addrModel.address_usage[k] =  addr.getAddressUsage().get(k).getAddressUsageCode().getValue();
                   }
                   
                   acctModel.address_list.add(addrModel);
                }
                
                
                
                
                //contact
                for(int j = 0 ; j < cust.getContactPerson().size() ; j++)
                {
                    CustomerReponseCustomerContactPerson contact = cust.getContactPerson().get(j);
                    AccountContactModel contModel = new AccountContactModel();
                    contModel.system_id = (String) this._systemht.get("system_id");
                    contModel.customer_uuid = acctModel.customer_uuid;
                    contModel.contact_uuid = contact.getBusinessPartnerContactUUID().getValue();
                    contModel.contact_id = contact.getBusinessPartnerContactInternalID();
                    contModel.given_name = contact.getGivenName();
                    contModel.family_name = contact.getFamilyName();
                    contModel.gender_code = contact.getGenderCode();
                    if(contact.getWorkplaceTelephone().size() > 0)
                    {
                         contModel.tel_no = contact.getWorkplaceTelephone().get(0).getFormattedNumberDescription();
                    }
                    
                    if(contact.isDefaultContactPersonIndicator() != null && contact.isDefaultContactPersonIndicator() )
                    {
                        contModel.default_indicator = "X";
                    }
                    
                    contModel.address_line1 = contact.getWorkplaceFormattedAddress().getFormattedAddress().getFirstLineDescription();
                    contModel.address_line2 = contact.getWorkplaceFormattedAddress().getFormattedAddress().getSecondLineDescription();
                    contModel.address_line3 = contact.getWorkplaceFormattedAddress().getFormattedAddress().getThirdLineDescription();
                    contModel.address_line4 = contact.getWorkplaceFormattedAddress().getFormattedAddress().getFourthLineDescription();
 
                    acctModel.contact_list.add(contModel);
                }
                account_list.add(acctModel);             
            }// End Extracting Data
            
            
            
            //Insert into database
            db = new MySQLDB();
            db.connect();
            String[] sql = getSQlTemplate();
            this.insertAccountStmt =  (PreparedStatement) db.conn.prepareStatement(sql[0]);
            this.insertAccountAddressStmt = (PreparedStatement) db.conn.prepareStatement(sql[1]);
            this.insertAccountAddressUsageStmt = (PreparedStatement) db.conn.prepareStatement(sql[2]);
            this.insertAccountContactStmt = (PreparedStatement) db.conn.prepareStatement(sql[3]);
            this.insertAccountTaxInfoStmt = (PreparedStatement) db.conn.prepareStatement(sql[4]);
            
            for(int i = 0 ; i < account_list.size() ; i++)
            {
                AccountModel acctModel = account_list.get(i);
                clearExistingData(acctModel);
                insertAccountStmt.setString(1, acctModel.system_id);
                insertAccountStmt.setString(2, acctModel.customer_uuid);
                insertAccountStmt.setString(3, acctModel.customer_id);
                insertAccountStmt.setString(4, acctModel.customer_name);
                insertAccountStmt.setString(5, acctModel.customer_type);
                insertAccountStmt.setString(6, acctModel.given_name);
                insertAccountStmt.setString(7, acctModel.family_name);
                insertAccountStmt.setString(8, acctModel.gender_code);
                insertAccountStmt.setString(9, acctModel.birthdate.equals("") ? null:acctModel.birthdate);
                insertAccountStmt.setString(10,"W");
                insertAccountStmt.setString(11, acctModel.byd_gmt0_lastchange_datetime);              
                insertAccountStmt.executeUpdate();
                
                for(int j = 0; j < acctModel.address_list.size() ; j++)
                {
                    AccountAddressModel addrModel = acctModel.address_list.get(j);
                    insertAccountAddressStmt.setString(1,addrModel.system_id);
                    insertAccountAddressStmt.setString(2,addrModel.customer_uuid);
                    insertAccountAddressStmt.setString(3,addrModel.address_uuid);
                    insertAccountAddressStmt.setString(4,addrModel.country_code);
                    insertAccountAddressStmt.setString(5,addrModel.city_name);
                    insertAccountAddressStmt.setString(6,addrModel.additional_city_name);
                    insertAccountAddressStmt.setString(7,addrModel.street_postal_code);
                    insertAccountAddressStmt.setString(8,addrModel.street_name);
                    insertAccountAddressStmt.setString(9,addrModel.street_prefix_name);
                    insertAccountAddressStmt.setString(10,addrModel.additional_street_prefix_name);
                    insertAccountAddressStmt.setString(11,addrModel.street_suffix_name);
                    insertAccountAddressStmt.setString(12,addrModel.additional_street_suffix_name);
                    insertAccountAddressStmt.setString(13,addrModel.house_id);
                    insertAccountAddressStmt.setString(14,addrModel.email_uri);
                    insertAccountAddressStmt.setString(15,addrModel.tel_no);
                    insertAccountAddressStmt.setString(16,addrModel.fax_no);
                    insertAccountAddressStmt.setString(17,addrModel.address_line1);
                    insertAccountAddressStmt.setString(18,addrModel.address_line2);
                    insertAccountAddressStmt.setString(19,addrModel.address_line3);
                    insertAccountAddressStmt.setString(20,addrModel.address_line4);
                    insertAccountAddressStmt.setString(21, addrModel.address_valid_from);
                    insertAccountAddressStmt.setString(22, addrModel.address_valid_to);
                    insertAccountAddressStmt.executeUpdate();   
                    for(int k = 0; k < addrModel.address_usage.length ; k++)
                    {
                        insertAccountAddressUsageStmt.setString(1,addrModel.system_id );
                        insertAccountAddressUsageStmt.setString(2,addrModel.customer_uuid );
                        insertAccountAddressUsageStmt.setString(3,addrModel.address_uuid );
                        insertAccountAddressUsageStmt.setString(4,  addrModel.address_usage[k]);                       
                        insertAccountAddressUsageStmt.executeUpdate();
                    }
                }
                
                
                for(int j = 0 ; j < acctModel.contact_list.size() ; j++)
                {
                    AccountContactModel contModel = acctModel.contact_list.get(j);
                    insertAccountContactStmt.setString(1, contModel.system_id);
                    insertAccountContactStmt.setString(2, contModel.customer_uuid);
                    insertAccountContactStmt.setString(3, contModel.contact_uuid);
                    insertAccountContactStmt.setString(4, contModel.contact_id);
                    insertAccountContactStmt.setString(5, contModel.default_indicator);
                    insertAccountContactStmt.setString(6, contModel.given_name);
                    insertAccountContactStmt.setString(7, contModel.family_name);
                    insertAccountContactStmt.setString(8, contModel.gender_code);
                    insertAccountContactStmt.setString(9, contModel.tel_no);
                    insertAccountContactStmt.setString(10, contModel.address_line1);
                    insertAccountContactStmt.setString(11, contModel.address_line2);
                    insertAccountContactStmt.setString(12, contModel.address_line3);
                    insertAccountContactStmt.setString(13, contModel.address_line4);
                    insertAccountContactStmt.executeUpdate();
                }
                
                
                for(int j =0 ; j < acctModel.taxinfo_list.size() ; j++)
                {
                    AccountTaxInfoModel taxModel = acctModel.taxinfo_list.get(j);
                    insertAccountTaxInfoStmt.setString(1, taxModel.system_id);
                    insertAccountTaxInfoStmt.setString(2, taxModel.customer_uuid);
                    insertAccountTaxInfoStmt.setString(3, taxModel.list_id);
                    insertAccountTaxInfoStmt.setString(4, taxModel.tax_id);
                    insertAccountTaxInfoStmt.setString(5, taxModel.tax_type_code);
                    insertAccountTaxInfoStmt.executeUpdate();
                }
            }//End insert Account
            
            
            
            //Send to External system
            send_to_external_system();
            
            
            
        } 
        catch (Exception ex) 
        {
            StringWriter sw = new StringWriter();
            ex.printStackTrace(new PrintWriter(sw));
            String exceptionAsString = sw.toString();
            System.out.println(exceptionAsString);
            
            EmailSender.sendFromGMail("nGateway Error - Query Account", exceptionAsString);
            Logger.getLogger(QueryAccountRunner.class.getName()).log(Level.SEVERE, null, ex);
        }
        finally
        {
            if(db != null) db.disconnect();
        }
    }
    
    
    private String get_last_synz_datetime() throws Exception
    {
        String ret = "";
        String sql = "select DATE_FORMAT(IFNULL(DATE_ADD(MAX(byd_gmt0_lastchange_datetime), INTERVAL 1 SECOND),STR_TO_DATE('01/01/2000', '%d/%m/%Y')),'%Y-%m-%dT%H:%i:%sZ') as xc from t_account where system_id = ? ";
        MySQLDB db = new MySQLDB();
        db.connect();
        db.createPrepareStatement(sql);
        db.bindValue(1, (String) this._systemht.get("system_id"));
        
        ResultSet res = db.executeQuery();
        ArrayList<Hashtable<String, String>> list = db.buildList(res);
        
        if(list.size() == 0)
        {
            ret = "";
        }
        else
        {
            ret = list.get(0).get("xc");
        }
        
        db.disconnect();
        return ret;
    }

    private  CustomerResponseMessageSync findByElements(com.ntz.byd.gateway.queryaccount.autogen.CustomerByElementsQueryMessageSync customerByElementsQuerySync) throws StandardFaultMessage_Exception {
        com.ntz.byd.gateway.queryaccount.autogen.Service service = new com.ntz.byd.gateway.queryaccount.autogen.Service();
        com.ntz.byd.gateway.queryaccount.autogen.QueryCustomerIn port = service.getBinding();
        BindingProvider provider = (BindingProvider) port;
        provider.getRequestContext().put(BindingProvider.USERNAME_PROPERTY, this._systemht.get("system_ws_username"));
        provider.getRequestContext().put(BindingProvider.PASSWORD_PROPERTY, this._systemht.get("system_ws_password"));
        provider.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, this._systemht.get("system_url").toString() + this._systemht.get("service_url_path").toString());
        return port.findByElements(customerByElementsQuerySync);
    }

    private com.ntz.byd.gateway.queryaccount.autogen.CustomerByElementsQueryMessageSync composeQueryAccountMessage(String lastupdate) throws DatatypeConfigurationException {
      com.ntz.byd.gateway.queryaccount.autogen.CustomerByElementsQueryMessageSync request = new com.ntz.byd.gateway.queryaccount.autogen.CustomerByElementsQueryMessageSync();
      request.setCustomerSelectionByElements(new CustomerSelectionByElements());
      request.getCustomerSelectionByElements().setSelectionByLastChangeSinceDateTime(DatatypeFactory.newInstance().newXMLGregorianCalendar(lastupdate));
      
      request.setProcessingConditions(new QueryProcessingConditions());
      request.getProcessingConditions().setQueryHitsMaximumNumberValue(Integer.valueOf(0));
      request.getProcessingConditions().setQueryHitsUnlimitedIndicator(true);
      
      
      return request;
    }
    
    private void clearExistingData(AccountModel acctModel) throws SQLException {
        
        String sql = "delete from t_account where system_id = '"+acctModel.system_id+"' AND customer_uuid = '"+acctModel.customer_uuid+"'";
        String sql1 = "delete from t_account_contact where system_id = '"+acctModel.system_id+"' AND customer_uuid = '"+acctModel.customer_uuid+"'";
        String sql2 = "delete from t_account_address where system_id = '"+acctModel.system_id+"' AND customer_uuid = '"+acctModel.customer_uuid+"'";
        String sql3 = "delete from t_account_tax_info where system_id = '"+acctModel.system_id+"' AND customer_uuid = '"+acctModel.customer_uuid+"'";
        String sql4 = "delete from t_account_address_usage where system_id = '"+acctModel.system_id+"' AND customer_uuid = '"+acctModel.customer_uuid+"'";
        
        MySQLDB db = new MySQLDB();
        db.connect();
        Statement createStatement = db.conn.createStatement();
        createStatement.execute(sql);
        createStatement.execute(sql1);
        createStatement.execute(sql2);
        createStatement.execute(sql3);
        createStatement.execute(sql4);
        
        createStatement.close();
        
        db.disconnect();
        
    }
    
    
    //0 = account
    //1 = account address
    //2 = account address usage
    //3 = account contact
    //4 = account tax info
    private String[] getSQlTemplate()
    {
        StringBuilder sb  = new StringBuilder();
        sb.append("INSERT INTO t_account(");
        sb.append("system_id,");   //1
        sb.append("customer_uuid,");//2
        sb.append("customer_id,");//3
        sb.append("customer_name,");//4
        sb.append("customer_type,");//5
        sb.append("given_name,");//6
        sb.append("family_name,");//7
        sb.append("gender_code,");//8
        sb.append("birthdate,");//9
        sb.append("external_interface_status,");//10
        sb.append("byd_gmt0_lastchange_datetime,");//11
        sb.append("create_datetime)");//12
        sb.append("VALUES(?,?,?,?,?,?,?,?,?,?,?,NOW())");
        
        
        
        StringBuilder sb1  = new StringBuilder();
        sb1.append("INSERT INTO t_account_address(");
        sb1.append("system_id,");  //1
        sb1.append("customer_uuid,"); //2
        sb1.append("address_uuid,");//3
        sb1.append("country_code,");//4
        sb1.append("city_name,");//5
        sb1.append("additional_city_name,");//6
        sb1.append("street_postal_code,");//7
        sb1.append("street_name,");//8
        sb1.append("street_prefix_name,"); //9
        sb1.append("additional_street_prefix_name,"); //10
        sb1.append("street_suffix_name,");// 11
        sb1.append("additional_street_suffix_name,"); //12
        sb1.append("house_id,"); //13
        sb1.append("email_uri,"); //14
        sb1.append("tel_no,");//15
        sb1.append("fax_no,");//16
        sb1.append("address_line1,"); //17
        sb1.append("address_line2,"); //18
        sb1.append("address_line3,"); //19
        sb1.append("address_line4,"); //20
        sb1.append("address_valid_from,"); //21
        sb1.append("address_valid_to)"); //22
        sb1.append("VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
        
        
        StringBuilder sb2  = new StringBuilder();
        sb2.append("INSERT INTO t_account_address_usage(");
        sb2.append("system_id,"); //1
        sb2.append("customer_uuid,");//2
        sb2.append("address_uuid,");//3
        sb2.append("usage_code)");//4
        sb2.append("VALUES(?,?,?,?)");
        
        
        
        StringBuilder sb3  = new StringBuilder();
        sb3.append("INSERT INTO t_account_contact(");
        sb3.append("system_id,"); //1
        sb3.append("customer_uuid,");//2
        sb3.append("contact_uuid,");//3
        sb3.append("contact_id,");//4
        sb3.append("default_indicator,"); //5
        sb3.append("given_name,");//6
        sb3.append("family_name,");//7
        sb3.append("gender_code,");//8
        sb3.append("tel_no,");//9
        sb3.append("address_line1,"); //10
        sb3.append("address_line2,");//11
        sb3.append("address_line3,");//12
        sb3.append("address_line4)");//13
        sb3.append("VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)");
        
        
        StringBuilder sb4  = new StringBuilder();
        sb4.append("INSERT INTO t_account_tax_info(");
        sb4.append("system_id,");//1
        sb4.append("customer_uuid,"); //2
        sb4.append("list_id,");//3
        sb4.append("tax_id,");//4
        sb4.append("tax_type_code)"); //5
        sb4.append("VALUES(?,?,?,?,?)");
        
        
        return new String[]{sb.toString(),sb1.toString(),sb2.toString(),sb3.toString(),sb4.toString()};
    }

    
    //================================================= START SEND TO EXTERNAL SYSTEM
    private void send_to_external_system() throws Exception {
        if( this._systemht.get("callback_url").toString().equals(""))
        {
            return;
        }
        
        
        MySQLDB db = new MySQLDB();
        db.connect();
        String sql = "select t1.*,t2.description as gender_desc from t_account t1 LEFT OUTER JOIN m_gender_code t2 ON t1.gender_code = t2.code  where t1.system_id = ? AND t1.external_interface_status in ('W','E')";
        db.createPrepareStatement(sql);
        db.bindValue(1,  this._systemht.get("system_id").toString());
        ResultSet res = db.executeQuery();
        ArrayList account_list = db.buildList(res);
        db.disconnect();
        
        if(account_list.size() == 0)
        {
            return;
        }
        
        
        ArrayList json_accounts = new ArrayList();
        for(int i = 0; i < account_list.size() ; i++)
        {
            Hashtable ht = (Hashtable) account_list.get(i);
            HashMap hm = new HashMap();
            hm.put("customer_uuid",ht.get("customer_uuid"));
            hm.put("customer_id",ht.get("customer_id"));
            hm.put("customer_name",ht.get("customer_name"));
            hm.put("customer_type",ht.get("customer_type"));
            hm.put("given_name",ht.get("given_name"));
            hm.put("family_name",ht.get("family_name"));
            hm.put("gender",ht.get("gender_desc"));
            hm.put("birthdate",ht.get("birthdate"));
            hm.put("byd_gmt0_lastchanfe_datetime",ht.get("byd_gmt0_lastchange_datetime"));
            hm.put("contacts", getContactList((String) ht.get("customer_uuid")));
            hm.put("tax_infos", getTaxInfoList((String) ht.get("customer_uuid")));
            hm.put("addresses", getAddressList((String) ht.get("customer_uuid")));
            
            
            json_accounts.add(hm);
        }
        
        
        
        Gson gson = new Gson();
        String dataSent = gson.toJson(json_accounts);
        System.out.println(dataSent);
       
        String results[] = null;
      
        results =  ExternalRestCaller.call(
                (String) this._systemht.get("callback_url"), 
                (String) this._systemht.get("callback_apikey"), 
                (String) this._systemht.get("callback_username"), 
                (String) this._systemht.get("callback_password"), 
                ExternalRestCaller.METHOD_POST, 
                dataSent);
      
      
       
       if(results[0].equals("200"))//OK
       {
           update_external_callback_status(account_list,"S");
       }
       else //Fail
       {
           update_external_callback_status(account_list,"E");
       }
      
        
    }
    private ArrayList getContactList(String customer_uuid) throws Exception {
       
        String sql = "select t1.contact_uuid,t1.contact_id,t1.default_indicator,t1.given_name,t1.family_name,t1.gender_code,t2.description as gender,t1.tel_no,t1.address_line1,t1.address_line2,t1.address_line3,t1.address_line4 from t_account_contact t1 LEFT JOIN m_gender_code t2 ON t1.gender_code = t2.code where t1.system_id = ? AND t1.customer_uuid = ? ";
        MySQLDB db = new MySQLDB(); 
        db.connect();
        db.createPrepareStatement(sql);
        db.bindValue(1, this._systemht.get("system_id").toString());
        db.bindValue(2, customer_uuid);
        ResultSet res = db.executeQuery();
        
        ArrayList list = db.buildList(res);
        db.disconnect();
        
        
        return list;
    }
    
    private ArrayList getTaxInfoList(String customer_uuid) throws Exception {
        String sql = "select t1.list_id,t1.tax_id,t1.tax_type_code from t_account_tax_info t1 where t1.system_id = ? AND t1.customer_uuid = ? ";
        MySQLDB db = new MySQLDB(); 
        db.connect();
        db.createPrepareStatement(sql);
        db.bindValue(1, this._systemht.get("system_id").toString());
        db.bindValue(2, customer_uuid);
        ResultSet res = db.executeQuery();
        
        ArrayList list = db.buildList(res);
        db.disconnect();
        
        
        return list;
    }
   

    private ArrayList getAddressList(String customer_uuid) throws Exception {
        String sql = "select t1.address_uuid,"
                + "t1.country_code,"
                + "t1.city_name,"
                + "t1.additional_city_name,"
                + "t1.street_postal_code,"
                + "t1.street_name,"
                + "t1.street_prefix_name,"
                + "t1.street_suffix_name,"
                + "t1.additional_street_prefix_name,"
                + "t1.additional_street_suffix_name,"
                + "t1.house_id,"
                + "t1.email_uri,"
                + "t1.tel_no,"
                + "t1.fax_no,"
                + "t1.address_line1,"
                + "t1.address_line2,"
                + "t1.address_line3,"
                + "t1.address_line4,"
                + "t1.address_valid_from,"
                + "t1.address_valid_to "
                + "from t_account_address t1 where t1.system_id = ? AND t1.customer_uuid = ? ";
        MySQLDB db = new MySQLDB(); 
        db.connect();
        db.createPrepareStatement(sql);
        db.bindValue(1, this._systemht.get("system_id").toString());
        db.bindValue(2, customer_uuid);
        ResultSet res = db.executeQuery();
        
        ArrayList list = db.buildList(res);
        db.disconnect();
        
        for(int i = 0 ; i < list.size(); i++)
        {
            Hashtable ht = (Hashtable) list.get(i);
            ht.put("usages", getAddressUsageList(customer_uuid, (String) ht.get("address_uuid")));
        }
        return list;
    }
    
    
    
    private ArrayList getAddressUsageList(String customer_uuid, String address_uuid) throws Exception {
        String sql = "select t1.usage_code,t2.description as usage_desc from t_account_address_usage t1 LEFT OUTER JOIN m_address_usage_code t2 ON t1.usage_code = t2.code where t1.system_id = ? AND t1.customer_uuid = ? AND t1.address_uuid = ?";
        MySQLDB db = new MySQLDB(); 
        db.connect();
        db.createPrepareStatement(sql);
        db.bindValue(1, this._systemht.get("system_id").toString());
        db.bindValue(2, customer_uuid);
        db.bindValue(3, address_uuid);
        ResultSet res = db.executeQuery();
        
        ArrayList list = db.buildList(res);
        db.disconnect();
        
        
        return list;
    }
    
    
    
    private void update_external_callback_status(ArrayList<Hashtable<String, String>> account_list, String status) throws Exception {
       String sql = "update t_account set external_interface_status = ? , external_interface_datetime = NOW() where system_id = ? and customer_uuid = ?";
       
       MySQLDB db = new MySQLDB();
       db.connect();
       db.createPrepareStatement(sql);
       db.bindValue(1, status);
       db.bindValue(2, this._systemht.get("system_id").toString());
       for(int i = 0 ; i < account_list.size(); i++)
       {
           db.bindValue(3, account_list.get(i).get("customer_uuid"));
           db.executeUpdate();
       }
       
       db.disconnect();
    }
    //================================================= END SEND TO EXTERNAL SYSTEM

   
}
