/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ntz.system.monitor;

import com.ntz.byd.gateway.ExternalRestCaller;
import com.ntz.byd.gateway.db.MySQLDB;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.MalformedURLException;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author NTZ_Admin
 */
public class SystemMon {

    public static void _start() throws Exception 
    {
        ArrayList<Hashtable<String, String>> tenant_list = get_availabel_mon_system();
        //System.out.println(tenant_list);
        for(int i = 0 ; i < tenant_list.size() ; i++)
        {
            final Hashtable<String, String> ht = tenant_list.get(i);
            Runnable runn = new Runnable(){
                @Override
                public void run() {
                    String resp_code = "0";
                    String resp_msg = "";
                    long start = System.currentTimeMillis();
                    long end  = 0;
                    try
                    {
                        String url = ht.get("mon_url").equals("") ? ht.get("system_url") :  ht.get("mon_url");
                        String[] resp = ExternalRestCaller.call(url, "", "", "", ExternalRestCaller.METHOD_GET, null);
                        resp_code = resp[0];
                    }
                    catch(MalformedURLException e) 
                    {
                        StringWriter sw = new StringWriter();
                        e.printStackTrace(new PrintWriter(sw));
                        resp_msg = sw.toString();

                        //System.out.println(e.getCause());
                    }
                    catch(IOException e)
                    {
                        StringWriter sw = new StringWriter();
                        e.printStackTrace(new PrintWriter(sw));
                        resp_msg = sw.toString();
                        //System.out.println();
                    }
                    finally
                    {
                        try  
                        {
                            end = System.currentTimeMillis();
                            update_status_log(resp_code, resp_msg, end - start ,ht );
                        } 
                        catch (Exception ex) 
                        {
                            Logger.getLogger(SystemMon.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    }
                }
            };
            
            new Thread(runn).start();
  
        }
    }
    
    private static void update_status_log(String resp_code, String resp_msg, long duration,  Hashtable<String, String> ht) throws Exception {
        String sql = "INSERT INTO t_system_monitor_log(mon_id, mlog_resp_status_message, mlog_resp_status_code, mlog_resp_duration, created_datetime)values(?,?,?,?,NOW())";
        MySQLDB db = new MySQLDB();     
        db.connect();
        db.createPrepareStatement(sql);
        db.bindValue(1, ht.get("mon_id"));
        db.bindValue(2, resp_msg);
        db.bindValue(3, resp_code);
        db.bindValue(4, duration);
        db.executeUpdate();
        
        db.disconnect();
    }
    
    private static ArrayList get_availabel_mon_system() throws Exception
    {
        String sql = "select t1.*,t2.system_url from m_system_monitoring t1"
                + " LEFT JOIN m_sap_byd_system t2 ON t1.system_id = t2.system_id"
                + " where t1.mon_status = 'Y'";
        MySQLDB db = new MySQLDB();
        db.connect();
        db.createPrepareStatement(sql);
        ResultSet res = db.executeQuery();
        
        ArrayList list = db.buildList(res);  
        db.disconnect();
        return list;
    }
    
}
