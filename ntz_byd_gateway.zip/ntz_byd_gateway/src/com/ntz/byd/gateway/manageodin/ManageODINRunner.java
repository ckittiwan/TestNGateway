/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ntz.byd.gateway.manageodin;

import com.google.gson.Gson;
import com.ntz.byd.gateway.EmailSender;
import com.ntz.byd.gateway.ExternalRestCaller;
import com.ntz.byd.gateway.db.MySQLDB;
import com.ntz.byd.gateway.queryoutbounddelivery.manage.autogen.BusinessDocumentBasicMessageHeader;
import com.ntz.byd.gateway.queryoutbounddelivery.manage.autogen.CopyOfCopyOutboundDeliveryUpdateRequest;
import com.ntz.byd.gateway.queryoutbounddelivery.manage.autogen.CopyOfOutboundDeliveryReleaseRequest;
import com.ntz.byd.gateway.queryoutbounddelivery.manage.autogen.CopyOfOutboundDeliveryReleaseRequestMessageSync;
import com.ntz.byd.gateway.queryoutbounddelivery.manage.autogen.LOCALNORMALISEDDateTime;
import com.ntz.byd.gateway.queryoutbounddelivery.manage.autogen.LogItem;
import com.ntz.byd.gateway.queryoutbounddelivery.manage.autogen.ODUpdateRequestMessageSync;
import com.ntz.byd.gateway.queryoutbounddelivery.manage.autogen.ODUpdateResponseMessageSync;
import com.ntz.byd.gateway.queryoutbounddelivery.manage.autogen.OutboundDeliveryUpdateRequestArrivalPeriod;
import com.ntz.byd.gateway.queryoutbounddelivery.manage.autogen.OutboundDeliveryUpdateRequestShippingPeriod;
import com.ntz.byd.gateway.queryoutbounddelivery.manage.autogen.StandardFaultMessage_Exception;
import com.ntz.byd.gateway.queryoutbounddelivery.manage.autogen.UPPEROPENLOCALNORMALISEDDateTimePeriod;
import com.ntz.byd.gateway.queryoutbounddelivery.manage.autogen.UUID;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.ws.BindingProvider;

/**
 *
 * @author NTZ_Admin
 */
public class ManageODINRunner implements Runnable {

    
    private Hashtable<String, String> systemht = null;
    public ManageODINRunner(Hashtable hashtable) {
       systemht = hashtable;
    }

   
    public void run() {
        ArrayList<Hashtable<String, String>> list_release = null;
        try 
        {
            list_release  = get_release_request_list();
            for(int i = 0; i < list_release.size() ; i++)
            {
                //Update Shipping Date, Arrival Date
                String sap_interface_status = "S";
                String sap_interface_error_msg = "";
                String external_interface_status = "N";
                try
                {
                    com.ntz.byd.gateway.queryoutbounddelivery.manage.autogen.ODUpdateRequestMessageSync request_update = composeUpdateMessage(list_release.get(i));
                    ODUpdateResponseMessageSync call_update_response = call_update(request_update);
                    if(call_update_response.getLog().getMaximumLogItemSeverityCode() != null && call_update_response.getLog().getMaximumLogItemSeverityCode().equals("3"))
                    {
                        sap_interface_status = "E";
                        external_interface_status = "W";
                        List<LogItem> log_item = call_update_response.getLog().getItem();
                        for(int j = 0 ; j < log_item.size() ; j++)
                        {
                            if(!sap_interface_error_msg.equals(""))
                                sap_interface_error_msg += ", ";

                            sap_interface_error_msg += log_item.get(j).getNote();
                        }

                        continue;
                    }
                    //Release Delivery Order 
                    com.ntz.byd.gateway.queryoutbounddelivery.manage.autogen.CopyOfOutboundDeliveryReleaseRequestMessageSync request_release = composeReleaseMessage(list_release.get(i));
                    ODUpdateResponseMessageSync call_release_response = call_release(request_release);
                    if(call_release_response.getLog().getMaximumLogItemSeverityCode() != null && call_release_response.getLog().getMaximumLogItemSeverityCode().equals("3"))
                    {
                        sap_interface_status = "E";
                        external_interface_status = "W";
                        List<LogItem> log_item = call_release_response.getLog().getItem(); 
                        for(int j = 0 ; j < log_item.size() ; j++)
                        {
                            if(!sap_interface_error_msg.equals(""))
                                sap_interface_error_msg += ", ";

                            sap_interface_error_msg += log_item.get(j).getNote();
                        }
                    }

                } 
                catch (DatatypeConfigurationException ex) 
                {
                    sap_interface_status = "E";
                    external_interface_status = "W";
                    if(!sap_interface_error_msg.equals(""))
                        sap_interface_error_msg += ex.getMessage();
                    Logger.getLogger(ManageODINRunner.class.getName()).log(Level.SEVERE, null, ex);
                } 
                catch (StandardFaultMessage_Exception ex) 
                {
                    sap_interface_status = "E";
                    external_interface_status = "W";
                    if(!sap_interface_error_msg.equals(""))
                        sap_interface_error_msg += ex.getFaultInfo().getStandard().getFaultText();
                    Logger.getLogger(ManageODINRunner.class.getName()).log(Level.SEVERE, null, ex);
                }
                finally
                {
                    //do update interface status
                    update_release_confirmation_status(sap_interface_status,external_interface_status,sap_interface_error_msg,list_release.get(i).get("doc_id") );
                }
   
            }
            
            
        
        } 
        catch (Exception ex) 
        {
            StringWriter sw = new StringWriter();
            ex.printStackTrace(new PrintWriter(sw));
            String exceptionAsString = sw.toString();
            System.out.println(exceptionAsString);
            
            EmailSender.sendFromGMail("nGateway Error - Manage OD In", exceptionAsString);
            Logger.getLogger(ManageODINRunner.class.getName()).log(Level.SEVERE, null, ex);
        } 
        
        
        
        
        try 
        {
            //send to external system
            send_to_callback_external_system();
        }
        catch (Exception ex) {
            Logger.getLogger(ManageODINRunner.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    
    
    private ArrayList get_release_request_list() throws Exception
    {
        String sql = "select t1.*, t2.delivery_order_uuid,DATE_FORMAT(t1.gmt0_shipping_datetime,'%Y-%m-%dT%H:%i:%sZ')  as gmt0_shipping_datetime2 ,DATE_FORMAT(t1.gmt0_arrival_datetime,'%Y-%m-%dT%H:%i:%sZ')  as gmt0_arrival_datetime2  from t_delivery_order_release_confirmation t1 "
                + " INNER JOIN t_delivery_order t2 ON t1.system_id = t2.system_id AND t1.delivery_order_id = t2.delivery_order_id "
                + " where t1.system_id = ? "
                + " AND t1.sap_interface_status = 'W' ";
        
        MySQLDB db = new MySQLDB();
        db.connect();
        db.createPrepareStatement(sql);
        db.bindValue(1, this.systemht.get("system_id"));
        
        ResultSet res = db.executeQuery();
        ArrayList list = db.buildList(res);
        db.disconnect();
        
        
        return list;
    }
    
    
    private ODUpdateRequestMessageSync composeUpdateMessage(Hashtable<String, String> ht) throws DatatypeConfigurationException 
    {
       ODUpdateRequestMessageSync request = new ODUpdateRequestMessageSync();
       request.setBasicMessageHeader(new BusinessDocumentBasicMessageHeader());
       
       
       CopyOfCopyOutboundDeliveryUpdateRequest ob = new CopyOfCopyOutboundDeliveryUpdateRequest();
       request.getOutboundDelivery().add(ob);
       
       ob.setUUID(new UUID());
       ob.getUUID().setValue(ht.get("delivery_order_uuid"));
       
       
       
       ob.setArrivalPeriod(new OutboundDeliveryUpdateRequestArrivalPeriod());
       ob.getArrivalPeriod().setDateTimePeriod(new UPPEROPENLOCALNORMALISEDDateTimePeriod());
       ob.getArrivalPeriod().getDateTimePeriod().setStartDateTime(new LOCALNORMALISEDDateTime());
       ob.getArrivalPeriod().getDateTimePeriod().getStartDateTime().setTimeZoneCode(ht.get("timezone_code"));
       ob.getArrivalPeriod().getDateTimePeriod().getStartDateTime().setValue(DatatypeFactory.newInstance().newXMLGregorianCalendar(ht.get("gmt0_arrival_datetime2")));     
       ob.getArrivalPeriod().getDateTimePeriod().setEndDateTime(new LOCALNORMALISEDDateTime());
       ob.getArrivalPeriod().getDateTimePeriod().getEndDateTime().setTimeZoneCode(ht.get("timezone_code"));
       ob.getArrivalPeriod().getDateTimePeriod().getEndDateTime().setValue(DatatypeFactory.newInstance().newXMLGregorianCalendar(ht.get("gmt0_arrival_datetime2")));
       
       
       ob.setShippingPeriod(new OutboundDeliveryUpdateRequestShippingPeriod());
       ob.getShippingPeriod().setDateTimePeriod(new UPPEROPENLOCALNORMALISEDDateTimePeriod());
       ob.getShippingPeriod().getDateTimePeriod().setStartDateTime(new LOCALNORMALISEDDateTime());
       ob.getShippingPeriod().getDateTimePeriod().getStartDateTime().setTimeZoneCode(ht.get("timezone_code"));
       ob.getShippingPeriod().getDateTimePeriod().getStartDateTime().setValue(DatatypeFactory.newInstance().newXMLGregorianCalendar(ht.get("gmt0_shipping_datetime2")));
       ob.getShippingPeriod().getDateTimePeriod().setEndDateTime(new LOCALNORMALISEDDateTime());
       ob.getShippingPeriod().getDateTimePeriod().getEndDateTime().setTimeZoneCode(ht.get("timezone_code"));
       ob.getShippingPeriod().getDateTimePeriod().getEndDateTime().setValue(DatatypeFactory.newInstance().newXMLGregorianCalendar(ht.get("gmt0_shipping_datetime2")));
       
       return request;
       
    }
    
    private CopyOfOutboundDeliveryReleaseRequestMessageSync composeReleaseMessage(Hashtable<String, String> ht) {
        CopyOfOutboundDeliveryReleaseRequestMessageSync request = new CopyOfOutboundDeliveryReleaseRequestMessageSync();
        request.setBasicMessageHeader(new BusinessDocumentBasicMessageHeader());
        CopyOfOutboundDeliveryReleaseRequest ob = new CopyOfOutboundDeliveryReleaseRequest();
        request.getOutboundDelivery().add(ob);

        ob.setUUID(new UUID());
        ob.getUUID().setValue(ht.get("delivery_order_uuid"));
        
        
        
        
        return request;
    }
    
    
    private void update_release_confirmation_status(String sap_interface_status, String external_interface_status, String sap_interface_error_msg, String doc_id) throws Exception 
    {
        String sql = "update t_delivery_order_release_confirmation set sap_interface_status = ? , external_interface_status = ? , sap_interface_error_msg = ? where doc_id = ? AND system_id = ? ";
        MySQLDB db = new MySQLDB();
        db.connect();
        db.createPrepareStatement(sql);
        db.bindValue(1, sap_interface_status);
        db.bindValue(2, external_interface_status);
        db.bindValue(3, sap_interface_error_msg);
        db.bindValue(4, doc_id);
        db.bindValue(5, this.systemht.get("system_id"));
        db.executeUpdate();
        db.disconnect(); 
    }

    private void send_to_callback_external_system() throws Exception 
    {
       if(this.systemht.get("callback_url").equals(""))
       {
           return;
       }
        String sql = "select * from t_delivery_order_release_confirmation where system_id = ? AND external_interface_status in ('W','E')";
        MySQLDB db = new MySQLDB();
        db.connect();
        db.createPrepareStatement(sql);
        db.bindValue(1, this.systemht.get("system_id"));
        ResultSet res = db.executeQuery();
        ArrayList list = db.buildList(res);
        db.disconnect();
        
        
        if(list.size() == 0) return;
        
        ArrayList list_json = new ArrayList();
        for(int i = 0; i < list.size(); i++)
        {
            Hashtable ht = (Hashtable) list.get(i);
            HashMap hm = new HashMap(); 
            hm.put("delivery_order_id", ht.get("delivery_order_id"));
            hm.put("gmt0_shipping_datetime", ht.get("gmt0_shipping_datetime"));
            hm.put("gmt0_arrival_datetime", ht.get("gmt0_arrival_datetime"));
            hm.put("timezone_code", ht.get("timezone_code"));
            hm.put("sap_error_msg", ht.get("sap_interface_error_msg"));
            hm.put("external_reference_text", ht.get("external_reference_text"));
            list_json.add(hm);
        }
        
       Gson gson = new Gson();
       String dataSent = gson.toJson(list_json);
       System.out.println(dataSent);

       String[] ret =  ExternalRestCaller.call((String) this.systemht.get("callback_url"), (String)this.systemht.get("callback_apikey"),(String) this.systemht.get("callback_username"), (String)this.systemht.get("callback_password"), ExternalRestCaller.METHOD_POST, dataSent);


       if(ret[0].equals("200")) //OK
       {
            update_external_callback_status(list,"S");
       }
       else
       {
           update_external_callback_status(list,"E");
       }
        
        
    }
     private void update_external_callback_status(ArrayList doc_list, String status) throws Exception {
        MySQLDB db = new MySQLDB();
        db.connect();
        String sql = "UPDATE t_delivery_order_release_confirmation set external_interface_status = ? , external_interface_datetime = NOW() where doc_id =  ? ";
        db.createPrepareStatement(sql);
        db.bindValue(1, status);
        for(int i = 0 ; i < doc_list.size(); i++)
        {
            Hashtable<String, String> ht = (Hashtable<String, String>) doc_list.get(i);       
            db.bindValue(2, ht.get("doc_id"));
            db.executeUpdate();
        }
        db.disconnect();
    }
    
    //=====================================================
    private  ODUpdateResponseMessageSync call_update(com.ntz.byd.gateway.queryoutbounddelivery.manage.autogen.ODUpdateRequestMessageSync odUpdateRequestSync) throws StandardFaultMessage_Exception {
        com.ntz.byd.gateway.queryoutbounddelivery.manage.autogen.Service service = new com.ntz.byd.gateway.queryoutbounddelivery.manage.autogen.Service();
        com.ntz.byd.gateway.queryoutbounddelivery.manage.autogen.ManageODIn port = service.getBinding();
        BindingProvider provider = (BindingProvider) port;
        provider.getRequestContext().put(BindingProvider.USERNAME_PROPERTY, this.systemht.get("system_ws_username"));
        provider.getRequestContext().put(BindingProvider.PASSWORD_PROPERTY, this.systemht.get("system_ws_password"));
        provider.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, this.systemht.get("system_url").toString() + this.systemht.get("service_url_path").toString());
        return port.update(odUpdateRequestSync);
    }

    private  ODUpdateResponseMessageSync call_release(com.ntz.byd.gateway.queryoutbounddelivery.manage.autogen.CopyOfOutboundDeliveryReleaseRequestMessageSync outboundDeliveryReleaseReqSync) throws StandardFaultMessage_Exception {
        com.ntz.byd.gateway.queryoutbounddelivery.manage.autogen.Service service = new com.ntz.byd.gateway.queryoutbounddelivery.manage.autogen.Service();
        com.ntz.byd.gateway.queryoutbounddelivery.manage.autogen.ManageODIn port = service.getBinding();
        BindingProvider provider = (BindingProvider) port;
        provider.getRequestContext().put(BindingProvider.USERNAME_PROPERTY, this.systemht.get("system_ws_username"));
        provider.getRequestContext().put(BindingProvider.PASSWORD_PROPERTY, this.systemht.get("system_ws_password"));
        provider.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, this.systemht.get("system_url").toString() + this.systemht.get("service_url_path").toString());
        return port.release(outboundDeliveryReleaseReqSync);
    }

  

}
