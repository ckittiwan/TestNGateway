/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ntz.byd.gateway;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Base64;

/**
 *
 * @author NTZ_Admin
 */
public class ExternalRestCaller {
    
    
    public static String METHOD_POST = "POST";
    public static String METHOD_GET = "GET";
    public static String[] call(
            String urlStr,
            String apikey,
            String username,
            String password,
            String methodType,
            String data
    ) throws MalformedURLException, IOException
    {
         System.out.println("callback url: "+urlStr);
         System.out.println("callback apikey : "+apikey);
         System.out.println("callback username: "+username);
         System.out.println("callback password : "+password);
         URL url = new URL(urlStr);
         HttpURLConnection con = (HttpURLConnection) url.openConnection();
         con.setRequestMethod(methodType);
         if(!apikey.equals(""))
            con.setRequestProperty("apikey",apikey);
         String userpass = username+":"+password ;
         String basicAuth = "Basic " + new String(Base64.getEncoder().encode(userpass.getBytes()));
         con.setRequestProperty ("Authorization", basicAuth);

         
         if(methodType.equals(METHOD_POST))
         {
            con.setDoOutput(true);
            con.getOutputStream().write(data.getBytes("UTF-8"));
         }
       
        
        
         BufferedReader in = null;
         
         try
         {
             in = new BufferedReader(new InputStreamReader(con.getInputStream()));
         }
         catch(MalformedURLException e)
         {
            StringWriter sw = new StringWriter();
            e.printStackTrace(new PrintWriter(sw));
            String exceptionAsString = sw.toString();
            System.out.println(exceptionAsString);
            
            EmailSender.sendFromGMail("nGateway Error - Send to external system", exceptionAsString);
            throw e;
         }
         catch(IOException e)
         {
            StringWriter sw = new StringWriter();
            e.printStackTrace(new PrintWriter(sw));
            String exceptionAsString = sw.toString();
            System.out.println(exceptionAsString);
            
            EmailSender.sendFromGMail("nGateway Error - Send to external system", exceptionAsString);
            throw e;
         }
         
          String inputLine;
          StringBuffer content = new StringBuffer();
          while ((inputLine = in.readLine()) != null) {
              content.append(inputLine);
          }
          
          String ret[] = new String[]{con.getResponseCode()+"",content.toString()};
          System.out.println("Response Status Code : " + con.getResponseCode());
          System.out.println("Response Content : " + content.toString());
          in.close();
          
          con.disconnect();
          
          //0 = HTTP Response Code
          //1 = Content Response
          return ret;  
    }
}
