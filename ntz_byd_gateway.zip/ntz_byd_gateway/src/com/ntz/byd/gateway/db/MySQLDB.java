/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ntz.byd.gateway.db;


import com.ntz.byd.gateway.XConfig;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Hashtable;
import org.apache.log4j.Logger;

/**
 *
 * @author NTZ_Admin
 */
public class MySQLDB {
     private String host ;
    private String user;
    private String pass;
    private String db ;
    public Connection conn;
    private PreparedStatement _pStmt;
    private String driver = "com.mysql.jdbc.Driver";
    
    //final static Logger logger = Logger.getLogger(MySQLDB.class);
    public MySQLDB()
    {
    	//Properties prop = new Properties();
    	try {
			//prop.load(Thread.currentThread().getContextClassLoader().getResourceAsStream("timesheet.properties"));
			host = XConfig.db_host;//prop.getProperty("Database_Host");
			user = XConfig.db_user;//prop.getProperty("Database_User");
			pass = XConfig.db_pass;//prop.getProperty("Database_Pass");
			db = XConfig.db_schema;//prop.getProperty("Database_Name");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
                        //logger.error(e.getMessage(),e);
		}
    }

    public boolean connect() {
        try
        {
            String URL = "jdbc:mysql://"+host+"/"+db+"?";
            URL += "useUnicode=true&characterEncoding=UTF-8&useOldAliasMetadataBehavior=true";
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection(URL, user, pass);
            return true;
            
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
           //logger.error(ex.getMessage(),ex);
           return false;
        } 
    }
    
    public void disconnect()
    {
        try 
        {
        	if(_pStmt != null)
                 _pStmt.close();
            if(conn != null)
                conn.close();
           
        } 
        catch (SQLException ex) 
        {
            ex.printStackTrace();
            //System.out.println(ex);
             //logger.error(ex.getMessage(),ex);
        }
        finally
        {
            conn = null;
        }
    }
    
    public ResultSet executeQuery() throws Exception
    {
        try
        {
           
            ResultSet _rs = _pStmt.executeQuery();
           // st.close();
            return _rs;
        }
        catch(Exception ex)
        {
           // System.out.println(e);
             //logger.error(ex.getMessage(),ex);
             throw ex;
        }
        
    }
    
    public Object[] executeUpdate()  throws Exception// 0 => amount of affected record  
    								//  1 => msg
    {
    	
    	Object ret[] = new Object[2];
        try
        {
            int executeUpdate = _pStmt.executeUpdate();
            ret[0] = executeUpdate;
            ret[1] = "success";
            return ret;
            
        }
        catch(Exception e)
        {
            //System.out.println(e);
            e.printStackTrace();
            throw e;
            //ret[0] = 0;
            //ret[1] = e.getMessage();
            //return ret;
        }
    }
    
    
    public void createPrepareStatement(String sql)
    {
        try {
            _pStmt =  conn.prepareStatement(sql,PreparedStatement.RETURN_GENERATED_KEYS);
        } catch (SQLException ex) {
            ex.printStackTrace();
            //System.out.println(ex);
        }
        
    }
    
    public long getGeneratedKey(){ //return last inserted ID in session scope
        long key = -1;
        try {
            ResultSet rs =  _pStmt.getGeneratedKeys();
            if (rs != null && rs.next()) {
                key = rs.getLong(1);
            }
        } catch (SQLException ex) {
           //logger.error(ex.getMessage(),ex);
           ex.printStackTrace();
        }
        return key;
    }
    
    public void bindValue(int i,String param){
        try {
            _pStmt.setString(i, param);
        } catch (SQLException ex) {
            //logger.error(ex.getMessage(),ex);
            ex.printStackTrace();
        }
    }
    
     public void bindValue(int i,int param){
        try {
            _pStmt.setInt(i, param);
        } catch (SQLException ex) {
            //logger.error(ex.getMessage(),ex);
            ex.printStackTrace();
        }
    }
     
     public void bindValue(int i,long param){
        try {
            _pStmt.setLong(i, param);
        } catch (SQLException ex) {
            //logger.error(ex.getMessage(),ex);
            ex.printStackTrace();
        }
      }
     
      public void bindValue(int i,double param){
        try {
            _pStmt.setDouble(i, param);
        } catch (SQLException ex) {
            //logger.error(ex.getMessage(),ex);
            ex.printStackTrace();
        }
      }
    
     public ArrayList buildList(ResultSet res)
    {
        ArrayList _list = new ArrayList();
        try {
            com.mysql.jdbc.ResultSetMetaData rsmd = (com.mysql.jdbc.ResultSetMetaData) res.getMetaData();
           
            while (res.next()) {
                Hashtable _tmp = new Hashtable();
              
                for (int i = 1; i <= rsmd.getColumnCount(); i++) {
                    String _tmp2 = res.getString(rsmd.getColumnName(i));
                    _tmp.put(rsmd.getColumnName(i), _tmp2 == null ? "":_tmp2);
                }
                _list.add(_tmp);

            }
           
        } catch (Exception ex) {
            //logger.error(ex.getMessage(),ex);
            ex.printStackTrace();
        }
        return _list; //return list
    }
}
