/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ntz.byd.gateway;

import com.ntz.byd.gateway.manageexchangerate.ManageExchangeRateProcessor;
import com.ntz.byd.gateway.managejournalentry.ManageJournalEntryProcessor;
import com.ntz.byd.gateway.manageodin.ManageODINProcessor;
import com.ntz.byd.gateway.managesitelogisticstask.ManageSiteLogisticsTaskCallbackProcessor;
import com.ntz.byd.gateway.managesitelogisticstask.ManageSiteLogisticsTaskProcessor;
import com.ntz.byd.gateway.querymaterial.QueryMaterialProcessor;
import com.ntz.byd.gateway.queryoutbounddelivery.QueryOutboundDeliveryProcessor;
import com.ntz.byd.gateway.querysitelogisticstask.QuerySiteLogisticsTaskProcessor;
import com.ntz.gateway.queryaccount.QueryAccountProcessor;
import com.ntz.system.monitor.SystemMon;
import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.net.ServerSocket;
import java.nio.channels.FileLock;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.TimeZone;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

/**
 *
 * @author NTZ_Admin
 */
public class Main {
    public static void main(String[] args) throws IOException, Exception {
        XConfig.init();  
        XConfig.initTrustAllCert();
        //Do not forget make lock file for every service
        System.out.println("Start process : " + args[0]);
        if(args[0].equals("QUERY_SITE_LOGISTICS_TASK"))
        {
            if(!isAlreadyRunning("./query_site_logistics_task.lock"))
            //if(!isAlreadyRunning(65001))
                QuerySiteLogisticsTaskProcessor._start();
        }
        else if(args[0].equals("MANAGE_SITE_LOGISTICS_TASK"))
        {
            if(!isAlreadyRunning("./manage_site_logistics_task.lock"))
            //if(!isAlreadyRunning(65002))
                ManageSiteLogisticsTaskProcessor._start();
        }
        else if(args[0].equals("MANAGE_SITE_LOGISTICS_TASK_CALLBAK"))
        {
            if(!isAlreadyRunning("./manage_site_logistics_task_callback.lock"))
            //if(!isAlreadyRunning(65003))
                ManageSiteLogisticsTaskCallbackProcessor._start();
        }
        else if(args[0].equals("QUERY_OUTBOUND_DELIVERY"))
        {
            if(!isAlreadyRunning("./query_outbound_delivery.lock"))
            //if(!isAlreadyRunning(65004))
                QueryOutboundDeliveryProcessor._start();   
        }
        else if(args[0].equals("MANAGE_OD_IN"))
        {
            if(!isAlreadyRunning("./manage_od_in.lock"))
            //if(!isAlreadyRunning(65005))
                ManageODINProcessor._start();   
        }
        else if(args[0].equals("MANAGE_JOURNAL_ENTRY"))
        {
            if(!isAlreadyRunning("./manage_journal_entry.lock"))
            //if(!isAlreadyRunning(65006))
                ManageJournalEntryProcessor._start();    
        }
        else if(args[0].equals("QUERY_ACCOUNT"))
        {
            if(!isAlreadyRunning("./query_account.lock"))
            //if(!isAlreadyRunning(65007))
                QueryAccountProcessor._start();    
        }
        else if(args[0].equals("QUERY_MATERIAL"))
        {
            if(!isAlreadyRunning("./query_material.lock"))
            //if(!isAlreadyRunning(65008))
                QueryMaterialProcessor._start();    
        }
        else if(args[0].equals("MANAGE_EXCHANGE_RATE"))
        {
            if(!isAlreadyRunning("./manage_exchange_rate.lock"))
            //if(!isAlreadyRunning(65009))
                ManageExchangeRateProcessor._start(args[1]);
        }
        else if(args[0].equals("SYSTEM_MON"))
        {
            if(!isAlreadyRunning("./system_mon.lock"))
            //if(!isAlreadyRunning(65010))
                SystemMon._start();
        }
        else
        {
            System.out.println("Hello World !!. Please apply parameter to specify servcie you would like to execute :)");
        }
        
        
        //System.out.println("End process : " + args[0]);
        
    }
    
    
      private static boolean isAlreadyRunning(String lock_file) {
    // socket concept is shown at http://www.rbgrn.net/content/43-java-single-application-instance
    // but this one is really great
        try {
            final File file = new File(lock_file);
            final RandomAccessFile randomAccessFile = new RandomAccessFile(file, "rw");
            final FileLock fileLock = randomAccessFile.getChannel().tryLock();
            if (fileLock != null) {
                Runtime.getRuntime().addShutdownHook(new Thread() {
                    public void run() {
                        try {
                            fileLock.release();
                            randomAccessFile.close();
                            file.delete();
                        } catch (Exception e) {
                            //log.error("Unable to remove lock file: " + lockFile, e);
                        }
                    }
                });
                return false;
            }
        } catch (Exception ex) {
           ex.printStackTrace();
        }
        return true;
    }
      
    private static boolean isAlreadyRunning(int port) {
        try {
            ServerSocket socket = new ServerSocket(port);
            return false;
        } catch (IOException ex) {
           
             System.out.println("Already Running...");
             return true;
        }
        
    }
    
    
    
      
    /*
    public static void main(String[] args) 
    {
        System.out.println("new main");
        
        for(int i = 0 ; i < 100 ; i++)
        {
            try
            {
                continue;
            }
            catch(Exception e)
            {
            
            }
            finally
            {
            
                System.out.println("Finally " + i);
            }
            
            
            System.out.println("End Loop " + i);
        }

    }*/
}
