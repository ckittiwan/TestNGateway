/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ntz.byd.gateway.managesitelogisticstask;

import com.ntz.byd.gateway.db.MySQLDB;
import com.ntz.byd.gateway.managesitelogisticstask.autogen.BusinessDocumentBasicMessageHeader;
import com.ntz.byd.gateway.managesitelogisticstask.autogen.BusinessTransactionDocumentID;
import com.ntz.byd.gateway.managesitelogisticstask.autogen.IdentifiedStockID;
import com.ntz.byd.gateway.managesitelogisticstask.autogen.ProductID;
import com.ntz.byd.gateway.managesitelogisticstask.autogen.Quantity;
import com.ntz.byd.gateway.managesitelogisticstask.autogen.SLTMaterialOutputManageBundleRequest;
import com.ntz.byd.gateway.managesitelogisticstask.autogen.SiteLogisticsLotOperationActivityManageBundleRequest;
import com.ntz.byd.gateway.managesitelogisticstask.autogen.SiteLogisticsTaskBundleLog;
import com.ntz.byd.gateway.managesitelogisticstask.autogen.SiteLogisticsTaskBundleMaintainResponse;
import com.ntz.byd.gateway.managesitelogisticstask.autogen.SiteLogisticsTaskBundleMaintainResponseMessageSync;
import com.ntz.byd.gateway.managesitelogisticstask.autogen.SiteLogisticsTaskMaintainBundleRequest;
import com.ntz.byd.gateway.managesitelogisticstask.autogen.SiteLogisticsTaskMaintainRequestBundleMessage;
import com.ntz.byd.gateway.managesitelogisticstask.autogen.SiteLogisticsTaskMaterialInputManageBundleRequest;
import com.ntz.byd.gateway.managesitelogisticstask.autogen.SiteLogisticsTaskReferenceObjectManageBundleRequest;
import com.ntz.byd.gateway.managesitelogisticstask.autogen.SiteLogisticsTaskSerialNumberManageBundleRequest;
import com.ntz.byd.gateway.managesitelogisticstask.autogen.StandardFaultMessage_Exception;
import com.ntz.byd.gateway.managesitelogisticstask.autogen.UUID;
import java.math.BigDecimal;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.ws.BindingProvider;

/**
 *
 * @author NTZ_Admin
 */
public class ManageSiteLogisticsTaskRunnerV2 implements Runnable{
    
    private Hashtable systemht = null;
    public ManageSiteLogisticsTaskRunnerV2(Hashtable get) {
        systemht = get;
    }

    
    @Override
    public void run() {
        
        ArrayList confirm_list = null;
        try {
            confirm_list = get_all_confirmation_list();
        } catch (Exception ex) {
            Logger.getLogger(ManageSiteLogisticsTaskRunner.class.getName()).log(Level.SEVERE, null, ex);
        }

        for(int i = 0; i < confirm_list.size();i++ )
        {
            Hashtable taskht = (Hashtable) confirm_list.get(i);
            String sap_interface_status = "S";
            String external_interface_status = "W";
            String sap_error_msg = "";

            try 
            {
                SiteLogisticsTaskBundleMaintainResponseMessageSync response = maintainBundleV1(composeManageSiteLogisticsMessage(taskht));   
                SiteLogisticsTaskBundleMaintainResponse resp = response.getSiteLogisticsTaskResponse().get(0);

                for(int j = 0 ; j < resp.getSiteLogisticsTaskLog().size() ; j++)
                {
                    SiteLogisticsTaskBundleLog _log = resp.getSiteLogisticsTaskLog().get(j);
                    if(_log.getSiteLogisticsTaskSeverityCode().equals("E"))
                    {
                        sap_interface_status = "E";
                        external_interface_status = "W";
                    }
                }
            } 
            catch (StandardFaultMessage_Exception ex) 
            {
                sap_interface_status = "E";
                external_interface_status = "W";
                sap_error_msg = ex.getFaultInfo().getStandard().getFaultText();
                Logger.getLogger(ManageSiteLogisticsTaskRunner.class.getName()).log(Level.SEVERE, null, ex);
            } 
            catch (Exception ex) 
            {
                sap_interface_status = "E";
                external_interface_status = "W";
                sap_error_msg = ex.getMessage();
                Logger.getLogger(ManageSiteLogisticsTaskRunner.class.getName()).log(Level.SEVERE, null, ex);
            } 
            finally
            {

                try {
                    update_interface_status(sap_interface_status,external_interface_status,sap_error_msg, (String) taskht.get("id"));
                } catch (Exception ex) {
                    Logger.getLogger(ManageSiteLogisticsTaskRunner.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
        
        
        
        
        //==================================================================
        
        
    }
    
    
    private SiteLogisticsTaskMaintainRequestBundleMessage composeManageSiteLogisticsMessage(Hashtable taskht) throws Exception
    {
        SiteLogisticsTaskMaintainRequestBundleMessage request = new SiteLogisticsTaskMaintainRequestBundleMessage();
        String task_auto_id = taskht.get("id").toString();
        
        request.setBasicMessageHeader(new BusinessDocumentBasicMessageHeader());
        SiteLogisticsTaskMaintainBundleRequest task = new SiteLogisticsTaskMaintainBundleRequest();
        request.getSiteLogisticsTask().add(task);
        task.setSiteLogisticTaskID(new BusinessTransactionDocumentID());
        task.getSiteLogisticTaskID().setValue((String) taskht.get("task_id"));
        task.setSiteLogisticTaskUUID(new UUID());
        task.getSiteLogisticTaskUUID().setValue((String) taskht.get("task_uuid"));
        
        SiteLogisticsTaskReferenceObjectManageBundleRequest reference_object = new SiteLogisticsTaskReferenceObjectManageBundleRequest();
        task.getReferenceObject().add(reference_object);
        
        reference_object.setReferenceObjectUUID(new UUID());
        reference_object.getReferenceObjectUUID().setValue((String) taskht.get("reference_object_uuid"));
        
           
        SiteLogisticsLotOperationActivityManageBundleRequest site_logistic_lot_operation_activity = new SiteLogisticsLotOperationActivityManageBundleRequest();
        reference_object.getOperationActivity().add(site_logistic_lot_operation_activity);
        
        site_logistic_lot_operation_activity.setOperationActivityUUID(new UUID());
        site_logistic_lot_operation_activity.getOperationActivityUUID().setValue((String) taskht.get("site_logistic_lot_operation_activity_uuid"));
        
        ArrayList task_item_confirm_list = get_confirm_task_item(task_auto_id);
        for(int i = 0;i < task_item_confirm_list.size();i++){
            Hashtable iteminfo = (Hashtable)task_item_confirm_list.get(i);
            String output_uuid = iteminfo.get("output_uuid").toString();
            String input_uuid  = iteminfo.get("input_uuid").toString();
            
            String source_logistic_area = iteminfo.get("source_logistic_area").toString();
            String target_logistic_area = iteminfo.get("target_logistic_area").toString();
            String identified_stock_id = iteminfo.get("identified_stock_id").toString();
            String split_indicator = iteminfo.get("split_indicator").toString();

            if(!output_uuid.equals("") && !input_uuid.equals("")){
                SiteLogisticsTaskMaterialInputManageBundleRequest input = new SiteLogisticsTaskMaterialInputManageBundleRequest();
                site_logistic_lot_operation_activity.getMaterialInput().add(input);
                input.setMaterialInputUUID(new UUID());
                input.getMaterialInputUUID().setValue(input_uuid);                
                input.setSourceLogisticsAreaID(source_logistic_area);
                
                SLTMaterialOutputManageBundleRequest output = new SLTMaterialOutputManageBundleRequest();
                site_logistic_lot_operation_activity.getMaterialOutput().add(output);
                
                output.setMaterialOutputUUID(new UUID());
                output.getMaterialOutputUUID().setValue(output_uuid);
                
                if(!target_logistic_area.equals("")){
                    output.setTargetLogisticsAreaID(target_logistic_area);
                }
                
                output.setActualQuantity(new Quantity());
                
                String actual_quantity = iteminfo.get("quantity").toString();
                output.getActualQuantity().setValue(BigDecimal.valueOf(Double.parseDouble(actual_quantity)));
                output.getActualQuantity().setUnitCode(iteminfo.get("unit_code").toString());
                
                if(!identified_stock_id.equals("")){
                    output.setIdentifiedStockID(new IdentifiedStockID());
                    output.getIdentifiedStockID().setValue(identified_stock_id);
                }
                
                if(split_indicator.equals("X")){
                    output.setSplitIndicator(Boolean.TRUE);
                }
                
                
                ArrayList task_item_serial = get_confirm_task_item_serial(iteminfo.get("id").toString());
                if(task_item_serial.size() > 0){
                    output.setSerialNumber(new SiteLogisticsTaskSerialNumberManageBundleRequest());
                    for(int x = 0; x < task_item_serial.size();x++){
                        Hashtable itemserial = (Hashtable)task_item_serial.get(x);
                        output.getSerialNumber().getSerialID().add(itemserial.get("serial_id").toString());
                    }
                }
                
            } else {
                SLTMaterialOutputManageBundleRequest output = new SLTMaterialOutputManageBundleRequest();
                site_logistic_lot_operation_activity.getMaterialOutput().add(output);
                
                output.setMaterialOutputUUID(new UUID());
                
                if(!target_logistic_area.equals("")){
                    output.setTargetLogisticsAreaID(target_logistic_area);
                }
                
                if(!source_logistic_area.equals("")){
                    output.setSourceLogisticsAreaIDPostSplit(source_logistic_area);
                }

                
                output.setActualQuantity(new Quantity());
                String actual_quantity = iteminfo.get("quantity").toString();
                output.getActualQuantity().setValue(BigDecimal.valueOf(Double.parseDouble(actual_quantity)));
                output.getActualQuantity().setUnitCode(iteminfo.get("unit_code").toString());
                
                if(!identified_stock_id.equals("")){
                    output.setIdentifiedStockID(new IdentifiedStockID());
                    output.getIdentifiedStockID().setValue(identified_stock_id);
                }
                
                if(split_indicator.equals("X")){
                    output.setSplitIndicator(Boolean.TRUE);
                }
                
                ArrayList task_item_serial = get_confirm_task_item_serial(iteminfo.get("id").toString());
                if(task_item_serial.size() > 0){
                    output.setSerialNumber(new SiteLogisticsTaskSerialNumberManageBundleRequest());
                    for(int x = 0; x < task_item_serial.size();x++){
                        Hashtable itemserial = (Hashtable)task_item_serial.get(x);
                        output.getSerialNumber().getSerialID().add(itemserial.get("serial_id").toString());
                    }
                }
                
            }
        } 
        return request;
    }

    private  SiteLogisticsTaskBundleMaintainResponseMessageSync maintainBundleV1(com.ntz.byd.gateway.managesitelogisticstask.autogen.SiteLogisticsTaskMaintainRequestBundleMessage siteLogisticsTaskBundleMaintainRequestSyncV1) throws StandardFaultMessage_Exception {
        com.ntz.byd.gateway.managesitelogisticstask.autogen.Service service = new com.ntz.byd.gateway.managesitelogisticstask.autogen.Service();
        com.ntz.byd.gateway.managesitelogisticstask.autogen.ManageSiteLogisticsTaskIn port = service.getBinding();       
        BindingProvider provider = (BindingProvider) port;
        provider.getRequestContext().put(BindingProvider.USERNAME_PROPERTY, this.systemht.get("system_ws_username"));
        provider.getRequestContext().put(BindingProvider.PASSWORD_PROPERTY, this.systemht.get("system_ws_password"));
        provider.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, this.systemht.get("system_url").toString() + this.systemht.get("service_url_path").toString());
        return port.maintainBundleV1(siteLogisticsTaskBundleMaintainRequestSyncV1);
    }

    private void update_interface_status(String sap_interface_status,String external_interface_status, String sap_error_msg, String id) throws Exception {
       
        
        MySQLDB db = new MySQLDB();
        db.connect();
        String sql = "update t_warehouse_task_confirmation set sap_interface_status = ? , sap_interface_error_msg = ? , external_interface_status = ? ,sap_interface_datetime = NOW() "
                + " where id = ? ";
        
        db.createPrepareStatement(sql);
        db.bindValue(1, sap_interface_status);
        db.bindValue(2, sap_error_msg);
        db.bindValue(3, external_interface_status);
        db.bindValue(4, id);
        db.executeUpdate();
        
        
        db.disconnect();
    }
    
    
    
    private  ArrayList get_confirm_task_item(String task_auto_id) throws Exception {
        
        MySQLDB db = new MySQLDB();
        db.connect();
        
        String sql = "SELECT * FROM t_warehouse_task_item_confirmation "
                + "WHERE confirm_task_auto_id = ? ORDER BY order_number ASC";
        
        db.createPrepareStatement(sql);
        db.bindValue(1, task_auto_id);
        
        ResultSet res = db.executeQuery();
        ArrayList list = db.buildList(res);
        db.disconnect();
        return list;
    }
    
    private  ArrayList get_confirm_task_item_serial(String item_auto_id) throws Exception {
        
        MySQLDB db = new MySQLDB();
        db.connect();
        
        String sql = "SELECT * FROM t_warehouse_task_item_confirmation_serial "
                + "WHERE id = ?";
        
        db.createPrepareStatement(sql);
        db.bindValue(1, item_auto_id);
        
        ResultSet res = db.executeQuery();
        ArrayList list = db.buildList(res);
        db.disconnect();
        return list;
    }
    
    
    private  ArrayList get_all_confirmation_list() throws Exception {
        
        MySQLDB db = new MySQLDB();
        db.connect();
        
        String sql = "SELECT t1.*,t2.task_uuid,t2.reference_object_uuid,t2.site_logistic_lot_operation_activity_uuid "
                + "from t_warehouse_task_confirmation t1  "
                + "INNER JOIN t_warehouse_task t2 ON t1.system_id = t2.system_id AND t1.task_id = t2.task_id  "
                + "WHERE t1.system_id = ? AND "
                + " t2.is_finish = 'N' and t2.is_cancel = 'N' "
                + "and t1.sap_interface_status = 'W' ";   //Only pending object is being called
        
        db.createPrepareStatement(sql);
        db.bindValue(1, (String) this.systemht.get("system_id"));
        
        ResultSet res = db.executeQuery();
        
        ArrayList list = db.buildList(res);
        db.disconnect();
        return list;
    }
   
}
