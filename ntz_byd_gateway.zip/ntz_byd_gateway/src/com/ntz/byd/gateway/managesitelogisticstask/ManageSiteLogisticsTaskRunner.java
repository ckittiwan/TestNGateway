/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ntz.byd.gateway.managesitelogisticstask;

import com.ntz.byd.gateway.db.MySQLDB;
import com.ntz.byd.gateway.managesitelogisticstask.autogen.BusinessDocumentBasicMessageHeader;
import com.ntz.byd.gateway.managesitelogisticstask.autogen.BusinessTransactionDocumentID;
import com.ntz.byd.gateway.managesitelogisticstask.autogen.ProductID;
import com.ntz.byd.gateway.managesitelogisticstask.autogen.Quantity;
import com.ntz.byd.gateway.managesitelogisticstask.autogen.SLTMaterialOutputManageBundleRequest;
import com.ntz.byd.gateway.managesitelogisticstask.autogen.SiteLogisticsLotOperationActivityManageBundleRequest;
import com.ntz.byd.gateway.managesitelogisticstask.autogen.SiteLogisticsTaskBundleLog;
import com.ntz.byd.gateway.managesitelogisticstask.autogen.SiteLogisticsTaskBundleMaintainResponse;
import com.ntz.byd.gateway.managesitelogisticstask.autogen.SiteLogisticsTaskBundleMaintainResponseMessageSync;
import com.ntz.byd.gateway.managesitelogisticstask.autogen.SiteLogisticsTaskMaintainBundleRequest;
import com.ntz.byd.gateway.managesitelogisticstask.autogen.SiteLogisticsTaskMaintainRequestBundleMessage;
import com.ntz.byd.gateway.managesitelogisticstask.autogen.SiteLogisticsTaskMaterialInputManageBundleRequest;
import com.ntz.byd.gateway.managesitelogisticstask.autogen.SiteLogisticsTaskReferenceObjectManageBundleRequest;
import com.ntz.byd.gateway.managesitelogisticstask.autogen.SiteLogisticsTaskSerialNumberManageBundleRequest;
import com.ntz.byd.gateway.managesitelogisticstask.autogen.StandardFaultMessage_Exception;
import com.ntz.byd.gateway.managesitelogisticstask.autogen.UUID;
import java.math.BigDecimal;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.ws.BindingProvider;

/**
 *
 * @author NTZ_Admin
 */
public class ManageSiteLogisticsTaskRunner implements Runnable{
    
    private Hashtable systemht = null;
    public ManageSiteLogisticsTaskRunner(Hashtable get) {
        systemht = get;
    }

    
    @Override
    public void run() {
        
        ArrayList confirm_list = null;
        try {
            confirm_list = get_all_confirmation_list();
        } catch (Exception ex) {
            Logger.getLogger(ManageSiteLogisticsTaskRunner.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        for(int i = 0; i < confirm_list.size();i++ )
        {
            Hashtable taskht = (Hashtable) confirm_list.get(i);
            String sap_interface_status = "S";
            String external_interface_status = "N";
            String sap_error_msg = "";

            try 
            {
                SiteLogisticsTaskBundleMaintainResponseMessageSync response = maintainBundleV1(composeManageSiteLogisticsMessage(taskht));   
                SiteLogisticsTaskBundleMaintainResponse resp = response.getSiteLogisticsTaskResponse().get(0);

                for(int j = 0 ; j < resp.getSiteLogisticsTaskLog().size() ; j++)
                {
                    SiteLogisticsTaskBundleLog _log = resp.getSiteLogisticsTaskLog().get(j);
                    if(_log.getSiteLogisticsTaskSeverityCode().equals("E"))
                    {
                        sap_interface_status = "E";
                        external_interface_status = "W";
                    }
                }
            } 
            catch (StandardFaultMessage_Exception ex) 
            {
                sap_interface_status = "E";
                external_interface_status = "W";
                sap_error_msg = ex.getFaultInfo().getStandard().getFaultText();
                Logger.getLogger(ManageSiteLogisticsTaskRunner.class.getName()).log(Level.SEVERE, null, ex);
            } 
            catch (Exception ex) 
            {
                sap_interface_status = "E";
                external_interface_status = "W";
                sap_error_msg = ex.getMessage();
                Logger.getLogger(ManageSiteLogisticsTaskRunner.class.getName()).log(Level.SEVERE, null, ex);
            } 
            finally
            {

                try {
                    update_interface_status(sap_interface_status,external_interface_status,sap_error_msg, (String) taskht.get("id"));
                } catch (Exception ex) {
                    Logger.getLogger(ManageSiteLogisticsTaskRunner.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
        
        
        
        
        //==================================================================
        
        
    }
    
    
    private SiteLogisticsTaskMaintainRequestBundleMessage composeManageSiteLogisticsMessage(Hashtable taskht) throws Exception
    {
        SiteLogisticsTaskMaintainRequestBundleMessage request = new SiteLogisticsTaskMaintainRequestBundleMessage();
        request.setBasicMessageHeader(new BusinessDocumentBasicMessageHeader());
        
        SiteLogisticsTaskMaintainBundleRequest task = new SiteLogisticsTaskMaintainBundleRequest();
        request.getSiteLogisticsTask().add(task);
        
        //==========================================
        task.setSiteLogisticTaskID(new BusinessTransactionDocumentID());
        task.getSiteLogisticTaskID().setValue((String) taskht.get("task_id"));
        task.setSiteLogisticTaskUUID(new UUID());
        task.getSiteLogisticTaskUUID().setValue((String) taskht.get("task_uuid"));
        
        SiteLogisticsTaskReferenceObjectManageBundleRequest reference_object = new SiteLogisticsTaskReferenceObjectManageBundleRequest();
        task.getReferenceObject().add(reference_object);
        
        reference_object.setReferenceObjectUUID(new UUID());
        reference_object.getReferenceObjectUUID().setValue((String) taskht.get("reference_object_uuid"));
        
        SiteLogisticsLotOperationActivityManageBundleRequest site_logistic_lot_operation_activity = new SiteLogisticsLotOperationActivityManageBundleRequest();
        reference_object.getOperationActivity().add(site_logistic_lot_operation_activity);
        
        site_logistic_lot_operation_activity.setOperationActivityUUID(new UUID());
        site_logistic_lot_operation_activity.getOperationActivityUUID().setValue((String) taskht.get("site_logistic_lot_operation_activity_uuid"));
        
        
        SLTMaterialOutputManageBundleRequest output = new SLTMaterialOutputManageBundleRequest();
        site_logistic_lot_operation_activity.getMaterialOutput().add(output);
        
        
        output.setMaterialOutputUUID(new UUID());
        output.getMaterialOutputUUID().setValue((String) taskht.get("output_uuid"));
        output.setProductID(new ProductID());
        output.getProductID().setValue((String) taskht.get("product_id"));
        
        int cnt_serial = Integer.parseInt((String) taskht.get("cnt_serial"));
        if(cnt_serial > 0)
        {
            //get serial
            ArrayList serial_list = get_confirmation_serial_list((String) taskht.get("id"));
            output.setSerialNumber(new SiteLogisticsTaskSerialNumberManageBundleRequest());
            
            for(int i = 0 ; i < serial_list.size() ; i++)
            {
                Hashtable ht_serial = (Hashtable) serial_list.get(i);
                output.getSerialNumber().getSerialID().add((String) ht_serial.get("serial_id"));
            }
        }
        else
        {
            output.setActualQuantity(new Quantity());
            output.getActualQuantity().setValue(BigDecimal.valueOf(Double.parseDouble((String) taskht.get("quantity"))));
            output.getActualQuantity().setUnitCode((String) taskht.get("unit_code"));
        }
        
        
        //2018 Sep 11
        if(taskht.get("target_logistic_area_update_indicator").toString().equals("X")) //Need update target logistic area
        {
            output.setTargetLogisticsAreaID((String) taskht.get("target_logistic_area"));
        }
        
        
        if(taskht.get("source_logistic_area_update_indicator").toString().equals("X")) //Need update source logistic area
        {
            SiteLogisticsTaskMaterialInputManageBundleRequest input = new SiteLogisticsTaskMaterialInputManageBundleRequest();
            site_logistic_lot_operation_activity.getMaterialInput().add(input);
            
            input.setMaterialInputUUID(new UUID());
            input.getMaterialInputUUID().setValue((String) taskht.get("input_uuid"));
            input.setSourceLogisticsAreaID((String) taskht.get("source_logistic_area"));
        }
        
        
        
        
        return request;
    }

    private  SiteLogisticsTaskBundleMaintainResponseMessageSync maintainBundleV1(com.ntz.byd.gateway.managesitelogisticstask.autogen.SiteLogisticsTaskMaintainRequestBundleMessage siteLogisticsTaskBundleMaintainRequestSyncV1) throws StandardFaultMessage_Exception {
        com.ntz.byd.gateway.managesitelogisticstask.autogen.Service service = new com.ntz.byd.gateway.managesitelogisticstask.autogen.Service();
        com.ntz.byd.gateway.managesitelogisticstask.autogen.ManageSiteLogisticsTaskIn port = service.getBinding();       
        BindingProvider provider = (BindingProvider) port;
        provider.getRequestContext().put(BindingProvider.USERNAME_PROPERTY, this.systemht.get("system_ws_username"));
        provider.getRequestContext().put(BindingProvider.PASSWORD_PROPERTY, this.systemht.get("system_ws_password"));
        provider.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, this.systemht.get("system_url").toString() + this.systemht.get("service_url_path").toString());
        return port.maintainBundleV1(siteLogisticsTaskBundleMaintainRequestSyncV1);
    }

    private ArrayList get_confirmation_serial_list(String id) throws Exception {
        MySQLDB db = new MySQLDB();
        db.connect();
        
        String sql = "select * from t_warehouse_task_confirmation_serial where id = ? ";
        db.createPrepareStatement(sql);
        db.bindValue(1,  id);
        
        ResultSet res = db.executeQuery();
        
        
        ArrayList list = db.buildList(res);
        
        db.disconnect();
        
        return list;
    }

    private void update_interface_status(String sap_interface_status,String external_interface_status, String sap_error_msg, String id) throws Exception {
        MySQLDB db = new MySQLDB();
        db.connect();
        String sql = "update t_warehouse_task_confirmation set sap_interface_status = ? , sap_interface_error_msg = ? , external_interface_status = ? ,sap_interface_datetime = NOW() "
                + " where id = ? ";
        
        db.createPrepareStatement(sql);
        db.bindValue(1, sap_interface_status);
        db.bindValue(2, sap_error_msg);
        db.bindValue(3, external_interface_status);
        db.bindValue(4, id);
        db.executeUpdate();
        
        
        db.disconnect();
    }
    
    
    
    
    private  ArrayList get_all_confirmation_list() throws Exception {
        MySQLDB db = new MySQLDB();
        db.connect();
        
        String sql = "select t1.*,t2.task_uuid,t2.reference_object_uuid,t2.site_logistic_lot_operation_activity_uuid,count_serial(t1.id) as cnt_serial from t_warehouse_task_confirmation t1  "
                + "INNER JOIN t_warehouse_task t2 ON t1.system_id = t2.system_id AND t1.task_id = t2.task_id  "
                + "WHERE t1.system_id = ? AND "
                + " t2.is_finish = 'N' and t2.is_cancel = 'N' "
                + "and t1.sap_interface_status = 'W' ";   //Only pending object is being called
        
        db.createPrepareStatement(sql);
        db.bindValue(1, (String) this.systemht.get("system_id"));
        
        ResultSet res = db.executeQuery();
        
        ArrayList list = db.buildList(res);
        
        
        db.disconnect();
        
        return list;
    }
   
}
