/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ntz.byd.gateway.managesitelogisticstask;

import com.google.gson.Gson;
import com.ntz.byd.gateway.EmailSender;
import com.ntz.byd.gateway.ExternalRestCaller;
import com.ntz.byd.gateway.db.MySQLDB;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author NTZ_Admin
 */
public class ManageSiteLigisticsTaskCallbackRunner implements Runnable{
    private Hashtable _systemht = null;
    
    public ManageSiteLigisticsTaskCallbackRunner(Hashtable _ht)
    {
        this._systemht = _ht;
    }
    
    @Override
    public void run() {
       
        if( this._systemht.get("callback_url").toString().equals(""))
        {
            return;
        }
        //=======================================================================================
        try 
        {
            ArrayList confirm_error_list = get_all_confirmation_error_list();
            
            if(confirm_error_list.size() == 0) return;
            
            ArrayList list_task_json = new ArrayList();
            for(int i = 0 ; i < confirm_error_list.size();i ++)
            {
                Hashtable ht = (Hashtable) confirm_error_list.get(i);
                
               
                Hashtable ht_json = new Hashtable();
                ht_json.put("task_id", ht.get("task_id"));
                ht_json.put("reference_id", ht.get("external_reference_text"));
                ht_json.put("sap_error_msg", ht.get("sap_interface_error_msg"));
                ht_json.put("sap_interface_status",ht.get("sap_interface_status"));
                list_task_json.add(ht_json);
            }
            
            
            Gson gson = new Gson();
            String dataSent = gson.toJson(list_task_json);
            System.out.println(dataSent);
           
           String[] ret =  ExternalRestCaller.call((String) this._systemht.get("callback_url"), (String)this._systemht.get("callback_apikey"),(String) this._systemht.get("callback_username"), (String)this._systemht.get("callback_password"), ExternalRestCaller.METHOD_POST, dataSent);
           
           
           if(ret[0].equals("200")) //OK
           {
                update_external_callback_status(confirm_error_list,"S");
           }
           else
           {
               update_external_callback_status(confirm_error_list,"E");
           }
           
           
           
        } catch (Exception ex) {
            StringWriter sw = new StringWriter();
            ex.printStackTrace(new PrintWriter(sw));
            String exceptionAsString = sw.toString();
            System.out.println(exceptionAsString);
            
            EmailSender.sendFromGMail("nGateway Error - Manage Site Logistic Tasks Callback", exceptionAsString);
            Logger.getLogger(ManageSiteLigisticsTaskCallbackRunner.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
    
    
     
     private  ArrayList get_all_confirmation_error_list() throws Exception 
     {
         String sql = "select * from t_warehouse_task_confirmation t1  "
                 + " WHERE  t1.external_interface_status in ('W','E') AND t1.system_id = ? ";
         
         MySQLDB db = new MySQLDB();        
         db.connect();
         db.createPrepareStatement(sql);
         db.bindValue(1, (String) this._systemht.get("system_id"));
         
         ResultSet res = db.executeQuery();
         ArrayList list = db.buildList(res);
         db.disconnect();
         
         return list;
     }

    private Object get_serial_by_id(String id) throws Exception {
         String sql = "select serial_id from t_warehouse_task_confirmation_serial t1  "
                 + " WHERE  id = ? ";
         MySQLDB db = new MySQLDB();        
         db.connect();
         db.createPrepareStatement(sql);
         db.bindValue(1, id);
         
         ResultSet res = db.executeQuery();
         ArrayList<Hashtable<String, String>> list = db.buildList(res);
         db.disconnect();
         
         String[] ret = new String[list.size()];
         for(int i = 0 ; i < ret.length; i++ )
         {
             ret[i] = list.get(i).get("serial_id");
         }
         
         return ret;
    }
    
    
     private void update_external_callback_status(ArrayList list_confirm_tasks, String status) throws Exception {
        MySQLDB db = new MySQLDB();
        db.connect();
        String sql = "UPDATE t_warehouse_task_confirmation set external_interface_status = ? , external_interface_datetime = NOW() where id =  ? ";
        db.createPrepareStatement(sql);
        db.bindValue(1, status);
        for(int i = 0 ; i < list_confirm_tasks.size(); i++)
        {
            Hashtable<String, String> ht = (Hashtable<String, String>) list_confirm_tasks.get(i);       
            db.bindValue(2, ht.get("id"));
            db.executeUpdate();
        }
        db.disconnect();
    }
    
}
