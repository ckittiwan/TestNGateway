/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ntz.byd.gateway.manageexchangerate;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.ntz.byd.gateway.EmailSender;
import com.ntz.byd.gateway.db.MySQLDB;
import com.ntz.byd.gateway.manageexchangerate.autogen.BusinessDocumentBasicMessageHeader;
import com.ntz.byd.gateway.manageexchangerate.autogen.ExchangeRateMaintainConfirmationBundleMessageSync;
import com.ntz.byd.gateway.manageexchangerate.autogen.ExchangeRateMaintainRequestBundleExchangeRate;
import com.ntz.byd.gateway.manageexchangerate.autogen.ExchangeRateMaintainRequestBundleMessageSync;
import com.ntz.byd.gateway.manageexchangerate.autogen.ExchangeRateTypeCode;
import com.ntz.byd.gateway.manageexchangerate.autogen.StandardFaultMessage_Exception;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.math.BigDecimal;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.ResultSet;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Hashtable;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.ws.BindingProvider;

/**
 *
 * @author NTZ_Admin
 */
public class ManageExchangeRateProcessor {
    public static void _start(String _fixDate){
        try
        {
            SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
            java.util.Date _current_date = new java.util.Date();
            String param_date = "";
            if(_fixDate.equals("X"))
            {
                 param_date = df.format(_current_date);
            }
            else
            {
                param_date = _fixDate;
            }
            
            String results = call_web_service(param_date);
            Gson gson = new Gson();
            JsonObject rootObj = gson.fromJson(results, JsonObject.class);
            JsonArray rate_list = rootObj.get("result").getAsJsonObject().get("data").getAsJsonObject().get("data_detail").getAsJsonArray();
            
            //Check if there is no rate data
            if(rate_list.get(0).getAsJsonObject().get("period").getAsString().equals(""))//We execute in Holiday
            {
                System.out.println("There is no new rate data");
                return;
            }
            
            
            System.out.println("Start insert Exchange Rate to Database");
            for(int i = 0 ; i < rate_list.size();  i++)
            {
                JsonObject rate_obj = rate_list.get(i).getAsJsonObject();
                System.out.println(rate_obj.get("currency_name_th").getAsString());
                insert_rate_to_db(
                        rate_obj.get("period").getAsString(),
                        rate_obj.get("currency_id").getAsString(),
                        rate_obj.get("currency_name_th").getAsString(),
                        rate_obj.get("currency_name_eng").getAsString(),
                        rate_obj.get("buying_sight").getAsString().equals("")?0.0:rate_obj.get("buying_sight").getAsBigDecimal().doubleValue() ,
                        rate_obj.get("buying_transfer").getAsBigDecimal().doubleValue(),
                        rate_obj.get("selling").getAsBigDecimal().doubleValue(),
                        rate_obj.get("mid_rate").getAsBigDecimal().doubleValue()
                );
                //System.out.println(rate_obj.get("currency_name_th"));
            }
            System.out.println("Finish inserted Exchange Rate to Database");
            
           
            //Start Interface to ByD
            Calendar c = Calendar.getInstance();
            //c.setTime(_current_date);
            c.setTime(df.parse(param_date));
            c.add(Calendar.DATE, 1);
            String _tomorrowDate  =  df.format(c.getTime());
            ExchangeRateMaintainRequestBundleMessageSync request = composeExchangeRateMessage(rate_list,_tomorrowDate );
            ArrayList tenant_list = get_available_tenant();
            for(int i = 0 ; i < tenant_list.size(); i++)
            {
                maintainBundle(request , (Hashtable) tenant_list.get(i),param_date);
            }
            
            
        }
        catch(Exception ex)
        {
            StringWriter sw = new StringWriter();
            ex.printStackTrace(new PrintWriter(sw));
            String exceptionAsString = sw.toString();
            System.out.println(exceptionAsString);
            
            EmailSender.sendFromGMail("nGateway Error - Manage Exchange Rate", exceptionAsString);
        }

    }
    
    private static String call_web_service(String param_date) throws MalformedURLException, IOException
    {
        
        String url = "https://apigw1.bot.or.th/bot/public/Stat-ExchangeRate/v2/DAILY_AVG_EXG_RATE/";
        
       
        //

        URL obj = new URL(url+"?start_period="+param_date+"&end_period="+param_date);
        HttpURLConnection con = (HttpURLConnection) obj.openConnection();

        // optional default is GET
        con.setRequestMethod("GET");

        //add request header
        con.setRequestProperty("x-ibm-client-id", "a0265534-db49-42da-bda2-1ef5b0b27e06");

        int responseCode = con.getResponseCode();
       // System.out.println("\nSending 'GET' request to URL : " + url);
        //System.out.println("Response Code : " + responseCode);

        BufferedReader in = new BufferedReader(
                new InputStreamReader(con.getInputStream()));
        String inputLine;
        StringBuffer response = new StringBuffer();

        while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
        }
        in.close();
        //System.out.println(response.toString());
        
        return response.toString();
    }
    
    
    
    private static void insert_rate_to_db(String period, String currency_id, String currency_name_th, String currency_name_en, double buying_sight, double buying_transfer, double selling, double mid_rate) throws Exception{
        System.out.println("START "+currency_name_th);
        MySQLDB db = new MySQLDB();
        db.connect();
        
        String sql = "INSERT INTO t_exchangerate(period, currency_id, currency_name_th, currency_name_en, buying_sight, buying_transfer, selling, mid_rate)VALUES(?,?,?,?,?,?,?,?)";
        
        db.createPrepareStatement(sql);
        db.bindValue(1, period);
        db.bindValue(2, currency_id);
        db.bindValue(3, currency_name_th);
        db.bindValue(4, currency_name_en);
        db.bindValue(5, buying_sight);
        db.bindValue(6, buying_transfer);
        db.bindValue(7, selling);
        db.bindValue(8, mid_rate);
        
        db.executeUpdate();
        db.disconnect();
        System.out.println("END "+currency_name_th);
    
    }
    
    
    //=================================================
    private static ArrayList get_available_tenant() throws Exception
    {
        MySQLDB db = new MySQLDB();
        db.connect();
        
        String sql = "select t1.*,t3.service_url_path,t2.callback_url,t2.callback_username,t2.callback_password,t2.callback_apikey  from m_sap_byd_system t1 "
                + " INNER JOIN m_system_service_mapping t2 ON t1.system_id = t2.system_id"
                + " INNER JOIN m_byd_service t3 ON t2.service_id = t3.service_id"
                + " where t3.service_code = 'MANAGE_EXCHANGE_RATE' "
                + " AND t2.status = 'Y' "
                + " AND t1.status = 'Y'"
                + " AND NOW() between t1.valid_from AND t1.valid_to";
        
        db.createPrepareStatement(sql);
        ResultSet res = db.executeQuery();
        ArrayList _list = db.buildList(res);
        db.disconnect();
        
        return _list;
        
    }
    
    private static ExchangeRateMaintainRequestBundleMessageSync composeExchangeRateMessage( JsonArray rate_list, String _tomorrowDate) throws DatatypeConfigurationException {
        ExchangeRateMaintainRequestBundleMessageSync request = new ExchangeRateMaintainRequestBundleMessageSync();
        request.setBasicMessageHeader(new BusinessDocumentBasicMessageHeader());   
        List<ExchangeRateMaintainRequestBundleExchangeRate> exchangeRate = request.getExchangeRate();
        
        
        DecimalFormat formatter = new DecimalFormat("#0.000000");   
        for(int i = 0 ; i < rate_list.size() ; i++)
        {
            ExchangeRateMaintainRequestBundleExchangeRate exRate = new ExchangeRateMaintainRequestBundleExchangeRate();
            exchangeRate.add(exRate);
            JsonObject rate_obj = rate_list.get(i).getAsJsonObject();
            exRate.setActionCode("01");
            exRate.setTypeCode(new ExchangeRateTypeCode());
            exRate.getTypeCode().setValue("001");
            exRate.setSourceCurrencyCode((String) rate_obj.get("currency_id").getAsString());
            exRate.setTargetCurrencyCode("THB"); 
            if( rate_obj.get("currency_id").getAsString().equals("JPY"))
            {
                
                exRate.setBidRate(BigDecimal.valueOf(Double.parseDouble(formatter.format(Double.parseDouble((String) rate_obj.get("buying_transfer").getAsString())/100.0))));
                exRate.setMidRate(BigDecimal.valueOf(Double.parseDouble(formatter.format(Double.parseDouble((String) rate_obj.get("mid_rate").getAsString())/100.0))));
                exRate.setAskRate(BigDecimal.valueOf(Double.parseDouble(formatter.format(Double.parseDouble((String) rate_obj.get("selling").getAsString())/100.0))));
            }
            else if( rate_obj.get("currency_id").getAsString().equals("IDR"))
            {
                exRate.setBidRate(BigDecimal.valueOf(Double.parseDouble(formatter.format(Double.parseDouble((String) rate_obj.get("buying_transfer").getAsString())/1000.0))));
                exRate.setMidRate(BigDecimal.valueOf(Double.parseDouble(formatter.format(Double.parseDouble((String) rate_obj.get("mid_rate").getAsString())/1000.0))));
                exRate.setAskRate(BigDecimal.valueOf(Double.parseDouble(formatter.format(Double.parseDouble((String) rate_obj.get("selling").getAsString())/1000.0))));
            }
            else
            {   
                exRate.setBidRate(BigDecimal.valueOf(Double.parseDouble((String) rate_obj.get("buying_transfer").getAsString())));
                exRate.setMidRate(BigDecimal.valueOf(Double.parseDouble((String) rate_obj.get("mid_rate").getAsString())));
                exRate.setAskRate(BigDecimal.valueOf(Double.parseDouble((String) rate_obj.get("selling").getAsString())));
            }
          
            exRate.setValidFromDateTime(DatatypeFactory.newInstance().newXMLGregorianCalendar(_tomorrowDate+"T00:00:00.000+07:00"));
        }
        return request;
    }

    private static ExchangeRateMaintainConfirmationBundleMessageSync maintainBundle(com.ntz.byd.gateway.manageexchangerate.autogen.ExchangeRateMaintainRequestBundleMessageSync exchangeRateBundleMaintainRequestSync, Hashtable _systemht, String period) throws StandardFaultMessage_Exception {
       
        Runnable runn = new Runnable(){
            @Override
            public void run() {
                String sap_interface_status = "S";
                String sap_interface_error_msg = "";
                
                com.ntz.byd.gateway.manageexchangerate.autogen.Service service = new com.ntz.byd.gateway.manageexchangerate.autogen.Service();
                com.ntz.byd.gateway.manageexchangerate.autogen.ManageExchangeRateIn port = service.getBinding();
                BindingProvider provider = (BindingProvider) port;
                provider.getRequestContext().put(BindingProvider.USERNAME_PROPERTY, _systemht.get("system_ws_username"));
                provider.getRequestContext().put(BindingProvider.PASSWORD_PROPERTY, _systemht.get("system_ws_password"));
                provider.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, _systemht.get("system_url").toString() + _systemht.get("service_url_path").toString());
                try 
                {
                    port.maintainBundle(exchangeRateBundleMaintainRequestSync);
                } 
                catch (StandardFaultMessage_Exception ex) 
                {
                    StringWriter sw = new StringWriter();
                    ex.printStackTrace(new PrintWriter(sw));
                    String exceptionAsString = sw.toString();
                    System.out.println(exceptionAsString);
                    sap_interface_error_msg = exceptionAsString;
                    sap_interface_status = "E";

                    EmailSender.sendFromGMail("nGateway Error - Manage Exchage Rate - Internal Thread - " + _systemht.get("system_url").toString(), exceptionAsString);
                }
                finally
                {
                    MySQLDB db = new MySQLDB();
                    db.connect();
                    db.createPrepareStatement("INSERT INTO t_exchangerate_log(system_id, sap_interface_datetime,sap_interface_status, sap_interface_error_msg, period)VALUES(?,NOW(),?,?,?)");
                    db.bindValue(1, (String) _systemht.get("system_id"));
                    db.bindValue(2, sap_interface_status);
                    db.bindValue(3, sap_interface_error_msg);
                    db.bindValue(4, period);
                    try {
                        db.executeUpdate();
                    } catch (Exception ex) {
                        StringWriter sw = new StringWriter();
                        ex.printStackTrace(new PrintWriter(sw));
                        String exceptionAsString = sw.toString();
                        System.out.println(exceptionAsString);

                        EmailSender.sendFromGMail("nGateway Error - Manage Exchage Rate - Internal Thread - " + _systemht.get("system_url").toString()+" - Database", exceptionAsString);
                    }
                    db.disconnect();
                
                }
            
            }
        };
        
        Thread th = new Thread(runn);
        th.start();
        return null;
        
    }
}
