/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ntz.byd.gateway;

/**
 *
 * @author NTZ_Admin
 */

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.Properties;
import java.util.logging.Level;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;


/**
 *
 * @author MON-INF
 */
public class EmailSender {
    
        
        
        
        public static void sendFromGMail( String subject, String body) {
            System.out.println("Sending Email....");
            Properties props = System.getProperties();
            String host = "smtp.gmail.com";
            props.put("mail.smtp.starttls.enable", "true");
            props.put("mail.smtp.host", XConfig.smtp_host);
            props.put("mail.smtp.user", XConfig.smtp_user);
            props.put("mail.smtp.password", XConfig.smtp_pass);
            props.put("mail.smtp.port", XConfig.smtp_port);
            props.put("mail.smtp.auth", "false");
            props.put("mail.smtp.ssl.trust", "smtp.gmail.com");

            Session session = Session.getDefaultInstance(props);
            MimeMessage message = new MimeMessage(session);

            try {
                message.setFrom(new InternetAddress(XConfig.smtp_from, XConfig.smtp_from));
                InternetAddress[] toAddress = new InternetAddress[XConfig.list_email.size()];

                // To get the array of addresses
                for( int i = 0; i < XConfig.list_email.size(); i++ ) {
                    toAddress[i] = new InternetAddress(XConfig.list_email.get(i));
                }

                for( int i = 0; i < toAddress.length; i++) {
                    message.addRecipient(Message.RecipientType.TO, toAddress[i]);
                }

                message.setSubject(subject);
                message.setText(body);
                Transport transport = session.getTransport("smtp");
                transport.connect(XConfig.smtp_host,XConfig.smtp_user , XConfig.smtp_pass);
                transport.sendMessage(message, message.getAllRecipients());
                transport.close();
                System.out.println("Success Sending Email.");
            } catch (MessagingException ex) {
                java.util.logging.Logger.getLogger(EmailSender.class.getName()).log(Level.SEVERE, null, ex);
            } catch (UnsupportedEncodingException ex) {
                java.util.logging.Logger.getLogger(EmailSender.class.getName()).log(Level.SEVERE, null, ex);
            }
           
       
    }
        
        /*
    public static void sendHTMLMailFromGMail( String subject, String body) {
            Properties props = System.getProperties();
            String host = "smtp.gmail.com";
            props.put("mail.smtp.starttls.enable", "true");
            props.put("mail.smtp.host", XConfig.smtp_host);
            props.put("mail.smtp.user", XConfig.smtp_user);
            props.put("mail.smtp.password", XConfig.smtp_pass);
            props.put("mail.smtp.port", XConfig.smtp_port);
            props.put("mail.smtp.auth", "false");

            Session session = Session.getDefaultInstance(props);
            MimeMessage message = new MimeMessage(session);

            try {
                message.setFrom(new InternetAddress(XConfig.smtp_from, XConfig.smtp_from));
                InternetAddress[] toAddress = new InternetAddress[XConfig.list_email.size()];

                // To get the array of addresses
                for( int i = 0; i < XConfig.list_email.size(); i++ ) {
                    toAddress[i] = new InternetAddress(XConfig.list_email.get(i));
                }

                for( int i = 0; i < toAddress.length; i++) {
                    message.addRecipient(Message.RecipientType.TO, toAddress[i]);
                }

                message.setSubject(subject);
                message.setContent(body,"text/html");
                Transport transport = session.getTransport("smtp");
                transport.connect(XConfig.smtp_host,XConfig.smtp_user , XConfig.smtp_pass);
                transport.sendMessage(message, message.getAllRecipients());
                transport.close();
            }
            catch (Exception ae) {
                //logger.error("Unable to send email", ae);
            }
       
    }
    */
    /*
    public static void main(String[] args) throws IOException {
        XConfig.init();
        XConfig.initTrustAllCert();
        System.out.println(XConfig.smtp_host);
        sendFromGMail("TEST GW", "TEST");
    }*/
}