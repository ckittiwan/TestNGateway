/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ntz.byd.gateway.querysitelogisticstask;

/**
 *
 * @author NTZ_Admin
 */
public class SiteLogisticsTaskItemModel {
    public String system_id;
    public String task_id;
    public String output_uuid;
    public String input_uuid;
    public String source_logistic_area;
    public String target_logistic_area;
    public String product_id;
    public String product_desc;
    public String identified_stock_id;
    public double plan_quantity;
    public String unit_code;
    public String line_item_id;
    
}
