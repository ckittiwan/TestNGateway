/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ntz.byd.gateway.querysitelogisticstask;

import java.util.ArrayList;

/**
 *
 * @author NTZ_Admin
 */
public class SiteLogisticsTaskModel {
    public String system_id;
    public String task_id;
    public String task_uuid;
    public String operation_type_code; 
    public String operation_type_code_name;
    public String reference_object_uuid;
    public String byd_assign_employee_id;
    public String site_logistic_lot_operation_activity_uuid;
    public String is_finish ;
    public String is_cancel;
    public String external_interface_status = "W";
  
    
    public ArrayList<SiteLogisticsTaskItemModel> items = new ArrayList<SiteLogisticsTaskItemModel>();
}
