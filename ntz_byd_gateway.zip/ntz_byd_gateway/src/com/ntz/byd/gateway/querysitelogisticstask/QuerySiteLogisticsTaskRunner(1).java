/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ntz.byd.gateway.querysitelogisticstask;

import com.google.gson.Gson;
import com.ntz.byd.gateway.EmailSender;
import com.ntz.byd.gateway.ExternalRestCaller;
import com.ntz.byd.gateway.db.MySQLDB;
import com.ntz.byd.gateway.querysitelogisticstask.autogen.EmployeeID;
import com.ntz.byd.gateway.querysitelogisticstask.autogen.QueryProcessingConditions;
import com.ntz.byd.gateway.querysitelogisticstask.autogen.SiteLogisticsLotMaterialInput;
import com.ntz.byd.gateway.querysitelogisticstask.autogen.SiteLogisticsLotMaterialOutput;
import com.ntz.byd.gateway.querysitelogisticstask.autogen.SiteLogisticsTaskByElementsQueryMessage;
import com.ntz.byd.gateway.querysitelogisticstask.autogen.SiteLogisticsTaskByElementsResponseSync;
import com.ntz.byd.gateway.querysitelogisticstask.autogen.SiteLogisticsTaskResponseMessageSync;
import com.ntz.byd.gateway.querysitelogisticstask.autogen.SiteLogisticsTaskSelectionByElements;
import com.ntz.byd.gateway.querysitelogisticstask.autogen.SiteLogisticsTaskSelectionByResponsibleEmployeeID;
import com.ntz.byd.gateway.querysitelogisticstask.autogen.StandardFaultMessage_Exception;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.ws.BindingProvider;

/**
 *
 * @author NTZ_Admin
 */
public class QuerySiteLogisticsTaskRunner implements Runnable {
    
   
    private Hashtable _systemht = null;
    private ArrayList task_type_list = null;
    
    public QuerySiteLogisticsTaskRunner(Hashtable _ht)
    {
        this._systemht = _ht;
    }
    
    private PreparedStatement statementInsertTask = null;
    private PreparedStatement statementInsertTaskItems = null;
    
    private SiteLogisticsTaskByElementsQueryMessage composeQuerySiteLogisticsTaskMessage(String employee_id)
    {
        SiteLogisticsTaskByElementsQueryMessage request = new SiteLogisticsTaskByElementsQueryMessage();
        request.setSiteLogisticsTaskSelectionByElements(new SiteLogisticsTaskSelectionByElements());
        
        SiteLogisticsTaskSelectionByResponsibleEmployeeID emp_req = new SiteLogisticsTaskSelectionByResponsibleEmployeeID();
        
        
        emp_req.setInclusionExclusionCode("I");
        emp_req.setIntervalBoundaryTypeCode("1");
        emp_req.setLowerBoundaryResponsibleEmployeeID(new EmployeeID());
        emp_req.getLowerBoundaryResponsibleEmployeeID().setValue(employee_id);
        
        
        
        request.getSiteLogisticsTaskSelectionByElements().getSelectionByResponsibleEmployeeID().add(emp_req);
        request.setProcessingConditions(new QueryProcessingConditions());
        request.getProcessingConditions().setQueryHitsUnlimitedIndicator(true);
        
        return request;
        
    }
    
    public void run() {
        try 
        {
            ArrayList _listTask = new ArrayList();
            ArrayList sap_employee_list = get_sap_employee_list();
            task_type_list = get_task_allow_type((String)this._systemht.get("system_id"));
            for(int z = 0 ; z < sap_employee_list.size(); z++)
            {
                Hashtable htemp = (Hashtable) sap_employee_list.get(z);
                SiteLogisticsTaskResponseMessageSync response = findByElements(composeQuerySiteLogisticsTaskMessage((String) htemp.get("sap_employee_id")));
                List<SiteLogisticsTaskByElementsResponseSync> siteLogisticsTasks = response.getSiteLogisticsTask();
               
                for(int i = 0 ; i < siteLogisticsTasks.size() ; i++)
                {
                    
                    SiteLogisticsTaskByElementsResponseSync taskObj = siteLogisticsTasks.get(i);
                    SiteLogisticsTaskModel _taskModel = new SiteLogisticsTaskModel();  
                    String operationTypeCode = taskObj.getOperationTypeCode().getValue();
                    String taskType = get_allow_task_type_code(operationTypeCode);
                    if(!checkAllowTask(taskType)){
                        continue;
                    }
                    _taskModel.system_id = (String) this._systemht.get("system_id");
                    _taskModel.task_id = taskObj.getSiteLogisticsTaskID().getValue();
                    _taskModel.task_uuid = taskObj.getSiteLogisticsTaskUUID().getValue();
                    _taskModel.operation_type_code = operationTypeCode;
                    _taskModel.operation_type_code_name = get_operation_type_code_name(_taskModel.operation_type_code);
                    _taskModel.reference_object_uuid = taskObj.getSiteLogisticsTaskReferencedObject().getReferencedObjectUUID().getValue();
                    _taskModel.site_logistic_lot_operation_activity_uuid = taskObj.getSiteLogisticsTaskReferencedObject().getSiteLogisticsLotOperationActivity().getSiteLogisticsLotOperationActivityUUID().getValue();
                    _taskModel.is_finish = "N";
                    _taskModel.is_cancel = "N";
                    _taskModel.byd_assign_employee_id = (String) htemp.get("sap_employee_id");
                    

                    _listTask.add(_taskModel);
                    List<SiteLogisticsLotMaterialOutput> materialOutputs = taskObj.getSiteLogisticsTaskReferencedObject().getSiteLogisticsLotOperationActivity().getMaterialOutput();
                    for(int j = 0 ; j < materialOutputs.size(); j++)
                    {
                        SiteLogisticsLotMaterialOutput outputObj = materialOutputs.get(j);
                        SiteLogisticsTaskItemModel itemModel = new SiteLogisticsTaskItemModel();
                        itemModel.system_id = _taskModel.system_id;
                        itemModel.task_id =  _taskModel.task_id;
                        itemModel.output_uuid = outputObj.getSiteLogisticsLotMaterialOutputUUID().getValue();
                        itemModel.target_logistic_area = outputObj.getTargetLogisticsAreaID();
                        itemModel.product_id = outputObj.getProductID().getValue();
                        itemModel.product_desc = outputObj.getProductDescription().getValue();
                        if(outputObj.getIdentifiedStockID() != null)
                            itemModel.identified_stock_id = outputObj.getIdentifiedStockID().getValue();
                        
                        itemModel.plan_quantity = outputObj.getPlanQuantity().getValue().doubleValue();
                        itemModel.unit_code = outputObj.getPlanQuantity().getUnitCode();
                        itemModel.line_item_id = outputObj.getLineItemID().toString();
                        _taskModel.items.add(itemModel);
                        
                    }
                    
                    
                    List<SiteLogisticsLotMaterialInput> materialInputs = taskObj.getSiteLogisticsTaskReferencedObject().getSiteLogisticsLotOperationActivity().getMaterialInput();
                    for(int j = 0 ;j < materialInputs.size(); j++)
                    {
                        SiteLogisticsLotMaterialInput inputObj = materialInputs.get(j);
                        
                        for(int k  = 0; k < _taskModel.items.size() ; k++)
                        {
                            if(inputObj.getLineItemID().intValue() == Integer.parseInt(_taskModel.items.get(k).line_item_id))
                            {
                                _taskModel.items.get(k).input_uuid = inputObj.getSiteLogisticsLotMaterialInputUUID().getValue();
                                _taskModel.items.get(k).source_logistic_area = inputObj.getSourceLogisticsAreaID();
                                if(inputObj.getIdentifiedStockID() != null)
                                     _taskModel.items.get(k).identified_stock_id = inputObj.getIdentifiedStockID().getValue();
                                    
                                break;
                            }
                        
                        }
                    }
  
                }
            
            }
            
            
            
            
            
            
            
            //insert into db
            MySQLDB db = new MySQLDB();
            db.connect();
            
            this.statementInsertTask = db.conn.prepareStatement(getSQLInsertTaskTemplate());
            this.statementInsertTaskItems = db.conn.prepareStatement(getSQLInsertTaskItemTemplate());
          
            for(int i = 0 ; i < _listTask.size() ; i++)
            {
                SiteLogisticsTaskModel _taskModel = (SiteLogisticsTaskModel) _listTask.get(i);
                
                ArrayList tmp_list =  getExistingTask(_taskModel.system_id, _taskModel.task_id ,_taskModel.task_uuid);
                if(tmp_list.size() == 0)
                {
                    //Task not exists
                    statementInsertTask.setString(1, _taskModel.system_id);
                    statementInsertTask.setString(2, _taskModel.task_id);
                    statementInsertTask.setString(3, _taskModel.task_uuid);
                    statementInsertTask.setString(4, _taskModel.operation_type_code);
                    statementInsertTask.setString(5, _taskModel.reference_object_uuid);
                    statementInsertTask.setString(6, _taskModel.site_logistic_lot_operation_activity_uuid);
                    statementInsertTask.setString(7, _taskModel.is_finish);
                    statementInsertTask.setString(8, _taskModel.is_cancel);
                    statementInsertTask.setString(9, _taskModel.external_interface_status);
                    statementInsertTask.setString(10, _taskModel.byd_assign_employee_id);
                    statementInsertTask.setString(11, _taskModel.operation_type_code_name);
                    statementInsertTask.executeUpdate();

                    for(int j = 0 ; j < _taskModel.items.size() ; j++)
                    {
                        SiteLogisticsTaskItemModel itemModel = _taskModel.items.get(j);
                        statementInsertTaskItems.setString(1, itemModel.system_id);
                        statementInsertTaskItems.setString(2, itemModel.task_id);
                        statementInsertTaskItems.setString(3, itemModel.output_uuid);
                        if(itemModel.input_uuid == null){
                            System.out.println("A -> " + itemModel.input_uuid);
                            statementInsertTaskItems.setString(4, "");
                        } else {
                            System.out.println("B -> " + itemModel.input_uuid);
                            statementInsertTaskItems.setString(4, itemModel.input_uuid);
                        }
                        statementInsertTaskItems.setString(5, itemModel.source_logistic_area);
                        statementInsertTaskItems.setString(6, itemModel.target_logistic_area);
                        statementInsertTaskItems.setString(7, itemModel.product_id);
                        statementInsertTaskItems.setString(8, itemModel.product_desc);
                        statementInsertTaskItems.setString(9, itemModel.identified_stock_id);
                        statementInsertTaskItems.setDouble(10, itemModel.plan_quantity);

                        statementInsertTaskItems.setString(11, itemModel.unit_code);
                        statementInsertTaskItems.setString(12, itemModel.line_item_id);
                        statementInsertTaskItems.executeUpdate();
                    }
                }
                else
                {
                    //Task Exist, Then check for update on logistic area, identified stock for each line item
                    ArrayList task_line_items = get_exists_task_line_item(_taskModel.system_id, _taskModel.task_id );
                    System.out.println("Already Exists Warehouse Task  System :  " +_taskModel.system_id+", Task ID :" + _taskModel.task_id  );
                    boolean task_change_flag = false; 
                    for(int j = 0 ; j < _taskModel.items.size() ; j++ )
                    {
                        //Looking for record in table
                        SiteLogisticsTaskItemModel _itModel = _taskModel.items.get(j);
                        for(int k = 0 ; k < task_line_items.size() ; k++)
                        {
                            Hashtable<String , String> _ht1  = (Hashtable) task_line_items.get(k);
                            if(_ht1.get("system_id").equals(_itModel.system_id) 
                                    && _ht1.get("task_id").equals(_itModel.task_id) 
                                    && _ht1.get("output_uuid").equals(_itModel.output_uuid)  
                                    && _ht1.get("input_uuid").equals(_itModel.input_uuid) )
                            {
                                //Found ht1 that match to _itModel, then check for focused fields
                                if( 
                                       !_ht1.get("source_logistic_area").equals(_itModel.source_logistic_area == null ? "":_itModel.source_logistic_area )
                                    || !_ht1.get("target_logistic_area").equals(_itModel.target_logistic_area == null ? "":_itModel.target_logistic_area) 
                                    || !_ht1.get("product_id").equals(_itModel.product_id) 
                                    || !_ht1.get("identified_stock_id").equals(_itModel.identified_stock_id == null ? "":_itModel.identified_stock_id )    
                                    ||  Double.parseDouble(_ht1.get("plan_quantity")) !=  _itModel.plan_quantity  
                                    || !_ht1.get("unit_code").equals(_itModel.unit_code) 
                                  )
                                {
                                    //Some field changed, then update and 
                                    System.out.println("Some Fields Changed System ID : " + _itModel.system_id + ", Task ID : " + _itModel.task_id + " Line No : " + _itModel.line_item_id);
                                    System.out.println(_ht1.get("source_logistic_area") + " : " + _itModel.source_logistic_area);
                                    System.out.println(_ht1.get("target_logistic_area") + " : " + _itModel.target_logistic_area);
                                    System.out.println(_ht1.get("product_id") + " : " + _itModel.product_id);
                                    System.out.println(_ht1.get("identified_stock_id") + " : " + _itModel.identified_stock_id);
                                    System.out.println( Double.parseDouble(_ht1.get("plan_quantity")) + " : " + _itModel.plan_quantity);
                                    System.out.println(_ht1.get("unit_code") + " : " + _itModel.unit_code);
                                        
                                    task_change_flag = true;
                                    update_existing_line_item(_itModel);
                                }
                                
                                
                                break; //break loop k                    
                            }
                        }
                    }         
                    if(task_change_flag) //Task get modified, then re-interface to external system
                    {
                        update_warehouse_task_external_interface_status(_taskModel.system_id, _taskModel.task_id , "W");
                    } 
                }//End if task exists
                
            }
            
            
            db.disconnect();
            
            
            //Start sending tasks to external callback
            send_task_to_external_callback_system();
  
            
        } catch (StandardFaultMessage_Exception ex) {
            StringWriter sw = new StringWriter();
            ex.printStackTrace(new PrintWriter(sw));
            String exceptionAsString = sw.toString();
            System.out.println(exceptionAsString);
            
            EmailSender.sendFromGMail("nGateway Error - Query Site Logistic Tasks", exceptionAsString);
            Logger.getLogger(QuerySiteLogisticsTaskRunner.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
             StringWriter sw = new StringWriter();
            ex.printStackTrace(new PrintWriter(sw));
            String exceptionAsString = sw.toString();
            System.out.println(exceptionAsString);
            
            EmailSender.sendFromGMail("nGateway Error - Query Site Logistic Tasks", exceptionAsString);
            Logger.getLogger(QuerySiteLogisticsTaskRunner.class.getName()).log(Level.SEVERE, null, ex);
        } catch (Exception ex) {
             StringWriter sw = new StringWriter();
            ex.printStackTrace(new PrintWriter(sw));
            String exceptionAsString = sw.toString();
            System.out.println(exceptionAsString);
            
            EmailSender.sendFromGMail("nGateway Error - Query Site Logistic Tasks", exceptionAsString);
            Logger.getLogger(QuerySiteLogisticsTaskRunner.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    
    private String getSQLInsertTaskTemplate()
    {
        String sql = "INSERT  INTO t_warehouse_task(system_id,task_id,task_uuid,operation_type_code, reference_object_uuid, site_logistic_lot_operation_activity_uuid, is_finish, is_cancel, create_datetime, external_interface_status, byd_assign_employee_id,operation_type_code_name,external_interface_datetime)values";
        sql += "(?,?,?,?,?,?,?,?,NOW(),?,?,?, NULL )";
        
        return sql;
    
    }
    
    private String getSQLInsertTaskItemTemplate()
    {
        String sql = "INSERT INTO t_warehouse_item(system_id,task_id,output_uuid,input_uuid,source_logistic_area, target_logistic_area, product_id, product_desc,identified_stock_id, plan_quantity, unit_code, line_item_id, create_datetime)values";
        sql += "(?,?,?,?,?,?,?,?,?,?,?,?,NOW() )";
        
        return sql;
    
    }
    
    


    private  SiteLogisticsTaskResponseMessageSync findByElements(com.ntz.byd.gateway.querysitelogisticstask.autogen.SiteLogisticsTaskByElementsQueryMessage siteLogisticsTaskByElementsQuerySync) throws StandardFaultMessage_Exception {
        com.ntz.byd.gateway.querysitelogisticstask.autogen.Service service = new com.ntz.byd.gateway.querysitelogisticstask.autogen.Service();
        com.ntz.byd.gateway.querysitelogisticstask.autogen.QuerySiteLogisticsTaskIn port = service.getBinding();
        BindingProvider provider = (BindingProvider) port;
        provider.getRequestContext().put(BindingProvider.USERNAME_PROPERTY, this._systemht.get("system_ws_username"));
        provider.getRequestContext().put(BindingProvider.PASSWORD_PROPERTY, this._systemht.get("system_ws_password"));
        provider.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, this._systemht.get("system_url").toString() + this._systemht.get("service_url_path").toString());
        return port.findByElements(siteLogisticsTaskByElementsQuerySync);
    }

    private ArrayList get_sap_employee_list() throws Exception {
        
        String sql = "select * from t_warehouse_task_config_employee where system_id = ? AND status = 'Y' ";
        MySQLDB db = new MySQLDB();
        db.connect();
        db.createPrepareStatement(sql);
        db.bindValue(1, (String) this._systemht.get("system_id"));
        
        ResultSet res = db.executeQuery();
        
        ArrayList list = db.buildList(res);
        db.disconnect();
        
        
        System.out.println(list);
        
        return list;
    }

    private String get_allow_task_type_code(String operation_type_code) {
        if(operation_type_code.equals("11"))
            return "PUTAWAY";
        else if(operation_type_code.equals("12"))
            return "UNLOAD";
        else if(operation_type_code.equals("13"))
            return "RETURN_PUTAWAY";
        else if(operation_type_code.equals("14"))
            return "RETURN_UNLOAD";
        else if(operation_type_code.equals("21"))
            return "PICK";
        else if(operation_type_code.equals("22"))
            return "LOAD";
        else if(operation_type_code.equals("23"))
            return "RETURN_PICK";
        else if(operation_type_code.equals("24"))
            return "RETURN_LOAD";
        else if(operation_type_code.equals("31"))
            return "REMOVE";
        else if(operation_type_code.equals("30"))
            return "REPLENISH";
        return "Unknown";
    }
    
    
    private String get_operation_type_code_name(String operation_type_code) {
        if(operation_type_code.equals("11"))
            return "Put Away";
        else if(operation_type_code.equals("12"))
            return "Unload";
        else if(operation_type_code.equals("13"))
            return "Returns Put Away";
        else if(operation_type_code.equals("14"))
            return "Returns Unload";
        else if(operation_type_code.equals("21"))
            return "Pick";
        else if(operation_type_code.equals("22"))
            return "Load";
        else if(operation_type_code.equals("23"))
            return "Returns Pick";
        else if(operation_type_code.equals("24"))
            return "Returns Load";
        else if(operation_type_code.equals("31"))
            return "Remove";
        else if(operation_type_code.equals("30"))
            return "Replenish";
        return "Unknown";
    }

    private void send_task_to_external_callback_system() throws IOException, Exception  {
        
        if( this._systemht.get("callback_url").toString().equals(""))
        {
            System.out.println("No call back");
            return;
        }
        
       MySQLDB db = new MySQLDB();
       
       db.connect();
       
       String sql = "select t1.task_id,t1.operation_type_code,t1.operation_type_code_name,t1.byd_assign_employee_id,DATE_FORMAT(t1.create_datetime,'%Y-%m-%d %H:%i:%s') as create_datetime from t_warehouse_task t1 where t1.external_interface_status in ('W','E') and t1.system_id = ? ";
       db.createPrepareStatement(sql);
       db.bindValue(1, (String) this._systemht.get("system_id"));
       
       ResultSet res = db.executeQuery();
       ArrayList list_tasks = db.buildList(res);
       db.disconnect();
       
       if(list_tasks.size() == 0) return;
       
       for(int i = 0 ; i < list_tasks.size();i++)
       {
           Hashtable ht = (Hashtable) list_tasks.get(i);
           ht.put("items",get_task_item((String)this._systemht.get("system_id"),(String)ht.get("task_id")));
       }
       
       Gson gson = new Gson();
       String dataSent = gson.toJson(list_tasks);
       System.out.println(dataSent);
       try {
            FileWriter fileWriter = new FileWriter(new File("output.json"));
            PrintWriter printWriter = new PrintWriter(fileWriter);
            printWriter.print(dataSent);
            printWriter.close();

       } catch(Exception e) {
           
       }
       String results[] = null;
      
        results =  ExternalRestCaller.call(
                (String) this._systemht.get("callback_url"), 
                (String) this._systemht.get("callback_apikey"), 
                (String) this._systemht.get("callback_username"), 
                (String) this._systemht.get("callback_password"), 
                ExternalRestCaller.METHOD_POST, 
                dataSent);
      
       if(results[0].equals("200"))//OK
       {
           update_external_callback_status(list_tasks,"S");
       }
       else //Fail
       {
           update_external_callback_status(list_tasks,"E");
       }
    }
    
    
    private ArrayList get_task_allow_type(String system_id) throws Exception{
        MySQLDB db = new MySQLDB();
        db.connect();
        
        String sql = "SELECT task_type_name FROM t_warehouse_task_config_allow_task_type WHERE system_id = ? AND active = 'Y'";
        db.createPrepareStatement(sql);
        db.bindValue(1,system_id);
        
        ResultSet res = db.executeQuery();
        ArrayList list = db.buildList(res);

        db.disconnect();
       
        return list;
    }
        
    
    
    private ArrayList get_task_item(String system_id, String task_id) throws Exception
    {
          MySQLDB db = new MySQLDB();
          db.connect();
          String sql = "select t1.output_uuid,t1.input_uuid,t1.source_logistic_area,t1.target_logistic_area,t1.product_id,t1.product_desc,t1.identified_stock_id,t1.plan_quantity,t1.unit_code,t1.line_item_id from t_warehouse_item t1 where t1.system_id = ? AND t1.task_id = ?";
          db.createPrepareStatement(sql);
          db.bindValue(1, system_id);
          db.bindValue(2, task_id);
          
          ResultSet res = db.executeQuery();
          ArrayList list = db.buildList(res);
        //  System.out.println(list);
          db.disconnect();
          return list;
    }

    private void update_external_callback_status(ArrayList list_tasks, String status) throws Exception {
        MySQLDB db = new MySQLDB();
        db.connect();
        String sql = "UPDATE t_warehouse_task set external_interface_status = ? , external_interface_datetime = NOW() where system_id = ? AND task_id = ? ";
        db.createPrepareStatement(sql);
        db.bindValue(1, status);
        db.bindValue(2, (String) this._systemht.get("system_id"));
        for(int i = 0 ; i < list_tasks.size(); i++)
        {
            Hashtable<String, String> ht = (Hashtable<String, String>) list_tasks.get(i);       
            db.bindValue(3, ht.get("task_id"));
            db.executeUpdate();
        }
        db.disconnect();
    }

    private ArrayList getExistingTask(String system_id, String task_id, String task_uuid) throws Exception {
       MySQLDB db = new MySQLDB();
       db.connect();
       String sql = "select * from t_warehouse_task t1 where system_id = ? AND task_id = ? AND task_uuid = ? ";
       db.createPrepareStatement(sql);
       db.bindValue(1, system_id);
       db.bindValue(2, task_id);
       db.bindValue(3, task_uuid);
       ResultSet res = db.executeQuery();
       ArrayList list = db.buildList(res);

       db.disconnect();
       
       return list;
    }

    private ArrayList get_exists_task_line_item(String system_id, String task_id) throws Exception {
        MySQLDB db = new MySQLDB();
       db.connect();
       String sql = "select * from t_warehouse_item t1 where system_id = ? AND task_id = ?";
       db.createPrepareStatement(sql);
       db.bindValue(1, system_id);
       db.bindValue(2, task_id);
       ResultSet res = db.executeQuery();
       ArrayList list = db.buildList(res);

       db.disconnect();
       
       return list;
    }

    private void update_existing_line_item(SiteLogisticsTaskItemModel _itModel) throws Exception {
       MySQLDB db = new MySQLDB();
       db.connect();
       String sql = "update t_warehouse_item t1 set "
               + "t1.source_logistic_area = ? , "
               + "t1.target_logistic_area = ? , "
               + "t1.product_id = ? , "
               + "t1.identified_stock_id = ?, "
               + "t1.plan_quantity = ?, "
               + "t1.unit_code = ? "
               + " where t1.system_id = ? AND t1.task_id = ? AND t1.output_uuid = ? AND t1.input_uuid = ? ";
       db.createPrepareStatement(sql);
       db.bindValue(1, _itModel.source_logistic_area);
       db.bindValue(2, _itModel.target_logistic_area);
       db.bindValue(3, _itModel.product_id);
       db.bindValue(4, _itModel.identified_stock_id);
       db.bindValue(5, _itModel.plan_quantity);
       db.bindValue(6, _itModel.unit_code);
       db.bindValue(7, _itModel.system_id);
       db.bindValue(8, _itModel.task_id);
       db.bindValue(9, _itModel.output_uuid);
       db.bindValue(10, _itModel.input_uuid);
       
       db.executeUpdate();
       db.disconnect();
    }

    private void update_warehouse_task_external_interface_status(String system_id, String task_id, String status) throws Exception {
       MySQLDB db = new MySQLDB();
       db.connect();
       String sql = "update t_warehouse_task t1 set t1.external_interface_status =  ? "
              
               + " where t1.system_id = ? AND t1.task_id = ?";
       db.createPrepareStatement(sql);
       db.bindValue(1,status);
       db.bindValue(2,system_id);
       db.bindValue(3, task_id);
       db.executeUpdate();
       db.disconnect();
    }
    
    private boolean checkAllowTask(String task_type){
        for(int i = 0;i < task_type_list.size();i++){
            Hashtable map = (Hashtable)task_type_list.get(i);
            if(map.get("task_type_name").equals(task_type)){
                return true;
            }
        }
        return false;
    }
    
}
