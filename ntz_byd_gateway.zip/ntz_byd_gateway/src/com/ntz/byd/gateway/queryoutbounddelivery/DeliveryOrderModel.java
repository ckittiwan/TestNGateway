/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ntz.byd.gateway.queryoutbounddelivery;

import java.util.ArrayList;

/**
 *
 * @author NTZ_Admin
 */
public class DeliveryOrderModel {
    public String system_id;
    public String delivery_order_id;
    public String delivery_order_uuid;
    public String gmt0_shipping_datetime = null;
    public String gmt0_arrival_datetime = null;
    public String shipto_tel_no1 = "";
    public String shipto_tel_no2 = "";
    public String shipto_name = "";
    public String shipto_address_line1 = "";
    public String shipto_address_line2 = "";
    public String shipto_address_line3 = "";
    public String shipto_address_line4 = "";
    public String shipto_org_name = "";
    public String shipfrom_tel_no1 = "";
    public String shipfrom_tel_no2 = "";
    public String shipfrom_name = "";
    public String shipfrom_address_line1 = "";
    public String shipfrom_address_line2 = "";
    public String shipfrom_address_line3 = "";
    public String shipfrom_address_line4 = "";
    public String shipfrom_org_name = "";
    public String shipfrom_location_id = "";
    public String external_interface_status = "W";
    
    
    public String release_status_code = "";
    public String cancel_status_code = "";
    
    ArrayList<DeliveryOrderItemModel> items = new ArrayList<DeliveryOrderItemModel>();
   // public String external_interface_error_msg = "";
  //  public String external_interface_datetime = null;
   // public String create_datetime;
    
    
    
    public String recipient_party_id = "";
    public String sender_party_id = "";

}
