/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ntz.byd.gateway.queryoutbounddelivery;

import com.ntz.byd.gateway.XConfig;
import com.ntz.byd.gateway.db.MySQLDB;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 *
 * @author NTZ_Admin
 */
public class QueryOutboundDeliveryProcessor {
      public static void _start() throws Exception 
      {
            ExecutorService executorService = Executors.newFixedThreadPool(XConfig.thread_size);
            ArrayList tenant_list = get_available_tenant();
            System.out.println(tenant_list);
            for(int i = 0 ; i < tenant_list.size(); i++)
            {
                QueryOutboundDeliveryRunner task = new QueryOutboundDeliveryRunner((Hashtable) tenant_list.get(i));
                executorService.submit(task);
            }

            executorService.shutdown();
      
      
      }
      
      
    public static ArrayList get_available_tenant() throws Exception
    {
        MySQLDB db = new MySQLDB();
        db.connect();
        
        String sql = "select t1.*,t3.service_url_path,t2.callback_url,t2.callback_username,t2.callback_password,t2.callback_apikey  from m_sap_byd_system t1 "
                + " INNER JOIN m_system_service_mapping t2 ON t1.system_id = t2.system_id"
                + " INNER JOIN m_byd_service t3 ON t2.service_id = t3.service_id"
                + " where t3.service_code = 'QUERY_OUTBOUND_DELIVERY' "
                + " AND t2.status = 'Y' "
                + " AND t1.status = 'Y'"
                + " AND NOW() between t1.valid_from AND t1.valid_to";
        
        db.createPrepareStatement(sql);
        ResultSet res = db.executeQuery();
        ArrayList _list = db.buildList(res);
        db.disconnect();
        
        return _list;
        
    }
      
}
