/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ntz.byd.gateway.queryoutbounddelivery;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.ntz.byd.gateway.EmailSender;
import com.ntz.byd.gateway.ExternalRestCaller;
import com.ntz.byd.gateway.db.MySQLDB;
import com.ntz.byd.gateway.queryoutbounddelivery.manage.autogen.CopyOfOutboundDeliveryByIDResponseItem;
import com.ntz.byd.gateway.queryoutbounddelivery.manage.autogen.CopyOfOutboundDeliveryByIDResponseItemProductSerialID;
import com.ntz.byd.gateway.queryoutbounddelivery.manage.autogen.CopyOfUUID;
import com.ntz.byd.gateway.queryoutbounddelivery.manage.autogen.ODByIDQuery;
import com.ntz.byd.gateway.queryoutbounddelivery.manage.autogen.ODByIDResponse;
import com.ntz.byd.gateway.queryoutbounddelivery.manage.autogen.ODByIDResponseMessageSync;
import com.ntz.byd.gateway.queryoutbounddelivery.manage.autogen.ODByUUIDQuerySync;
import com.ntz.byd.gateway.queryoutbounddelivery.manage.autogen.OutboundDeliveryByIDResponseMaterial;
import com.ntz.byd.gateway.queryoutbounddelivery.query.autogen.Code;
import com.ntz.byd.gateway.queryoutbounddelivery.query.autogen.DateTime;
import com.ntz.byd.gateway.queryoutbounddelivery.query.autogen.OutboundDeliveryFindByElementsMessage;
import com.ntz.byd.gateway.queryoutbounddelivery.query.autogen.OutboundDeliveryFindByElementsRequestMessage;
import com.ntz.byd.gateway.queryoutbounddelivery.query.autogen.OutboundDeliveryFindByElementsResponseMessage;
import com.ntz.byd.gateway.queryoutbounddelivery.query.autogen.QueryProcessingConditions;
import com.ntz.byd.gateway.queryoutbounddelivery.query.autogen.SelectionByCode;
import com.ntz.byd.gateway.queryoutbounddelivery.query.autogen.SelectionByDateTime;
import com.ntz.byd.gateway.queryoutbounddelivery.query.autogen.StandardFaultMessage_Exception;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Hashtable;
import java.util.TimeZone;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.ws.BindingProvider;

/**
 *
 * @author NTZ_Admin
 */
public class QueryOutboundDeliveryRunner implements Runnable{
    private Hashtable _systemht = null;
    
    private PreparedStatement statementInsertOrder = null;
    private PreparedStatement statementInsertOrderItems = null;
    private PreparedStatement statementInsertOrderItemsSerial = null;
    
    public QueryOutboundDeliveryRunner(Hashtable hashtable) {
       _systemht = hashtable;
    }

    
    
    @Override
    public void run() {
        try {
            ArrayList<Hashtable<String, String>> tzList = get_timezone_list();
            Hashtable _query_period = get_query_period();
            OutboundDeliveryFindByElementsMessage reqQuery = composeQueryMessage(tzList,_query_period);
            OutboundDeliveryFindByElementsResponseMessage respQuery = findByElements(reqQuery);
            if(respQuery.getOutboundDelivery().size() == 0)
            {
                return;
            }
            
            ODByUUIDQuerySync reqRead = composeReadMessage(respQuery);
            ODByIDResponseMessageSync respRead = read(reqRead);
            insertInToDB(respRead);
            
            
        } catch (Exception ex) {
            StringWriter sw = new StringWriter();
            ex.printStackTrace(new PrintWriter(sw));
            String exceptionAsString = sw.toString();
            System.out.println(exceptionAsString);
            
            EmailSender.sendFromGMail("nGateway Error - Query Outbound Delivery", exceptionAsString);
            Logger.getLogger(QueryOutboundDeliveryRunner.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private ArrayList get_timezone_list() throws Exception {
         MySQLDB db = new MySQLDB();
         db.connect();
         String sql = "select * from t_delivery_order_config_timezone_code where system_id = ? AND status = 'Y' ";
         db.createPrepareStatement(sql);
         db.bindValue(1, (String) this._systemht.get("system_id"));
         ResultSet res = db.executeQuery();
         
         ArrayList list = db.buildList(res);

         db.disconnect();
         return list;
    }
    
     private Hashtable get_query_period() throws Exception {
         MySQLDB db = new MySQLDB();
         db.connect();
         String sql = "select * from t_delivery_order_config_query_period where system_id = ?";
         db.createPrepareStatement(sql);
         db.bindValue(1, (String) this._systemht.get("system_id"));
         ResultSet res = db.executeQuery();
         
         ArrayList list = db.buildList(res);
         db.disconnect();
         
         Hashtable ht = null;
         if(list.size() == 0)
         {
             ht = new Hashtable();
             ht.put("system_id", this._systemht.get("system_id"));
             ht.put("date_backward", "0");
             ht.put("date_forward", "0");
         }
         else
         {
             ht = (Hashtable) list.get(0);
         }
         
         
         return ht;
    }
    
    
    
    public OutboundDeliveryFindByElementsMessage composeQueryMessage(ArrayList<Hashtable<String, String>> tzList, Hashtable<String, String> qpr) throws DatatypeConfigurationException
    {
        int date_backward = Integer.parseInt(qpr.get("date_backward"));
        int date_forward = Integer.parseInt(qpr.get("date_forward"));
        
        Date curr_date = new Date();
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        df.setTimeZone(TimeZone.getTimeZone("GMT"));
        
        Calendar c1 = Calendar.getInstance(); 
        c1.setTime(curr_date); 
        c1.add(Calendar.DATE, - date_backward);
        
        Calendar c2 = Calendar.getInstance(); 
        c2.setTime(curr_date); 
        c2.add(Calendar.DATE,  date_forward);
        
        
        Date startDate = c1.getTime();
        Date endDate = c2.getTime();
       
        
        OutboundDeliveryFindByElementsMessage request = new OutboundDeliveryFindByElementsMessage();
        request.setOutboundDeliveryFindByElementsRequestMessageBody(new OutboundDeliveryFindByElementsRequestMessage());
        
        
        for(int i = 0 ; i < tzList.size() ; i++)
        {
            SelectionByDateTime sel_date = new SelectionByDateTime();
            sel_date.setInclusionExclusionCode("I");
            sel_date.setIntervalBoundaryTypeCode("3");
            sel_date.setLowerBoundaryDateTime(new DateTime());
            sel_date.getLowerBoundaryDateTime().setValue(DatatypeFactory.newInstance().newXMLGregorianCalendar(df.format(startDate)+"T00:00:00Z"));
            sel_date.getLowerBoundaryDateTime().setTimeZoneCode(tzList.get(i).get("timezone_code"));
            sel_date.setUpperBoundaryDateTime(new DateTime());
            sel_date.getUpperBoundaryDateTime().setValue(DatatypeFactory.newInstance().newXMLGregorianCalendar(df.format(endDate)+"T23:59:59Z"));
             sel_date.getUpperBoundaryDateTime().setTimeZoneCode(tzList.get(i).get("timezone_code"));
            request.getOutboundDeliveryFindByElementsRequestMessageBody().getSelectionByDateShippingDateTime().add(sel_date);
        }
        
        
        SelectionByCode sel_code = new SelectionByCode();
        sel_code.setInclusionExclusionCode("I");
        sel_code.setIntervalBoundaryTypeCode("1");
        sel_code.setLowerBoundaryCode(new Code());
        sel_code.getLowerBoundaryCode().setValue("3");
        request.getOutboundDeliveryFindByElementsRequestMessageBody().getSelectionByReleaseStatusCode().add(sel_code);
        //request.getOutboundDeliveryFindByElementsRequestMessageBody().getSelectionByConsistencyStatusCode().add(sel_code);
        
        
        request.setProcessingConditions(new QueryProcessingConditions());
        request.getProcessingConditions().setQueryHitsUnlimitedIndicator(true);
        request.getProcessingConditions().setQueryHitsMaximumNumberValue(new Integer(1000));
        
        
        return request;
    }
    
    
    public ODByUUIDQuerySync composeReadMessage(OutboundDeliveryFindByElementsResponseMessage uuidList)
    {
        ODByUUIDQuerySync request = new ODByUUIDQuerySync();
        request.setOutboundDelivery(new ODByIDQuery());
        for(int i = 0 ; i < uuidList.getOutboundDelivery().size() ; i++)
        {
             CopyOfUUID do_uuid = new CopyOfUUID();
             do_uuid.setValue(uuidList.getOutboundDelivery().get(i).getOutboundDeliveryUUID().getValue());
             request.getOutboundDelivery().getUUID().add(do_uuid);
        }
        return request;
    }

    private  OutboundDeliveryFindByElementsResponseMessage findByElements(com.ntz.byd.gateway.queryoutbounddelivery.query.autogen.OutboundDeliveryFindByElementsMessage outboundDeliveryFindByElementsQuerySync) throws StandardFaultMessage_Exception {
        com.ntz.byd.gateway.queryoutbounddelivery.query.autogen.Service service = new com.ntz.byd.gateway.queryoutbounddelivery.query.autogen.Service();
        com.ntz.byd.gateway.queryoutbounddelivery.query.autogen.QueryOutboundDeliveryIn port = service.getBinding();
        BindingProvider provider = (BindingProvider) port;
        provider.getRequestContext().put(BindingProvider.USERNAME_PROPERTY, this._systemht.get("system_ws_username"));
        provider.getRequestContext().put(BindingProvider.PASSWORD_PROPERTY, this._systemht.get("system_ws_password"));
        provider.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, this._systemht.get("system_url").toString() + this._systemht.get("service_url_path").toString());
        return port.findByElements(outboundDeliveryFindByElementsQuerySync);
    }
    
    
    

    private  ODByIDResponseMessageSync read(com.ntz.byd.gateway.queryoutbounddelivery.manage.autogen.ODByUUIDQuerySync odByIDQuerySync) throws com.ntz.byd.gateway.queryoutbounddelivery.manage.autogen.StandardFaultMessage_Exception {
        com.ntz.byd.gateway.queryoutbounddelivery.manage.autogen.Service service = new com.ntz.byd.gateway.queryoutbounddelivery.manage.autogen.Service();
        com.ntz.byd.gateway.queryoutbounddelivery.manage.autogen.ManageODIn port = service.getBinding();
        BindingProvider provider = (BindingProvider) port;
        provider.getRequestContext().put(BindingProvider.USERNAME_PROPERTY, this._systemht.get("system_ws_username"));
        provider.getRequestContext().put(BindingProvider.PASSWORD_PROPERTY, this._systemht.get("system_ws_password"));
        provider.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, this._systemht.get("system_url").toString() + "/sap/bc/srt/scs/sap/manageodin");
        return port.read(odByIDQuerySync);
    }

    private void insertInToDB(ODByIDResponseMessageSync respRead) throws SQLException, Exception {
        ArrayList<DeliveryOrderModel> do_list = new  ArrayList<DeliveryOrderModel>();
        for(int i = 0 ; i < respRead.getOutboundDelivery().size(); i++ )
        {
            DeliveryOrderModel doModel = new DeliveryOrderModel();
            do_list.add(doModel);
            ODByIDResponse doObj = respRead.getOutboundDelivery().get(i);
            
            doModel.system_id = (String) this._systemht.get("system_id");
            doModel.delivery_order_id = doObj.getID().getValue();
            doModel.delivery_order_uuid = doObj.getUUID().getValue();
            if( doObj.getShippingPeriod() != null)
                doModel.gmt0_shipping_datetime =  doObj.getShippingPeriod().getDateTimePeriod().getStartDateTime().getValue().toString().replaceFirst("T", " ").replaceFirst("Z", "");
            
            if(doObj.getArrivalPeriod() != null)
                doModel.gmt0_arrival_datetime = doObj.getArrivalPeriod().getDateTimePeriod().getStartDateTime().getValue().toString().replaceFirst("T", " ").replaceFirst("Z", "");
            
            if(doObj.getShipToLocation().getUsedAddress().getFacsimile().size() > 0)
            {
                doModel.shipto_tel_no1 =  doObj.getShipToLocation().getUsedAddress().getFacsimile().get(0).getFormattedNumberDescription();
                doModel.shipto_tel_no2 =  doObj.getShipToLocation().getUsedAddress().getFacsimile().get(0).getNormalisedNumberDescription();
            }
            doModel.shipto_name = doObj.getShipToLocation().getUsedAddress().getFormattedAddress().getFormattedName();
            doModel.shipto_address_line1 = doObj.getShipToLocation().getUsedAddress().getFormattedAddress().getFormattedAddress().getFirstLineDescription();
            doModel.shipto_address_line2 = doObj.getShipToLocation().getUsedAddress().getFormattedAddress().getFormattedAddress().getSecondLineDescription();
            doModel.shipto_address_line3 = doObj.getShipToLocation().getUsedAddress().getFormattedAddress().getFormattedAddress().getThirdLineDescription();
            doModel.shipto_address_line4 = doObj.getShipToLocation().getUsedAddress().getFormattedAddress().getFormattedAddress().getFourthLineDescription();
            if(doObj.getShipToLocation().getUsedAddress().getOrganisationName().size() > 0)
            {
                doModel.shipto_org_name =  doObj.getShipToLocation().getUsedAddress().getOrganisationName().get(0).getFormattedName();
            }
            
            
            if(doObj.getShipFromLocation().getUsedAddress().getFacsimile().size() > 0)
            {
                doModel.shipfrom_tel_no1 =  doObj.getShipFromLocation().getUsedAddress().getFacsimile().get(0).getFormattedNumberDescription();
                doModel.shipfrom_tel_no2 =  doObj.getShipFromLocation().getUsedAddress().getFacsimile().get(0).getNormalisedNumberDescription();
            }
            doModel.shipfrom_name = doObj.getShipFromLocation().getUsedAddress().getFormattedAddress().getFormattedName();
            doModel.shipfrom_address_line1 = doObj.getShipFromLocation().getUsedAddress().getFormattedAddress().getFormattedAddress().getFirstLineDescription();
            doModel.shipfrom_address_line2 = doObj.getShipFromLocation().getUsedAddress().getFormattedAddress().getFormattedAddress().getSecondLineDescription();
            doModel.shipfrom_address_line3 = doObj.getShipFromLocation().getUsedAddress().getFormattedAddress().getFormattedAddress().getThirdLineDescription();
            doModel.shipfrom_address_line4 = doObj.getShipFromLocation().getUsedAddress().getFormattedAddress().getFormattedAddress().getFourthLineDescription();
            if(doObj.getShipFromLocation().getUsedAddress().getOrganisationName().size() > 0)
            {
                doModel.shipfrom_org_name =  doObj.getShipFromLocation().getUsedAddress().getOrganisationName().get(0).getFormattedName();
            }
            doModel.shipfrom_location_id =  doObj.getShipFromLocation().getLocationID().getValue();
            
            
            doModel.external_interface_status = "W";
            
            //Add recipient party id, sender party id
            doModel.recipient_party_id = doObj.getProductRecipientParty().getPartyKey().getPartyID().getValue();
            doModel.sender_party_id = doObj.getVendorParty().getPartyKey().getPartyID().getValue();
            
            doModel.release_status_code = doObj.getStatus().getReleaseStatusCode();
            doModel.cancel_status_code = doObj.getStatus().getCancellationStatusCode();
            
            
            
            ArrayList _tmp_list2 = getExistingDeliveryOrder(doModel.delivery_order_id, doModel.system_id);
            if(_tmp_list2.size() > 0) //Already Exists, No need to fetch items
            {
                continue;
            }
            //For thaiKK get item data from OData 
            /*
            if(this._systemht.get("system_aliasname").equals("THAIKK-TEST") || this._systemht.get("system_aliasname").equals("THAIKK-PRD"))
            {
                get_items_from_odata(doModel);
                continue;
            }
            */
            
            int line_item_id = 1;
            for(int j = 0 ; j < doObj.getItem().size(); j++)
            {
                CopyOfOutboundDeliveryByIDResponseItem itObj = doObj.getItem().get(j);
                
                for(int k = 0 ; k < itObj.getDetailedItem().size() ; k++)
                {
                    OutboundDeliveryByIDResponseMaterial detailItem = itObj.getDetailedItem().get(k);
                    
                    DeliveryOrderItemModel itModel = new DeliveryOrderItemModel();
                    itModel.system_id = doModel.system_id;
                    itModel.delivery_order_id = doModel.delivery_order_id;
                    itModel.delivery_order_uuid = doModel.delivery_order_uuid;
                    itModel.item_uuid = itObj.getUUID().getValue();
                    itModel.line_item_id = (line_item_id * 10)+"";
                    itModel.product_id = itObj.getProduct().getProductKey().getProductID().getValue();
                    itModel.product_desc = itObj.getProduct().getMaterialOverview().getDescription();
                    itModel.quantity = detailItem.getDeliveryQuantity().getQuantity().getValue().doubleValue();
                    itModel.unit_code = detailItem.getDeliveryQuantity().getQuantity().getUnitCode();


                    if(detailItem.getIdentifiedStockID() != null)
                    {
                        itModel.identified_stock_id = detailItem.getIdentifiedStockID().getValue();
                    }

                    doModel.items.add(itModel);
                    line_item_id++;
                }

                /*
                for(int z = 0; z < itObj.getProduct().getItemProductSerialID().size(); z++)
                {
                    CopyOfOutboundDeliveryByIDResponseItemProductSerialID itSerial = itObj.getProduct().getItemProductSerialID().get(z);
                    
                    DeliveryOrderItemSerialModel serialModel = new DeliveryOrderItemSerialModel();
                    serialModel.system_id = doModel.system_id;
                    serialModel.delivery_order_id = doModel.delivery_order_id;
                    serialModel.delivery_order_uuid = doModel.delivery_order_uuid;
                    serialModel.item_uuid = itModel.item_uuid;
                    serialModel.serial_id = itSerial.getSerialID();
                    itModel.seirals.add(serialModel);
                }
                
                doModel.items.add(itModel);
                */
            }
        
        }
        
        
        //LOOP INSERT HEERE
        MySQLDB db = new MySQLDB();
        db.connect();
        statementInsertOrder = db.conn.prepareStatement(getSQLInsertOrderTemplate());
        statementInsertOrderItems = db.conn.prepareStatement(getSQLInsertOrderItemTemplate());
        statementInsertOrderItemsSerial = db.conn.prepareStatement(getSQLInsertOrderItemSerialTemplate());
        for(int i = 0 ; i < do_list.size(); i++)
        {
            DeliveryOrderModel doModel = do_list.get(i);
            
            ArrayList _tmp_list = getExistingDeliveryOrder(doModel.delivery_order_id, doModel.system_id);
            if(_tmp_list.size() == 0) //Not Exists
            {
                statementInsertOrder.setString(1, doModel.system_id);
                statementInsertOrder.setString(2, doModel.delivery_order_id);
                statementInsertOrder.setString(3, doModel.delivery_order_uuid);
                statementInsertOrder.setString(4, doModel.gmt0_shipping_datetime);
                statementInsertOrder.setString(5, doModel.gmt0_arrival_datetime);
                statementInsertOrder.setString(6, doModel.shipto_tel_no1);
                statementInsertOrder.setString(7, doModel.shipto_tel_no2);
                statementInsertOrder.setString(8, doModel.shipto_name);
                statementInsertOrder.setString(9, doModel.shipto_address_line1);
                statementInsertOrder.setString(10, doModel.shipto_address_line2);
                statementInsertOrder.setString(11, doModel.shipto_address_line3);
                statementInsertOrder.setString(12, doModel.shipto_address_line4);
                statementInsertOrder.setString(13, doModel.shipto_org_name);
                statementInsertOrder.setString(14, doModel.shipfrom_tel_no1);
                statementInsertOrder.setString(15, doModel.shipfrom_tel_no2);
                statementInsertOrder.setString(16, doModel.shipfrom_name);
                statementInsertOrder.setString(17, doModel.shipfrom_address_line1);
                statementInsertOrder.setString(18, doModel.shipfrom_address_line2);
                statementInsertOrder.setString(19, doModel.shipfrom_address_line3);
                statementInsertOrder.setString(20, doModel.shipfrom_address_line4);
                statementInsertOrder.setString(21, doModel.shipfrom_org_name);
                statementInsertOrder.setString(22, doModel.shipfrom_location_id);
                statementInsertOrder.setString(23, doModel.external_interface_status);
                statementInsertOrder.setString(24, doModel.release_status_code);
                statementInsertOrder.setString(25, doModel.cancel_status_code);
                statementInsertOrder.setString(26, doModel.recipient_party_id);
                statementInsertOrder.setString(27, doModel.sender_party_id);

                statementInsertOrder.executeUpdate();

                for(int j = 0 ; j < doModel.items.size() ; j++)
                {
                    DeliveryOrderItemModel itModel = doModel.items.get(j);
                    statementInsertOrderItems.setString(1, itModel.system_id);
                    statementInsertOrderItems.setString(2, itModel.delivery_order_id);
                    statementInsertOrderItems.setString(3, itModel.delivery_order_uuid);
                    statementInsertOrderItems.setString(4, itModel.item_uuid);
                    statementInsertOrderItems.setString(5, itModel.line_item_id);
                    statementInsertOrderItems.setString(6, itModel.product_id);
                    statementInsertOrderItems.setString(7, itModel.product_desc);
                    statementInsertOrderItems.setString(8, itModel.identified_stock_id);
                    statementInsertOrderItems.setDouble(9, itModel.quantity);
                    statementInsertOrderItems.setString(10, itModel.unit_code);
                    statementInsertOrderItems.executeUpdate();
                    
                    //serial insert
                    for(int z = 0 ; z < itModel.seirals.size(); z++)
                    {
                        DeliveryOrderItemSerialModel serialModel = itModel.seirals.get(z);
                        statementInsertOrderItemsSerial.setString(1, serialModel.system_id);
                        statementInsertOrderItemsSerial.setString(2, serialModel.delivery_order_id);
                        statementInsertOrderItemsSerial.setString(3, serialModel.delivery_order_uuid);
                        statementInsertOrderItemsSerial.setString(4, serialModel.item_uuid);
                        statementInsertOrderItemsSerial.setString(5, serialModel.serial_id);
                        statementInsertOrderItemsSerial.executeUpdate();
                    }
                    
                }
            
            }
            else //Delivery Order already exists in gateway database
            {
                System.out.println("Already Exist Delivery Order : " + doModel.delivery_order_id + ", System ID : " + doModel.system_id);
                Hashtable<String, String> _ht_exist_do  =  (Hashtable) _tmp_list.get(0);
                if(!doModel.release_status_code.equals(_ht_exist_do.get("release_status_code")) || 
                        !doModel.cancel_status_code.equals(_ht_exist_do.get("cancel_status_code")))
                {
                    //Something changed, need to update and send to external system
                    System.out.println("Status Changed Delivery Order : " + doModel.delivery_order_id);
                    update_exist_delivery_order(doModel);
                }
            
            }
            
           
        }
        db.disconnect();
        
        
        //send_to_external system
        send_to_external_callback_system();
    }
    
    public String getSQLInsertOrderTemplate()
    {
        StringBuilder sb = new StringBuilder();
        sb.append("insert into t_delivery_order(");
        sb.append("system_id,");//1
        sb.append("delivery_order_id,");//2
        sb.append("delivery_order_uuid,");//3
        sb.append("gmt0_shipping_datetime,");//4
        sb.append("gmt0_arrival_datetime,");//5
        sb.append("shipto_tel_no1,");//6
        sb.append("shipto_tel_no2,");//7
        sb.append("shipto_name,");//8
        sb.append("shipto_address_line1,");//9
        sb.append("shipto_address_line2,");//10
        sb.append("shipto_address_line3,");//11
        sb.append("shipto_address_line4,");//12
        sb.append("shipto_org_name,");//13
        sb.append("shipfrom_tel_no1,");//14
        sb.append("shipfrom_tel_no2,");//15
        sb.append("shipfrom_name,");//16
        sb.append("shipfrom_address_line1,");//17
        sb.append("shipfrom_address_line2,");//18
        sb.append("shipfrom_address_line3,");//19
        sb.append("shipfrom_address_line4,");//20
        sb.append("shipfrom_org_name,");//21
        sb.append("shipfrom_location_id,");//22
        sb.append("external_interface_status,");//23
        sb.append("release_status_code,");//24
        sb.append("cancel_status_code,");//25
        sb.append("recipient_party_id,");//26
        sb.append("sender_party_id,");//27
        sb.append("create_datetime,external_interface_error_msg)VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,NOW(),'')");
        return sb.toString();

    }
    
    public String getSQLInsertOrderItemTemplate()
    {
        StringBuilder sb = new StringBuilder();
        sb.append("insert into t_delivery_order_items(");
        sb.append("system_id,");//1
        sb.append("delivery_order_id,");//2
        sb.append("delivery_order_uuid,");//3
        sb.append("item_uuid,");//4
        sb.append("line_item_id,");//5
        sb.append("product_id,");//6
        sb.append("product_desc,");//7
        sb.append("identified_stock_id,");//8
        sb.append("quantity,");//9
        sb.append("unit_code,");//10
        sb.append("create_datetime)");
        sb.append("VALUES(?,?,?,?,?,?,?,?,?,?,NOW())");
        return sb.toString();
    }
    
    
    public String getSQLInsertOrderItemSerialTemplate()
    {
        StringBuilder sb = new StringBuilder();
        sb.append("insert into t_delivery_order_items_serial(");
        sb.append("system_id,");//1
        sb.append("delivery_order_id,");//2
        sb.append("delivery_order_uuid,");//3
        sb.append("item_uuid,");//4
        sb.append("serial_id,");//5 
        sb.append("create_datetime)");
        sb.append("VALUES(?,?,?,?,?,NOW())");
        return sb.toString();
    }

    
    //=============================================== Send to external system
    private void send_to_external_callback_system() throws Exception {
        if( this._systemht.get("callback_url").toString().equals(""))
        {
            return;
        }
        
        MySQLDB db = new MySQLDB();
        db.connect();
        String sql = "select t1.*,t2.release_status_desc,t3.cancel_status_desc from t_delivery_order t1  "
                + " INNER JOIN m_release_status_code t2 ON t1.release_status_code = t2.release_status_code"
                + "  INNER JOIN m_cancel_status_code t3 ON t1.cancel_status_code = t3.cancel_status_code where t1.system_id = ? AND t1.external_interface_status in ('W','E')";
        db.createPrepareStatement(sql);
        db.bindValue(1, (String) this._systemht.get("system_id"));
        
        ResultSet res = db.executeQuery();
        ArrayList do_list = db.buildList(res);
        db.disconnect();
        
        if(do_list.size() == 0) return;
        
        
        ArrayList list_json = new ArrayList();
        for(int i = 0 ; i < do_list.size() ;i++)
        {
            Hashtable<String, String> h = (Hashtable) do_list.get(i);
            Hashtable ht = new Hashtable();
            ht.put("delivery_order_id", h.get("delivery_order_id"));
            ht.put("gmt0_shipping_datetime", h.get("gmt0_shipping_datetime"));
            ht.put("gmt0_arrival_datetime", h.get("gmt0_arrival_datetime"));
            ht.put("recipient_party_id", h.get("recipient_party_id"));
            ht.put("sender_party_id", h.get("sender_party_id"));
            ht.put("shipto_tel_no1", h.get("shipto_tel_no1"));
            ht.put("shipto_tel_no2", h.get("shipto_tel_no2"));
            ht.put("shipto_name", h.get("shipto_name"));
            ht.put("shipto_address_line1", h.get("shipto_address_line1"));
            ht.put("shipto_address_line2", h.get("shipto_address_line2"));
            ht.put("shipto_address_line3", h.get("shipto_address_line3"));
            ht.put("shipto_address_line4", h.get("shipto_address_line4"));
            ht.put("shipto_org_name", h.get("shipto_org_name"));
            
            ht.put("shipfrom_tel_no1", h.get("shipfrom_tel_no1"));
            ht.put("shipto_tel_no2", h.get("shipto_tel_no2"));
            ht.put("shipfrom_name", h.get("shipfrom_name"));
            ht.put("shipfrom_address_line1", h.get("shipfrom_address_line1"));
            ht.put("shipfrom_address_line2", h.get("shipfrom_address_line2"));
            ht.put("shipfrom_address_line3", h.get("shipfrom_address_line3"));
            ht.put("shipfrom_address_line4", h.get("shipfrom_address_line4"));
            ht.put("shipfrom_org_name", h.get("shipfrom_org_name"));
            ht.put("shipfrom_location_id", h.get("shipfrom_location_id"));
            ht.put("release_status", h.get("release_status_code"));
            ht.put("release_status_desc", h.get("release_status_desc"));
            ht.put("cancel_status", h.get("cancel_status_code"));
            ht.put("cancel_status_desc", h.get("cancel_status_desc"));
            
            ht.put("items",get_items(h.get("system_id"),h.get("delivery_order_id"),h.get("delivery_order_uuid")));
            
            list_json.add(ht);
        }
        
        
        Gson gson = new Gson();
        String dataSent = gson.toJson(list_json);
        System.out.println(dataSent);
       
        String results[] = null;
      
        results =  ExternalRestCaller.call(
                (String) this._systemht.get("callback_url"), 
                (String) this._systemht.get("callback_apikey"), 
                (String) this._systemht.get("callback_username"), 
                (String) this._systemht.get("callback_password"), 
                ExternalRestCaller.METHOD_POST, 
                dataSent);
      
      
       
       if(results[0].equals("200"))//OK
       {
           update_external_callback_status(do_list,"S");
       }
       else //Fail
       {
           update_external_callback_status(do_list,"E");
       }
    }
    
    
    
    public ArrayList get_items(String system_id, String delivery_order_id, String delivery_order_uuid) throws Exception
    {
        MySQLDB db = new MySQLDB();
        db.connect();
        String sql = "select line_item_id,product_id,product_desc,identified_stock_id,quantity,unit_code,item_uuid from t_delivery_order_items where system_id = ? AND delivery_order_id = ? AND delivery_order_uuid = ? order by line_item_id";
        db.createPrepareStatement(sql);
        db.bindValue(1, system_id);
        db.bindValue(2, delivery_order_id);
        db.bindValue(3, delivery_order_uuid);
        
        ResultSet res = db.executeQuery();
        ArrayList list = db.buildList(res);
        
        db.disconnect();
        
        for(int i = 0 ; i < list.size() ; i ++)
        {
            Hashtable ht = (Hashtable) list.get(i);
            ht.put("serials", get_items_serial(system_id,delivery_order_id,delivery_order_uuid, (String) ht.get("item_uuid")));
        }
        
        
        return list;
    }
    
    
    public String[] get_items_serial(String system_id, String delivery_order_id, String delivery_order_uuid, String item_uuid) throws Exception
    {
        MySQLDB db = new MySQLDB();
        db.connect();
        String sql = "select serial_id from t_delivery_order_items_serial where system_id = ? AND delivery_order_id = ? AND delivery_order_uuid = ? AND item_uuid = ? ";
        db.createPrepareStatement(sql);
        db.bindValue(1, system_id);
        db.bindValue(2, delivery_order_id);
        db.bindValue(3, delivery_order_uuid);
        db.bindValue(4, item_uuid);
        
        ResultSet res = db.executeQuery();
        ArrayList<Hashtable<String, String>> list = db.buildList(res);
        
        db.disconnect();
        String ret[] = new String[list.size()];
        for(int i = 0 ; i < list.size() ; i++)
        {
            ret[i] = list.get(i).get("serial_id");
        }
        
        
        return ret;
    }
    
    
    
     private void update_external_callback_status(ArrayList do_list, String status) throws Exception {
        MySQLDB db = new MySQLDB();
        db.connect();
        String sql = "UPDATE t_delivery_order set external_interface_status = ? , external_interface_datetime = NOW() where system_id = ? AND delivery_order_id = ? AND delivery_order_uuid = ? ";
        db.createPrepareStatement(sql);
        db.bindValue(1, status);
        db.bindValue(2, (String) this._systemht.get("system_id"));
        for(int i = 0 ; i < do_list.size(); i++)
        {
            Hashtable<String, String> ht = (Hashtable<String, String>) do_list.get(i);       
            db.bindValue(3, ht.get("delivery_order_id"));
            db.bindValue(4, ht.get("delivery_order_uuid"));
            db.executeUpdate();
        }
        db.disconnect();
    }
     
     
     
     
     private ArrayList getExistingDeliveryOrder(String delivery_order_id,String system_id) throws Exception
     {
        MySQLDB db = new MySQLDB();
        db.connect();
        String sql = "select * from t_delivery_order where system_id = ? AND delivery_order_id = ? ";
        db.createPrepareStatement(sql);
        db.bindValue(1, system_id);
        db.bindValue(2, delivery_order_id);
        ResultSet res = db.executeQuery();
        ArrayList list = db.buildList(res);
        db.disconnect();
        
        
        return list;
         
     } 

    private void update_exist_delivery_order(DeliveryOrderModel doModel) throws Exception {
        MySQLDB db = new MySQLDB();
        db.connect();
        String sql = "UPDATE t_delivery_order set external_interface_status = 'W' , release_status_code = ? , cancel_status_code = ?  where system_id = ? AND delivery_order_id = ? AND delivery_order_uuid = ? ";
        db.createPrepareStatement(sql);
        db.bindValue(1, doModel.release_status_code);
        db.bindValue(2,  doModel.cancel_status_code);
        db.bindValue(3, doModel.system_id);
        db.bindValue(4, doModel.delivery_order_id);
        db.bindValue(5, doModel.delivery_order_uuid);
        db.executeUpdate();
        db.disconnect();
    }
    
    
    
   /*
    //========================================== THAI KK
    public void get_items_from_odata(DeliveryOrderModel doModel) throws IOException {
        System.out.println("System_id : "+this._systemht.get("system_id")+" Call ODATA for Delivery Order ID : " + doModel.delivery_order_id);
        String url = "";
        String user = "";
        String pass = "";
        
        Gson gson = new Gson();
        if(this._systemht.get("system_aliasname").equals("THAIKK-TEST"))
        {
            url = "https://my344270.sapbydesign.com/sap/byd/odata/cust/v1/ntz_query_outbound_delivery_item/OutboundDeliveryCollection?$format=json&$filter=ID+eq+'"+doModel.delivery_order_id+"'";
            user = "Interface";
            pass = "Password11";
        }
        else //PRD
        {
            url = "https://my345967.sapbydesign.com/sap/byd/odata/cust/v1/ntz_query_outbound_delivery_item/OutboundDeliveryCollection?$format=json&$filter=ID+eq+'"+doModel.delivery_order_id+"'";
            user = "Interface";
            pass = "Password12";
        }
       
       
        String[] do_results =  ExternalRestCaller.call(url,"",user, pass, ExternalRestCaller.METHOD_GET, "");
        JsonObject do_element = gson.fromJson(do_results[1], JsonObject.class );
        
        String item_url = do_element.getAsJsonObject("d").getAsJsonArray("results").get(0).getAsJsonObject().getAsJsonObject("OutboundDeliveryMaterial").getAsJsonObject("__deferred").getAsJsonPrimitive("uri").getAsString();
        String[] item_results =  ExternalRestCaller.call(item_url+"?$format=json","",user, pass, ExternalRestCaller.METHOD_GET, "");
        
        JsonObject item_elements = gson.fromJson(item_results[1], JsonObject.class );
        JsonArray item_array = item_elements.getAsJsonObject("d").getAsJsonArray("results");        
        for(int i =0; i < item_array.size(); i ++)
        {
            
            
            
            JsonObject item_object = item_array.get(i).getAsJsonObject();
            String _item_uuid =  item_object.getAsJsonPrimitive("ItemUUID").getAsString();
            String _product_id = item_object.getAsJsonPrimitive("ProductID").getAsString();
            String _identified_stock = item_object.getAsJsonPrimitive("IdentifiedStockID").getAsString();
            
            String qty_url = item_object.getAsJsonObject("OutboundDeliveryDeliveryQuantity").getAsJsonObject("__deferred").getAsJsonPrimitive("uri").getAsString();
            String qty_results[] = ExternalRestCaller.call(qty_url+"?$format=json","",user, pass, ExternalRestCaller.METHOD_GET, "");
            
            JsonObject qty_elements = gson.fromJson(qty_results[1], JsonObject.class );
            Double _quantity = qty_elements.getAsJsonObject("d").getAsJsonObject("results").getAsJsonPrimitive("Quantity").getAsDouble();
            String _unit_code = qty_elements.getAsJsonObject("d").getAsJsonObject("results").getAsJsonPrimitive("unitCode").getAsString();
            
            
            String mat_url = item_object.getAsJsonObject("MaterialMaterial").getAsJsonObject("__deferred").getAsJsonPrimitive("uri").getAsString();
            String mat_results[] = ExternalRestCaller.call(mat_url+"?$format=json","",user, pass, ExternalRestCaller.METHOD_GET, "");
            JsonObject mat_elements = gson.fromJson(mat_results[1], JsonObject.class );
            
            String _product_desc = mat_elements.getAsJsonObject("d").getAsJsonObject("results").getAsJsonPrimitive("Description").getAsString();
            
            //System.out.println(_product_desc);
            DeliveryOrderItemModel itModel = new DeliveryOrderItemModel();
            itModel.system_id = doModel.system_id;
            itModel.delivery_order_id = doModel.delivery_order_id;
            itModel.delivery_order_uuid = doModel.delivery_order_uuid;
            itModel.item_uuid = _item_uuid;
            itModel.line_item_id = ""+((i+1)*10);
            itModel.product_id = _product_id;
            itModel.identified_stock_id = _identified_stock;
            itModel.product_desc = _product_desc;
            itModel.quantity = _quantity;
            itModel.unit_code = _unit_code;
            doModel.items.add(itModel);
        }
        
    }*/
    
}
