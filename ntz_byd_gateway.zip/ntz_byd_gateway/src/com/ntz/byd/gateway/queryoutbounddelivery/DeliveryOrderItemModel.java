/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ntz.byd.gateway.queryoutbounddelivery;

import java.util.ArrayList;

/**
 *
 * @author NTZ_Admin
 */
public class DeliveryOrderItemModel {
    public String system_id;
    public String delivery_order_id;
    public String delivery_order_uuid;
    public String item_uuid;
    public String line_item_id;
    public String product_id;
    public String product_desc;
    public double quantity;
    public String unit_code;
    public String identified_stock_id = "";
    
    
    
    ArrayList<DeliveryOrderItemSerialModel> seirals = new ArrayList<DeliveryOrderItemSerialModel>();

}
