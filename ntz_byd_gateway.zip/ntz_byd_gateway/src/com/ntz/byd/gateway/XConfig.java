/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ntz.byd.gateway;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.security.GeneralSecurityException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Locale;
import java.util.Properties;
import java.util.TimeZone;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

/**
 *
 * @author NTZ_Admin
 */
public class XConfig {

    public static void init() throws FileNotFoundException, IOException {
        Locale.setDefault(new Locale("en", "EN"));
        TimeZone.setDefault(TimeZone.getTimeZone("Asia/Bangkok"));
        System.setProperty("com.sun.xml.ws.transport.http.client.HttpTransportPipe.dump", "true");
        System.setProperty("com.sun.xml.internal.ws.transport.http.client.HttpTransportPipe.dump", "true");
        System.setProperty("com.sun.xml.ws.transport.http.HttpAdapter.dump", "true");
        System.setProperty("com.sun.xml.internal.ws.transport.http.HttpAdapter.dump", "true");
        System.setProperty("com.sun.xml.internal.ws.transport.http.HttpAdapter.dumpTreshold", "9999999999999");

        Properties prop = new Properties();
        InputStream input = null;
        input = new FileInputStream("resources/conf.properties");
        prop.load(input);
        

        db_host = prop.getProperty("db_host");
        db_user = prop.getProperty("db_user");
        db_pass = prop.getProperty("db_pass");
        db_port = prop.getProperty("db_port");
        db_schema = prop.getProperty("db_schema");

        thread_size = Integer.parseInt(prop.getProperty("thread_size"));
        //System.out.println("Config Init " + db_pass);
        
        
        smtp_host = prop.getProperty("smtp_host");
        smtp_user = prop.getProperty("smtp_user");
        smtp_pass = prop.getProperty("smtp_pass");
        smtp_port = prop.getProperty("smtp_port");
        smtp_from = prop.getProperty("smtp_from");


        list_email = new ArrayList<String>();
        String _tmpMail= prop.getProperty("notification_email");
        if(_tmpMail != null && !_tmpMail.equals(""))
        {
            String[] emails = _tmpMail.split(",");
            for(int _i = 0; _i < emails.length; _i++)
            {   
                list_email.add(emails[_i]);
            }
        }
        
        
        
    }

    public static void initTrustAllCert() {
        // Create a trust manager that does not validate certificate chains
        TrustManager[] trustAllCerts = new TrustManager[]{
            new X509TrustManager() {
                public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                    return new X509Certificate[0];
                }

                public void checkClientTrusted(
                        java.security.cert.X509Certificate[] certs, String authType) {
                }

                public void checkServerTrusted(
                        java.security.cert.X509Certificate[] certs, String authType) {
                }
            }
        };
        

        // Install the all-trusting trust manager
        try {
            SSLContext sc = SSLContext.getInstance("SSL");
            sc.init(null, trustAllCerts, new java.security.SecureRandom());
            HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
        } catch (GeneralSecurityException e) {
        }
    }

    public static String db_host = "";
    public static String db_user = "";
    public static String db_pass = "";
    public static String db_port = "";
    public static String db_schema = "";

    public static int thread_size = 0;
    
    
    
    
    
    public static ArrayList<String> list_email = null;
    public static String smtp_host = "";
    public static String smtp_user = "";
    public static String smtp_pass = "";
    public static String smtp_port = "";
    public static String smtp_from = "";
}
