/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ntz.byd.gateway.querymaterial;

import java.util.ArrayList;

/**
 *
 * @author NTZ_Admin
 */
public class MaterialModel {
    public String system_id = "";
    public String material_id = "";
    public String material_uuid = "";
    public String product_category_id = "";
    public String identified_stock_type_code = "";
    public String base_unit_code = "";
    public String inventory_unit_code = "";
    public String purchasing_unit_code = "";
    public String purchasing_life_cycle_status_code = "";
    public String byd_gmt0_lastchange_datetime = "";
    public String external_interface_status = "W";
    
    
    ArrayList<MaterialDetailModel> mat_detail = new ArrayList<MaterialDetailModel>();
    ArrayList<MaterialDescriptionModel> mat_description = new ArrayList<MaterialDescriptionModel>();
    ArrayList<MaterialUnitConversionModel> mat_unit_conversion = new ArrayList<MaterialUnitConversionModel>();
    ArrayList<MaterialSupplierPartNoModel> mat_supplier_partno = new ArrayList<MaterialSupplierPartNoModel>();
    ArrayList<MaterialSalesModel> mat_sales = new ArrayList<MaterialSalesModel>();
    ArrayList<MaterialLogisticsModel> mat_logistics = new ArrayList<MaterialLogisticsModel>();
    ArrayList<MaterialValuationModel> mat_valuation = new ArrayList<MaterialValuationModel>();
}
