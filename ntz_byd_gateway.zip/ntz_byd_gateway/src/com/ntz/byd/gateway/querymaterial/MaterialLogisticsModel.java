/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ntz.byd.gateway.querymaterial;

/**
 *
 * @author NTZ_Admin
 */
public class MaterialLogisticsModel {
    public String system_id = "";
    public String material_id = "";
    public String material_uuid = "";
 
    public String life_cycle_status_code = "";
    public String site_id = "";
   
}
