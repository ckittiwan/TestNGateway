/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ntz.byd.gateway.querymaterial;

/**
 *
 * @author NTZ_Admin
 */
public class MaterialUnitConversionModel {
    public String system_id = "";
    public String material_id = "";
    public String material_uuid = "";
    public String unit_code = "";
    public String corresponding_unit_code = "";
    public double quantity = 0.0;
    public double corresponding_quantity = 0.0;
}
