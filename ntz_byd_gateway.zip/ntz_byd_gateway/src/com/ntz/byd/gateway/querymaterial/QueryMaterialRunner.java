/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ntz.byd.gateway.querymaterial;

import com.google.gson.Gson;
import com.mysql.jdbc.PreparedStatement;
import com.ntz.byd.gateway.EmailSender;
import com.ntz.byd.gateway.ExternalRestCaller;
import com.ntz.byd.gateway.db.MySQLDB;
import com.ntz.byd.gateway.querymaterial.autogen.MaterialByElementsQueryMessageSync;
import com.ntz.byd.gateway.querymaterial.autogen.MaterialByElementsQuerySelectionByElements;
import com.ntz.byd.gateway.querymaterial.autogen.MaterialByElementsResponseMaterialDescription;
import com.ntz.byd.gateway.querymaterial.autogen.MaterialByElementsResponseMaterialLogistics;
import com.ntz.byd.gateway.querymaterial.autogen.MaterialByElementsResponseMaterialQuantityConversion;
import com.ntz.byd.gateway.querymaterial.autogen.MaterialByElementsResponseMaterialSales;
import com.ntz.byd.gateway.querymaterial.autogen.MaterialByElementsResponseMaterialSupplierPartNumber;
import com.ntz.byd.gateway.querymaterial.autogen.MaterialByElementsResponseMaterialSync;
import com.ntz.byd.gateway.querymaterial.autogen.MaterialByElementsResponseMaterialText;
import com.ntz.byd.gateway.querymaterial.autogen.MaterialByElementsResponseMaterialValuation;
import com.ntz.byd.gateway.querymaterial.autogen.MaterialByElementsResponseMessageSync;
import com.ntz.byd.gateway.querymaterial.autogen.QueryProcessingConditions;
import com.ntz.byd.gateway.querymaterial.autogen.StandardFaultMessage_Exception;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.TimeZone;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.ws.BindingProvider;

/**
 *
 * @author NTZ_Admin
 */
public class QueryMaterialRunner implements Runnable{
    
    private Hashtable _systemht = null;
    private PreparedStatement insertMaterialStmt = null;
    private PreparedStatement insertMaterialDetailStmt = null;
    private PreparedStatement insertMaterialDescriptionStmt = null;
    private PreparedStatement insertMaterialUnitConversionStmt = null;
    private PreparedStatement insertMaterialSupplierPartNoStmt = null;
    private PreparedStatement insertMaterialSalesStmt = null;
    private PreparedStatement insertMaterialLogisticsStmt = null;
    private PreparedStatement insertMaterialValuationStmt = null;
    
    
    
    public QueryMaterialRunner(Hashtable hashtable){
        _systemht = hashtable;
    }

    @Override
    public void run() {
        
        MySQLDB db = null;
        try 
        {
            SimpleDateFormat df_gmt0 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            df_gmt0.setTimeZone(TimeZone.getTimeZone("GMT"));
            
            
            String lastupdate = get_last_synz_datetime();
            com.ntz.byd.gateway.querymaterial.autogen.MaterialByElementsQueryMessageSync request = composeMessage(lastupdate);
            
            MaterialByElementsResponseMessageSync resp = findByElements(request);
            
            ArrayList<MaterialModel> mat_list = new  ArrayList<MaterialModel>();
            
            for(int i = 0 ; i < resp.getMaterial().size() ; i++)
            {
                MaterialByElementsResponseMaterialSync mat = resp.getMaterial().get(i);
                MaterialModel matModel = new MaterialModel();
                matModel.system_id = (String) this._systemht.get("system_id");
                matModel.material_id = mat.getInternalID().getValue();
                System.out.println(matModel.material_id);
                matModel.material_uuid = mat.getUUID().getValue();
                matModel.product_category_id = mat.getProductCategoryID();
                if(mat.getIdentifiedStockTypeCode() != null)
                {
                    matModel.identified_stock_type_code = mat.getIdentifiedStockTypeCode().getValue();
                }
                    
                
                matModel.base_unit_code = mat.getBaseMeasureUnitCode();
                matModel.inventory_unit_code = mat.getInventoryValuationMeasureUnitCode();
                if(mat.getPurchasing() != null)
                {
                    matModel.purchasing_unit_code = mat.getPurchasing().getPurchasingMeasureUnitCode();
                    matModel.purchasing_life_cycle_status_code = mat.getPurchasing().getLifeCycleStatusCode();
                }              
                matModel.byd_gmt0_lastchange_datetime = df_gmt0.format(mat.getSystemAdministrativeData().getLastChangeDateTime().toGregorianCalendar().getTime());
                
                for(int j = 0 ; j < mat.getDetail().size() ; j++)
                {
                    MaterialByElementsResponseMaterialText detail = mat.getDetail().get(j);
                    MaterialDetailModel detModel = new MaterialDetailModel();
                    detModel.system_id = matModel.system_id;
                    detModel.material_id = matModel.material_id;
                    detModel.material_uuid = matModel.material_uuid;
                    detModel.language_code = detail.getContentText().getLanguageCode();
                    detModel.content = detail.getContentText().getValue();
                    matModel.mat_detail.add(detModel);
                }
                
                for(int j =0 ; j < mat.getDescription().size() ; j++)
                {
                    MaterialByElementsResponseMaterialDescription desc = mat.getDescription().get(j);
                    MaterialDescriptionModel descModel = new MaterialDescriptionModel();
                    descModel.system_id = matModel.system_id;
                    descModel.material_id = matModel.material_id;
                    descModel.material_uuid = matModel.material_uuid;
                    descModel.language_code = desc.getDescription().getLanguageCode();
                    descModel.content = desc.getDescription().getValue();
                    matModel.mat_description.add(descModel);
                }
                
                for(int j =0 ; j < mat.getQuantityConversion().size() ; j++)
                {
                    MaterialByElementsResponseMaterialQuantityConversion conv = mat.getQuantityConversion().get(j);
                    MaterialUnitConversionModel convModel = new MaterialUnitConversionModel();
                    convModel.system_id = matModel.system_id;
                    convModel.material_id = matModel.material_id;
                    convModel.material_uuid = matModel.material_uuid;
                    convModel.unit_code = conv.getQuantity().getUnitCode();
                    convModel.corresponding_unit_code = conv.getCorrespondingQuantity().getUnitCode();
                    convModel.quantity = conv.getQuantity().getValue().doubleValue();
                    convModel.corresponding_quantity = conv.getCorrespondingQuantity().getValue().doubleValue();  
                    matModel.mat_unit_conversion.add(convModel);
                }
                
                //mat.getGlobalTradeItemNumber().get(0).
                for(int j = 0 ; j < mat.getSupplierPartNumber().size() ; j++)
                {
                    MaterialByElementsResponseMaterialSupplierPartNumber supp = mat.getSupplierPartNumber().get(j);
                    MaterialSupplierPartNoModel suppModel = new MaterialSupplierPartNoModel();
                    suppModel.system_id = matModel.system_id;
                    suppModel.material_id = matModel.material_id;
                    suppModel.material_uuid = matModel.material_uuid;
                    suppModel.supplier_internal_id = supp.getSupplierInternalID();
                    suppModel.product_supplier_id = supp.getProductSupplierID();
                    matModel.mat_supplier_partno.add(suppModel);
                }
                
                for(int j = 0 ; j < mat.getSales().size(); j ++)
                {
                    MaterialByElementsResponseMaterialSales sales = mat.getSales().get(j);
                    MaterialSalesModel salesModel  = new MaterialSalesModel();
                    salesModel.system_id = matModel.system_id;
                    salesModel.material_id = matModel.material_id;
                    salesModel.material_uuid = matModel.material_uuid;
                    salesModel.sales_organisation_id = sales.getSalesOrganisationID();
                    salesModel.distribution_channel_code = sales.getDistributionChannelCode().getValue();
                    salesModel.life_cycle_status_code = sales.getLifeCycleStatusCode();
                    salesModel.sales_unit_code = sales.getSalesMeasureUnitCode();
                    salesModel.item_group_code = sales.getItemGroupCode();
                    salesModel.cash_discount_deductible_indicator = sales.isCashDiscountDeductibleIndicator()==null?"":(sales.isCashDiscountDeductibleIndicator()?"X":"");               
                    matModel.mat_sales.add(salesModel);
                }
                
                
                for(int j = 0 ; j < mat.getLogistics().size(); j++)
                {
                    MaterialByElementsResponseMaterialLogistics logis = mat.getLogistics().get(j);
                    MaterialLogisticsModel logisModel = new MaterialLogisticsModel();
                    logisModel.system_id = matModel.system_id;
                    logisModel.material_id = matModel.material_id;
                    logisModel.material_uuid = matModel.material_uuid;
                    logisModel.site_id = logis.getSiteID().getValue();
                    logisModel.life_cycle_status_code = logis.getLifeCycleStatusCode();
                    matModel.mat_logistics.add(logisModel);
                }
                
                
                for(int j =0 ; j < mat.getValuation().size(); j++)
                {
                    MaterialByElementsResponseMaterialValuation val = mat.getValuation().get(j);
                    MaterialValuationModel valModel = new MaterialValuationModel();
                    valModel.system_id = matModel.system_id;
                    valModel.material_id = matModel.material_id;
                    valModel.material_uuid = matModel.material_uuid;
                    valModel.company_id = val.getCompanyID();
                    valModel.business_residence_id = val.getBusinessResidenceID();
                    valModel.life_cycle_status_code = val.getLifeCycleStatusCode();
                    matModel.mat_valuation.add(valModel);
                }
                
                
                mat_list.add(matModel);
            }
            
            
            
            
            //Start Insert table here
            db = new MySQLDB();
            db.connect();
            String[] sql = getSQLTemplate();
            insertMaterialStmt = (PreparedStatement) db.conn.prepareStatement(sql[0]);
            insertMaterialDetailStmt  = (PreparedStatement) db.conn.prepareStatement(sql[1]);
            insertMaterialDescriptionStmt = (PreparedStatement) db.conn.prepareStatement(sql[2]);
            insertMaterialUnitConversionStmt  = (PreparedStatement) db.conn.prepareStatement(sql[3]);
            insertMaterialSupplierPartNoStmt   = (PreparedStatement) db.conn.prepareStatement(sql[4]);
            insertMaterialSalesStmt    = (PreparedStatement) db.conn.prepareStatement(sql[5]);
            insertMaterialLogisticsStmt     = (PreparedStatement) db.conn.prepareStatement(sql[6]);
            insertMaterialValuationStmt      = (PreparedStatement) db.conn.prepareStatement(sql[7]);
            
            for(int i = 0 ; i < mat_list.size() ; i++)
            {
                MaterialModel matModel = mat_list.get(i);
                clearExistingData(matModel);
                insertMaterialStmt.setString(1, matModel.system_id);
                insertMaterialStmt.setString(2, matModel.material_id);
                insertMaterialStmt.setString(3, matModel.material_uuid);
                insertMaterialStmt.setString(4, matModel.product_category_id);
                insertMaterialStmt.setString(5, matModel.identified_stock_type_code);
                insertMaterialStmt.setString(6, matModel.base_unit_code);
                insertMaterialStmt.setString(7, matModel.inventory_unit_code);
                insertMaterialStmt.setString(8, matModel.purchasing_unit_code);
                insertMaterialStmt.setString(9, matModel.purchasing_life_cycle_status_code);
                insertMaterialStmt.setString(10, matModel.byd_gmt0_lastchange_datetime);
                insertMaterialStmt.setString(11, matModel.external_interface_status);
                insertMaterialStmt.executeUpdate();
                
                for(int j = 0 ; j < matModel.mat_detail.size(); j++)
                {
                    MaterialDetailModel detModel = matModel.mat_detail.get(j);
                    insertMaterialDetailStmt.setString(1, detModel.system_id);
                    insertMaterialDetailStmt.setString(2, detModel.material_id);
                    insertMaterialDetailStmt.setString(3, detModel.material_uuid);
                    insertMaterialDetailStmt.setString(4, detModel.language_code);
                    insertMaterialDetailStmt.setString(5, detModel.content);
                    insertMaterialDetailStmt.executeUpdate();
                }
                
                for(int j = 0 ; j < matModel.mat_description.size(); j++)
                {
                    MaterialDescriptionModel descModel = matModel.mat_description.get(j);
                    insertMaterialDescriptionStmt.setString(1, descModel.system_id);
                    insertMaterialDescriptionStmt.setString(2, descModel.material_id);
                    insertMaterialDescriptionStmt.setString(3, descModel.material_uuid);
                    insertMaterialDescriptionStmt.setString(4, descModel.language_code);
                    insertMaterialDescriptionStmt.setString(5, descModel.content);
                    insertMaterialDescriptionStmt.executeUpdate();
                }
                
                
                for(int j = 0 ; j < matModel.mat_unit_conversion.size(); j++)
                {
                    MaterialUnitConversionModel unitModel = matModel.mat_unit_conversion.get(j);
                    insertMaterialUnitConversionStmt.setString(1, unitModel.system_id);
                    insertMaterialUnitConversionStmt.setString(2, unitModel.material_id);
                    insertMaterialUnitConversionStmt.setString(3, unitModel.material_uuid);
                    insertMaterialUnitConversionStmt.setString(4, unitModel.unit_code);
                    insertMaterialUnitConversionStmt.setString(5, unitModel.corresponding_unit_code);
                    insertMaterialUnitConversionStmt.setDouble(6, unitModel.quantity);
                    insertMaterialUnitConversionStmt.setDouble(7, unitModel.corresponding_quantity);
                    insertMaterialUnitConversionStmt.executeUpdate();
                }
                
                
                
                for(int j = 0 ; j < matModel.mat_supplier_partno.size(); j++)
                {
                  MaterialSupplierPartNoModel suppModel = matModel.mat_supplier_partno.get(j);    
                  insertMaterialSupplierPartNoStmt.setString(1, suppModel.system_id);
                  insertMaterialSupplierPartNoStmt.setString(2, suppModel.material_id);
                  insertMaterialSupplierPartNoStmt.setString(3, suppModel.material_uuid);
                  insertMaterialSupplierPartNoStmt.setString(4, suppModel.supplier_internal_id);
                  insertMaterialSupplierPartNoStmt.setString(5, suppModel.product_supplier_id);
                  insertMaterialSupplierPartNoStmt.executeUpdate();                  
                }
                
                
                for(int j = 0 ; j < matModel.mat_sales.size(); j++)
                {
                  MaterialSalesModel saleModel = matModel.mat_sales.get(j);    
                  insertMaterialSalesStmt.setString(1, saleModel.system_id);
                  insertMaterialSalesStmt.setString(2, saleModel.material_id);
                  insertMaterialSalesStmt.setString(3, saleModel.material_uuid);
                  insertMaterialSalesStmt.setString(4, saleModel.sales_organisation_id);
                  insertMaterialSalesStmt.setString(5, saleModel.distribution_channel_code);
                  insertMaterialSalesStmt.setString(6, saleModel.life_cycle_status_code);
                  insertMaterialSalesStmt.setString(7, saleModel.sales_unit_code);
                  insertMaterialSalesStmt.setString(8, saleModel.item_group_code);
                  insertMaterialSalesStmt.setString(9, saleModel.cash_discount_deductible_indicator);
                  insertMaterialSalesStmt.executeUpdate();                  
                }
                
                
                for(int j = 0 ; j < matModel.mat_logistics.size(); j++)
                {
                  MaterialLogisticsModel get = matModel.mat_logistics.get(j);    
                  insertMaterialLogisticsStmt.setString(1, get.system_id);
                  insertMaterialLogisticsStmt.setString(2, get.material_id);
                  insertMaterialLogisticsStmt.setString(3, get.material_uuid);
                  insertMaterialLogisticsStmt.setString(4, get.site_id);
                  insertMaterialLogisticsStmt.setString(5, get.life_cycle_status_code);
                  insertMaterialLogisticsStmt.executeUpdate();                  
                }
                
                
                for(int j = 0 ; j < matModel.mat_valuation.size(); j++)
                {
                  MaterialValuationModel get = matModel.mat_valuation.get(j);    
                  insertMaterialValuationStmt.setString(1, get.system_id);
                  insertMaterialValuationStmt.setString(2, get.material_id);
                  insertMaterialValuationStmt.setString(3, get.material_uuid);
                  insertMaterialValuationStmt.setString(4, get.company_id);
                  insertMaterialValuationStmt.setString(5, get.business_residence_id);
                  insertMaterialValuationStmt.setString(6, get.life_cycle_status_code);
                  insertMaterialValuationStmt.executeUpdate();                  
                }

            }
            
            
            //send to external system
            send_to_external_system();
            
        }
        catch (Exception ex) 
        {
            
            StringWriter sw = new StringWriter();
            ex.printStackTrace(new PrintWriter(sw));
            String exceptionAsString = sw.toString();
            System.out.println(exceptionAsString);
            
            EmailSender.sendFromGMail("nGateway Error - Query Material", exceptionAsString);
            
            Logger.getLogger(QueryMaterialRunner.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private String get_last_synz_datetime() throws Exception {
        String ret = "";
        String sql = "select DATE_FORMAT(IFNULL(DATE_ADD(MAX(byd_gmt0_lastchange_datetime), INTERVAL 1 SECOND),STR_TO_DATE('01/01/2000', '%d/%m/%Y')),'%Y-%m-%dT%H:%i:%sZ') as xc from t_material where system_id = ? ";
        MySQLDB db = new MySQLDB();
        db.connect();
        db.createPrepareStatement(sql);
        db.bindValue(1, (String) this._systemht.get("system_id"));
        
        ResultSet res = db.executeQuery();
        ArrayList<Hashtable<String, String>> list = db.buildList(res);
        
        if(list.size() == 0)
        {
            ret = "";
        }
        else
        {
            ret = list.get(0).get("xc");
        }
        
        db.disconnect();
        return ret;
    }
    
    
    private String[] getSQLTemplate()
    {
        StringBuilder sb0  = new StringBuilder();
        sb0.append("INSERT INTO t_material(system_id,"); //1
        sb0.append("material_id,"); //2
        sb0.append("material_uuid,");//3
        sb0.append("product_category_id,");//4
        sb0.append("identified_stock_type_code,");//5
        sb0.append("base_unit_code,");//6
        sb0.append("inventory_unit_code,");//7
        sb0.append("purchasing_unit_code,");//8
        sb0.append("purchasing_life_cycle_status_code,");//9
        sb0.append("byd_gmt0_lastchange_datetime,");//10
        sb0.append("external_interface_status,");//11
        sb0.append("create_datetime)");
        sb0.append("VALUES(?,?,?,?,?,?,?,?,?,?,?,NOW())");
        
        
        StringBuilder sb1  = new StringBuilder();
        sb1.append("INSERT INTO t_material_detail(system_id,material_id,material_uuid,language_code,content)");
        sb1.append("VALUES(?,?,?,?,?)");


        StringBuilder sb2  = new StringBuilder();
        sb2.append("INSERT INTO t_material_description(system_id,material_id,material_uuid,language_code,content)");
        sb2.append("VALUES(?,?,?,?,?)");

        StringBuilder sb3  = new StringBuilder();
        sb3.append("INSERT INTO t_material_unit_conversion(");
        sb3.append("system_id,");//1
        sb3.append("material_id,");//2
        sb3.append("material_uuid,");//3
        sb3.append("unit_code,");//4
        sb3.append("corresponding_unit_code,");//5
        sb3.append("quantity,");//6
        sb3.append("corresponding_quantity)");//7
        sb3.append("VALUES(?,?,?,?,?,?,?)");
        
        
        StringBuilder sb4 = new StringBuilder();
        sb4.append("INSERT INTO t_material_supplierpartno(system_id, material_id, material_uuid, supplier_internal_id, product_supplier_id)");
        sb4.append("VALUES(?,?,?,?,?)");
        
        
        
        StringBuilder sb5  = new StringBuilder();
        sb5.append("INSERT INTO t_material_sales(");
        sb5.append("system_id,");//1
        sb5.append("material_id,");//2
        sb5.append("material_uuid,");//3
        sb5.append("sales_organisation_id,");//4
        sb5.append("distribution_channel_code,");//5
        sb5.append("life_cycle_status_code,");//6
        sb5.append("sales_unit_code,");//7
        sb5.append("item_group_code,");//8
        sb5.append("cash_discount_deductible_indicator)");//9
        sb5.append("VALUES(?,?,?,?,?,?,?,?,?)");
        
        
        
        StringBuilder sb6  = new StringBuilder();
        sb6.append("INSERT INTO t_material_logistics(system_id,material_id,material_uuid,site_id,life_cycle_status_code)");
        sb6.append("VALUES(?,?,?,?,?)");
     
        StringBuilder sb7  = new StringBuilder();
        sb7.append("INSERT INTO t_material_valuation(system_id,material_id,material_uuid,company_id,business_residence_id,life_cycle_status_code)");
        sb7.append("VALUES(?,?,?,?,?,?)");
         
        
        
        return new String[]{sb0.toString(),sb1.toString(),sb2.toString(),sb3.toString(),sb4.toString(),sb5.toString(),sb6.toString(),sb7.toString()};
        
    }
    
    
     private void clearExistingData(MaterialModel matModel) throws SQLException {
        
        String sql0 = "delete from t_material where system_id = '"+matModel.system_id+"' AND material_uuid = '"+matModel.material_uuid+"'";
        String sql1 = "delete from t_material_detail where system_id = '"+matModel.system_id+"' AND material_uuid = '"+matModel.material_uuid+"'";
        String sql2 = "delete from t_material_description where system_id = '"+matModel.system_id+"' AND material_uuid = '"+matModel.material_uuid+"'";
        String sql3 = "delete from t_material_unit_conversion where system_id = '"+matModel.system_id+"' AND material_uuid = '"+matModel.material_uuid+"'";
        String sql4 = "delete from t_material_supplierpartno where system_id = '"+matModel.system_id+"' AND material_uuid = '"+matModel.material_uuid+"'";
        String sql5 = "delete from t_material_sales where system_id = '"+matModel.system_id+"' AND material_uuid = '"+matModel.material_uuid+"'";
        String sql6 = "delete from t_material_logistics where system_id = '"+matModel.system_id+"' AND material_uuid = '"+matModel.material_uuid+"'";
        String sql7 = "delete from t_material_valuation where system_id = '"+matModel.system_id+"' AND material_uuid = '"+matModel.material_uuid+"'";
        
        MySQLDB db = new MySQLDB();
        db.connect();
        Statement createStatement = db.conn.createStatement();
        createStatement.execute(sql0);
        createStatement.execute(sql1);
        createStatement.execute(sql2);
        createStatement.execute(sql3);
        createStatement.execute(sql4);
        createStatement.execute(sql5);
        createStatement.execute(sql6);
        createStatement.execute(sql7);
        
        createStatement.close();
        
        db.disconnect();
        
    }
    
    

    private  MaterialByElementsResponseMessageSync findByElements(com.ntz.byd.gateway.querymaterial.autogen.MaterialByElementsQueryMessageSync materialByElementsQuerySync) throws StandardFaultMessage_Exception {
        com.ntz.byd.gateway.querymaterial.autogen.Service service = new com.ntz.byd.gateway.querymaterial.autogen.Service();
        com.ntz.byd.gateway.querymaterial.autogen.QueryMaterialIn port = service.getBinding();
        BindingProvider provider = (BindingProvider) port;
        provider.getRequestContext().put(BindingProvider.USERNAME_PROPERTY, this._systemht.get("system_ws_username"));
        provider.getRequestContext().put(BindingProvider.PASSWORD_PROPERTY, this._systemht.get("system_ws_password"));
        provider.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, this._systemht.get("system_url").toString() + this._systemht.get("service_url_path").toString());
        return port.findByElements(materialByElementsQuerySync);
    }

    private MaterialByElementsQueryMessageSync composeMessage(String lastupdate) throws DatatypeConfigurationException {
        MaterialByElementsQueryMessageSync request = new MaterialByElementsQueryMessageSync();
        
        request.setMaterialSelectionByElements(new MaterialByElementsQuerySelectionByElements());
        request.getMaterialSelectionByElements().setSelectionByLastChangeSinceDateTime(DatatypeFactory.newInstance().newXMLGregorianCalendar(lastupdate));
        request.setProcessingConditions(new QueryProcessingConditions());
        request.getProcessingConditions().setQueryHitsMaximumNumberValue(Integer.valueOf(0));
        request.getProcessingConditions().setQueryHitsUnlimitedIndicator(true);
        
        return request;
    }

    
    
    //================================================= START SEND TO EXTERNAL SYSTEM
    private void send_to_external_system() throws Exception {
        if( this._systemht.get("callback_url").toString().equals(""))
        {
            return;
        }
        
        MySQLDB db = new MySQLDB();
        db.connect();
        String sql = "select * from t_material t1 where t1.system_id = ? AND t1.external_interface_status in ('W','E')";
        db.createPrepareStatement(sql);
        db.bindValue(1,  this._systemht.get("system_id").toString());
        ResultSet res = db.executeQuery();
        ArrayList mat_list = db.buildList(res);
        db.disconnect();
        
        if(mat_list.size() == 0)
        {
            return;
        }
        
        
        ArrayList json_material = new ArrayList();
        for(int i = 0 ; i < mat_list.size(); i++)
        {
            Hashtable ht = (Hashtable) mat_list.get(i);
            HashMap hm = new HashMap();
            hm.put("material_id",ht.get("material_id"));
            hm.put("material_uuid",ht.get("material_uuid"));
            hm.put("product_category_id",ht.get("product_category_id"));
            hm.put("identified_stock_type_code",ht.get("identified_stock_type_code"));
            hm.put("base_unit_code",ht.get("base_unit_code"));
            hm.put("inventory_unit_code",ht.get("inventory_unit_code"));
            hm.put("purchasing_unit_code",ht.get("purchasing_unit_code"));
            hm.put("purchasing_life_cycle_status_code",ht.get("purchasing_life_cycle_status_code"));
            hm.put("byd_gmt0_lastchange_datetime",ht.get("byd_gmt0_lastchange_datetime"));
            hm.put("details",getMaterialDetails( (String)ht.get("system_id"),(String) ht.get("material_uuid")));
            hm.put("descriptions",getMaterialDescriptions((String)ht.get("system_id"),(String) ht.get("material_uuid")));
            hm.put("unit_conversion",getMaterialUnitConversion((String)ht.get("system_id"),(String) ht.get("material_uuid")));
            hm.put("supplier_part_no",getMaterialSupplierPartNo((String)ht.get("system_id"),(String) ht.get("material_uuid")));
            hm.put("sales",getMaterialSales((String)ht.get("system_id"),(String) ht.get("material_uuid")));
            hm.put("logistics",getMaterialLogistics((String)ht.get("system_id"),(String) ht.get("material_uuid")));
            hm.put("valuations",getMaterialValuations((String)ht.get("system_id"),(String) ht.get("material_uuid")));
            
            json_material.add(hm);
            
        }
        
        
        Gson gson = new Gson();
        String dataSent = gson.toJson(json_material);
        //System.out.println(dataSent);
        String results[] = null;
      
        results =  ExternalRestCaller.call(
                (String) this._systemht.get("callback_url"), 
                (String) this._systemht.get("callback_apikey"), 
                (String) this._systemht.get("callback_username"), 
                (String) this._systemht.get("callback_password"), 
                ExternalRestCaller.METHOD_POST, 
                dataSent);
      
      
       
       if(results[0].equals("200"))//OK
       {
           update_external_callback_status(mat_list,"S");
       }
       else //Fail
       {
           update_external_callback_status(mat_list,"E");
       }
        
        
        
    }
    

    private ArrayList getMaterialDetails(String system_id, String material_uuid) throws Exception {
        String sql = "select language_code, content from t_material_detail where system_id = ? AND material_uuid = ?";
        MySQLDB db = new MySQLDB(); 
        db.connect();
        db.createPrepareStatement(sql);
        db.bindValue(1, system_id);
        db.bindValue(2, material_uuid);
        ResultSet res = db.executeQuery();
        
        ArrayList list = db.buildList(res);
        db.disconnect();
        
        
        return list;
    }

    private ArrayList getMaterialDescriptions(String system_id, String material_uuid) throws Exception {
        String sql = "select language_code, content from t_material_description where system_id = ? AND material_uuid = ?";
        MySQLDB db = new MySQLDB(); 
        db.connect();
        db.createPrepareStatement(sql);
        db.bindValue(1, system_id);
        db.bindValue(2, material_uuid);
        ResultSet res = db.executeQuery();
        
        ArrayList list = db.buildList(res);
        db.disconnect();
        
        
        return list;
    }

    private ArrayList getMaterialUnitConversion(String system_id, String material_uuid) throws Exception {
        String sql = "select unit_code, corresponding_unit_code, quantity, corresponding_quantity from t_material_unit_conversion where system_id = ? AND material_uuid = ?";
        MySQLDB db = new MySQLDB(); 
        db.connect();
        db.createPrepareStatement(sql);
        db.bindValue(1, system_id);
        db.bindValue(2, material_uuid);
        ResultSet res = db.executeQuery();
        
        ArrayList list = db.buildList(res);
        db.disconnect();
        
        
        return list;
    }

    private ArrayList getMaterialSupplierPartNo(String system_id, String material_uuid)throws Exception {
        String sql = "select supplier_internal_id as supplier_id, product_supplier_id as product_id from t_material_supplierpartno where system_id = ? AND material_uuid = ?";
        MySQLDB db = new MySQLDB(); 
        db.connect();
        db.createPrepareStatement(sql);
        db.bindValue(1, system_id);
        db.bindValue(2, material_uuid);
        ResultSet res = db.executeQuery();
        
        ArrayList list = db.buildList(res);
        db.disconnect();
        
        
        return list;
    }
    
    private ArrayList getMaterialSales(String system_id, String material_uuid)throws Exception {
        String sql = "select sales_organisation_id,distribution_channel_code,life_cycle_status_code,sales_unit_code,item_group_code,cash_discount_deductible_indicator from t_material_sales where system_id = ? AND material_uuid = ?";
        MySQLDB db = new MySQLDB(); 
        db.connect();
        db.createPrepareStatement(sql);
        db.bindValue(1, system_id);
        db.bindValue(2, material_uuid);
        ResultSet res = db.executeQuery();
        
        ArrayList list = db.buildList(res);
        db.disconnect();
        
        
        return list;
    }

    private ArrayList getMaterialLogistics(String system_id, String material_uuid) throws Exception{
        String sql = "select site_id, life_cycle_status_code from t_material_logistics where system_id = ? AND material_uuid = ?";
        MySQLDB db = new MySQLDB(); 
        db.connect();
        db.createPrepareStatement(sql);
        db.bindValue(1, system_id);
        db.bindValue(2, material_uuid);
        ResultSet res = db.executeQuery();
        
        ArrayList list = db.buildList(res);
        db.disconnect();
        
        
        return list;
    }

    private ArrayList getMaterialValuations(String system_id, String material_uuid) throws Exception {
        String sql = "select company_id,business_residence_id, life_cycle_status_code from t_material_valuation where system_id = ? AND material_uuid = ?";
        MySQLDB db = new MySQLDB(); 
        db.connect();
        db.createPrepareStatement(sql);
        db.bindValue(1, system_id);
        db.bindValue(2, material_uuid);
        ResultSet res = db.executeQuery();
        
        ArrayList list = db.buildList(res);
        db.disconnect();
        
        
        return list;
    }

     private void update_external_callback_status(ArrayList<Hashtable<String, String>> mat_list, String status) throws Exception {
       String sql = "update t_material set external_interface_status = ? , external_interface_datetime = NOW() where system_id = ? and material_uuid = ?";
       
       MySQLDB db = new MySQLDB();
       db.connect();
       db.createPrepareStatement(sql);
       db.bindValue(1, status);
       db.bindValue(2, this._systemht.get("system_id").toString());
       for(int i = 0 ; i < mat_list.size(); i++)
       {
           db.bindValue(3, mat_list.get(i).get("material_uuid"));
           db.executeUpdate();
       }
       
       db.disconnect();
    }
    
}
