/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ntz.byd.gateway.querymaterial;

/**
 *
 * @author NTZ_Admin
 */
public class MaterialSalesModel {
    public String system_id = "";
    public String material_id = "";
    public String material_uuid = "";
    public String sales_organisation_id = "";
    public String distribution_channel_code = "";
    public String life_cycle_status_code = "";
    public String sales_unit_code = "";
    public String item_group_code = "";
    public String cash_discount_deductible_indicator = "";
}
