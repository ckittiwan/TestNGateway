/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ntz.byd.gateway.querymaterial;

/**
 *
 * @author NTZ_Admin
 */
public class MaterialValuationModel {
    public String system_id = "";
    public String material_id = "";
    public String material_uuid = "";
    public String company_id = "";
    public String business_residence_id = "";
    public String life_cycle_status_code = "";
}
