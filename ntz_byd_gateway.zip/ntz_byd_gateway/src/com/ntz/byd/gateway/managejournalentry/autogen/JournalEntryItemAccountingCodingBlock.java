
package com.ntz.byd.gateway.managejournalentry.autogen;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.CollapsedStringAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;


/**
 * <p>Java class for JournalEntryItemAccountingCodingBlock complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="JournalEntryItemAccountingCodingBlock">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="CostCentreID" type="{http://sap.com/xi/AP/Common/GDT}OrganisationalCentreID" minOccurs="0"/>
 *         &lt;element name="ProjectTaskID" type="{http://sap.com/xi/Common/DataTypes}ProjectElementID" minOccurs="0"/>
 *         &lt;element name="SalesOrderReference" type="{http://sap.com/xi/Common/DataTypes}BusinessTransactionDocumentReference" minOccurs="0"/>
 *         &lt;element name="CostObjectKey" type="{http://sap.com/xi/AP/Common/Global}FinancialAccountingViewOfCostObjectKey" minOccurs="0"/>
 *         &lt;element name="IndividualMaterialInternalID" type="{http://sap.com/xi/Common/DataTypes}ProductInternalID" minOccurs="0"/>
 *         &lt;element name="ProfitCentreID" type="{http://sap.com/xi/AP/Common/GDT}OrganisationalCentreID" minOccurs="0"/>
 *         &lt;element name="ServiceOrderReference" type="{http://sap.com/xi/Common/DataTypes}BusinessTransactionDocumentReference" minOccurs="0"/>
 *         &lt;element name="CustomerContractReference" type="{http://sap.com/xi/Common/DataTypes}BusinessTransactionDocumentReference" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "JournalEntryItemAccountingCodingBlock", propOrder = {
    "costCentreID",
    "projectTaskID",
    "salesOrderReference",
    "costObjectKey",
    "individualMaterialInternalID",
    "profitCentreID",
    "serviceOrderReference",
    "customerContractReference"
})
public class JournalEntryItemAccountingCodingBlock {

    @XmlElement(name = "CostCentreID")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String costCentreID;
    @XmlElement(name = "ProjectTaskID")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String projectTaskID;
    @XmlElement(name = "SalesOrderReference")
    protected BusinessTransactionDocumentReference salesOrderReference;
    @XmlElement(name = "CostObjectKey")
    protected FinancialAccountingViewOfCostObjectKey costObjectKey;
    @XmlElement(name = "IndividualMaterialInternalID")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String individualMaterialInternalID;
    @XmlElement(name = "ProfitCentreID")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String profitCentreID;
    @XmlElement(name = "ServiceOrderReference")
    protected BusinessTransactionDocumentReference serviceOrderReference;
    @XmlElement(name = "CustomerContractReference")
    protected BusinessTransactionDocumentReference customerContractReference;

    /**
     * Gets the value of the costCentreID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCostCentreID() {
        return costCentreID;
    }

    /**
     * Sets the value of the costCentreID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCostCentreID(String value) {
        this.costCentreID = value;
    }

    /**
     * Gets the value of the projectTaskID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProjectTaskID() {
        return projectTaskID;
    }

    /**
     * Sets the value of the projectTaskID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProjectTaskID(String value) {
        this.projectTaskID = value;
    }

    /**
     * Gets the value of the salesOrderReference property.
     * 
     * @return
     *     possible object is
     *     {@link BusinessTransactionDocumentReference }
     *     
     */
    public BusinessTransactionDocumentReference getSalesOrderReference() {
        return salesOrderReference;
    }

    /**
     * Sets the value of the salesOrderReference property.
     * 
     * @param value
     *     allowed object is
     *     {@link BusinessTransactionDocumentReference }
     *     
     */
    public void setSalesOrderReference(BusinessTransactionDocumentReference value) {
        this.salesOrderReference = value;
    }

    /**
     * Gets the value of the costObjectKey property.
     * 
     * @return
     *     possible object is
     *     {@link FinancialAccountingViewOfCostObjectKey }
     *     
     */
    public FinancialAccountingViewOfCostObjectKey getCostObjectKey() {
        return costObjectKey;
    }

    /**
     * Sets the value of the costObjectKey property.
     * 
     * @param value
     *     allowed object is
     *     {@link FinancialAccountingViewOfCostObjectKey }
     *     
     */
    public void setCostObjectKey(FinancialAccountingViewOfCostObjectKey value) {
        this.costObjectKey = value;
    }

    /**
     * Gets the value of the individualMaterialInternalID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIndividualMaterialInternalID() {
        return individualMaterialInternalID;
    }

    /**
     * Sets the value of the individualMaterialInternalID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIndividualMaterialInternalID(String value) {
        this.individualMaterialInternalID = value;
    }

    /**
     * Gets the value of the profitCentreID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProfitCentreID() {
        return profitCentreID;
    }

    /**
     * Sets the value of the profitCentreID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProfitCentreID(String value) {
        this.profitCentreID = value;
    }

    /**
     * Gets the value of the serviceOrderReference property.
     * 
     * @return
     *     possible object is
     *     {@link BusinessTransactionDocumentReference }
     *     
     */
    public BusinessTransactionDocumentReference getServiceOrderReference() {
        return serviceOrderReference;
    }

    /**
     * Sets the value of the serviceOrderReference property.
     * 
     * @param value
     *     allowed object is
     *     {@link BusinessTransactionDocumentReference }
     *     
     */
    public void setServiceOrderReference(BusinessTransactionDocumentReference value) {
        this.serviceOrderReference = value;
    }

    /**
     * Gets the value of the customerContractReference property.
     * 
     * @return
     *     possible object is
     *     {@link BusinessTransactionDocumentReference }
     *     
     */
    public BusinessTransactionDocumentReference getCustomerContractReference() {
        return customerContractReference;
    }

    /**
     * Sets the value of the customerContractReference property.
     * 
     * @param value
     *     allowed object is
     *     {@link BusinessTransactionDocumentReference }
     *     
     */
    public void setCustomerContractReference(BusinessTransactionDocumentReference value) {
        this.customerContractReference = value;
    }

}
