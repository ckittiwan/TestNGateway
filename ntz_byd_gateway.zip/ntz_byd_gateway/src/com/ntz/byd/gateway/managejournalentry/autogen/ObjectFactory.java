
package com.ntz.byd.gateway.managejournalentry.autogen;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.ntz.byd.gateway.managejournalentry.autogen package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _JournalEntryBundleCreateRequest_QNAME = new QName("http://sap.com/xi/SAPGlobal20/Global", "JournalEntryBundleCreateRequest");
    private final static QName _JournalEntryBundleCreateConfirmation_QNAME = new QName("http://sap.com/xi/SAPGlobal20/Global", "JournalEntryBundleCreateConfirmation");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.ntz.byd.gateway.managejournalentry.autogen
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link BusinessTransactionDocumentReference }
     * 
     */
    public BusinessTransactionDocumentReference createBusinessTransactionDocumentReference() {
        return new BusinessTransactionDocumentReference();
    }

    /**
     * Create an instance of {@link RegionCode }
     * 
     */
    public RegionCode createRegionCode() {
        return new RegionCode();
    }

    /**
     * Create an instance of {@link Quantity }
     * 
     */
    public Quantity createQuantity() {
        return new Quantity();
    }

    /**
     * Create an instance of {@link BusinessTransactionDocumentTypeCode }
     * 
     */
    public BusinessTransactionDocumentTypeCode createBusinessTransactionDocumentTypeCode() {
        return new BusinessTransactionDocumentTypeCode();
    }

    /**
     * Create an instance of {@link TaxJurisdictionCode }
     * 
     */
    public TaxJurisdictionCode createTaxJurisdictionCode() {
        return new TaxJurisdictionCode();
    }

    /**
     * Create an instance of {@link GeneralLedgerAccountAliasCode }
     * 
     */
    public GeneralLedgerAccountAliasCode createGeneralLedgerAccountAliasCode() {
        return new GeneralLedgerAccountAliasCode();
    }

    /**
     * Create an instance of {@link JournalEntryCashItemCashPayment }
     * 
     */
    public JournalEntryCashItemCashPayment createJournalEntryCashItemCashPayment() {
        return new JournalEntryCashItemCashPayment();
    }

    /**
     * Create an instance of {@link AccountingDocumentTypeCode }
     * 
     */
    public AccountingDocumentTypeCode createAccountingDocumentTypeCode() {
        return new AccountingDocumentTypeCode();
    }

    /**
     * Create an instance of {@link JournalEntryCreateRequestBundleCreditorItem }
     * 
     */
    public JournalEntryCreateRequestBundleCreditorItem createJournalEntryCreateRequestBundleCreditorItem() {
        return new JournalEntryCreateRequestBundleCreditorItem();
    }

    /**
     * Create an instance of {@link JournalEntryCreateRequestBundleMessage }
     * 
     */
    public JournalEntryCreateRequestBundleMessage createJournalEntryCreateRequestBundleMessage() {
        return new JournalEntryCreateRequestBundleMessage();
    }

    /**
     * Create an instance of {@link JournalEntryCreateConfirmationBundleMessage }
     * 
     */
    public JournalEntryCreateConfirmationBundleMessage createJournalEntryCreateConfirmationBundleMessage() {
        return new JournalEntryCreateConfirmationBundleMessage();
    }

    /**
     * Create an instance of {@link JournalEntryCreateRequestBundleCashItem }
     * 
     */
    public JournalEntryCreateRequestBundleCashItem createJournalEntryCreateRequestBundleCashItem() {
        return new JournalEntryCreateRequestBundleCashItem();
    }

    /**
     * Create an instance of {@link JournalEntryCreateRequestBundleJournalEntry }
     * 
     */
    public JournalEntryCreateRequestBundleJournalEntry createJournalEntryCreateRequestBundleJournalEntry() {
        return new JournalEntryCreateRequestBundleJournalEntry();
    }

    /**
     * Create an instance of {@link JournalEntryCreateRequestBundleItem }
     * 
     */
    public JournalEntryCreateRequestBundleItem createJournalEntryCreateRequestBundleItem() {
        return new JournalEntryCreateRequestBundleItem();
    }

    /**
     * Create an instance of {@link JournalEntryCreateConfirmationBundleJournalEntry }
     * 
     */
    public JournalEntryCreateConfirmationBundleJournalEntry createJournalEntryCreateConfirmationBundleJournalEntry() {
        return new JournalEntryCreateConfirmationBundleJournalEntry();
    }

    /**
     * Create an instance of {@link JournalEntryCreateRequestBundleDebtorItem }
     * 
     */
    public JournalEntryCreateRequestBundleDebtorItem createJournalEntryCreateRequestBundleDebtorItem() {
        return new JournalEntryCreateRequestBundleDebtorItem();
    }

    /**
     * Create an instance of {@link JournalEntryCreateRequestBundleTaxItem }
     * 
     */
    public JournalEntryCreateRequestBundleTaxItem createJournalEntryCreateRequestBundleTaxItem() {
        return new JournalEntryCreateRequestBundleTaxItem();
    }

    /**
     * Create an instance of {@link BusinessDocumentBasicMessageHeader }
     * 
     */
    public BusinessDocumentBasicMessageHeader createBusinessDocumentBasicMessageHeader() {
        return new BusinessDocumentBasicMessageHeader();
    }

    /**
     * Create an instance of {@link RegionCode2 }
     * 
     */
    public RegionCode2 createRegionCode2() {
        return new RegionCode2();
    }

    /**
     * Create an instance of {@link TaxTypeCode }
     * 
     */
    public TaxTypeCode createTaxTypeCode() {
        return new TaxTypeCode();
    }

    /**
     * Create an instance of {@link BusinessDocumentMessageID }
     * 
     */
    public BusinessDocumentMessageID createBusinessDocumentMessageID() {
        return new BusinessDocumentMessageID();
    }

    /**
     * Create an instance of {@link ProductTaxStandardClassificationSystemCode }
     * 
     */
    public ProductTaxStandardClassificationSystemCode createProductTaxStandardClassificationSystemCode() {
        return new ProductTaxStandardClassificationSystemCode();
    }

    /**
     * Create an instance of {@link JournalEntryItemPaymentControl }
     * 
     */
    public JournalEntryItemPaymentControl createJournalEntryItemPaymentControl() {
        return new JournalEntryItemPaymentControl();
    }

    /**
     * Create an instance of {@link UUID }
     * 
     */
    public UUID createUUID() {
        return new UUID();
    }

    /**
     * Create an instance of {@link JournalEntryItemTax }
     * 
     */
    public JournalEntryItemTax createJournalEntryItemTax() {
        return new JournalEntryItemTax();
    }

    /**
     * Create an instance of {@link Log }
     * 
     */
    public Log createLog() {
        return new Log();
    }

    /**
     * Create an instance of {@link ProductTaxStandardClassificationCode }
     * 
     */
    public ProductTaxStandardClassificationCode createProductTaxStandardClassificationCode() {
        return new ProductTaxStandardClassificationCode();
    }

    /**
     * Create an instance of {@link LogItemCategoryCode }
     * 
     */
    public LogItemCategoryCode createLogItemCategoryCode() {
        return new LogItemCategoryCode();
    }

    /**
     * Create an instance of {@link AccountsPayableDueItemTypeCode }
     * 
     */
    public AccountsPayableDueItemTypeCode createAccountsPayableDueItemTypeCode() {
        return new AccountsPayableDueItemTypeCode();
    }

    /**
     * Create an instance of {@link TaxRateTypeCode }
     * 
     */
    public TaxRateTypeCode createTaxRateTypeCode() {
        return new TaxRateTypeCode();
    }

    /**
     * Create an instance of {@link ProductTaxationCharacteristicsCode }
     * 
     */
    public ProductTaxationCharacteristicsCode createProductTaxationCharacteristicsCode() {
        return new ProductTaxationCharacteristicsCode();
    }

    /**
     * Create an instance of {@link LogItem }
     * 
     */
    public LogItem createLogItem() {
        return new LogItem();
    }

    /**
     * Create an instance of {@link TaxDeductibilityCode }
     * 
     */
    public TaxDeductibilityCode createTaxDeductibilityCode() {
        return new TaxDeductibilityCode();
    }

    /**
     * Create an instance of {@link JournalEntryItemAccountingCodingBlock }
     * 
     */
    public JournalEntryItemAccountingCodingBlock createJournalEntryItemAccountingCodingBlock() {
        return new JournalEntryItemAccountingCodingBlock();
    }

    /**
     * Create an instance of {@link AccountsReceivableDueItemTypeCode }
     * 
     */
    public AccountsReceivableDueItemTypeCode createAccountsReceivableDueItemTypeCode() {
        return new AccountsReceivableDueItemTypeCode();
    }

    /**
     * Create an instance of {@link LogItemNotePlaceholderSubstitutionList }
     * 
     */
    public LogItemNotePlaceholderSubstitutionList createLogItemNotePlaceholderSubstitutionList() {
        return new LogItemNotePlaceholderSubstitutionList();
    }

    /**
     * Create an instance of {@link CostObjectTypeCode }
     * 
     */
    public CostObjectTypeCode createCostObjectTypeCode() {
        return new CostObjectTypeCode();
    }

    /**
     * Create an instance of {@link Amount }
     * 
     */
    public Amount createAmount() {
        return new Amount();
    }

    /**
     * Create an instance of {@link BusinessTransactionDocumentID }
     * 
     */
    public BusinessTransactionDocumentID createBusinessTransactionDocumentID() {
        return new BusinessTransactionDocumentID();
    }

    /**
     * Create an instance of {@link JournalEntryItemCashDiscountTerms }
     * 
     */
    public JournalEntryItemCashDiscountTerms createJournalEntryItemCashDiscountTerms() {
        return new JournalEntryItemCashDiscountTerms();
    }

    /**
     * Create an instance of {@link StandardFaultMessage }
     * 
     */
    public StandardFaultMessage createStandardFaultMessage() {
        return new StandardFaultMessage();
    }

    /**
     * Create an instance of {@link ExchangeFaultData }
     * 
     */
    public ExchangeFaultData createExchangeFaultData() {
        return new ExchangeFaultData();
    }

    /**
     * Create an instance of {@link StandardFaultMessageExtension }
     * 
     */
    public StandardFaultMessageExtension createStandardFaultMessageExtension() {
        return new StandardFaultMessageExtension();
    }

    /**
     * Create an instance of {@link FinancialAccountingViewOfCostObjectKey }
     * 
     */
    public FinancialAccountingViewOfCostObjectKey createFinancialAccountingViewOfCostObjectKey() {
        return new FinancialAccountingViewOfCostObjectKey();
    }

    /**
     * Create an instance of {@link ExchangeLogData }
     * 
     */
    public ExchangeLogData createExchangeLogData() {
        return new ExchangeLogData();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link JournalEntryCreateRequestBundleMessage }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://sap.com/xi/SAPGlobal20/Global", name = "JournalEntryBundleCreateRequest")
    public JAXBElement<JournalEntryCreateRequestBundleMessage> createJournalEntryBundleCreateRequest(JournalEntryCreateRequestBundleMessage value) {
        return new JAXBElement<JournalEntryCreateRequestBundleMessage>(_JournalEntryBundleCreateRequest_QNAME, JournalEntryCreateRequestBundleMessage.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link JournalEntryCreateConfirmationBundleMessage }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://sap.com/xi/SAPGlobal20/Global", name = "JournalEntryBundleCreateConfirmation")
    public JAXBElement<JournalEntryCreateConfirmationBundleMessage> createJournalEntryBundleCreateConfirmation(JournalEntryCreateConfirmationBundleMessage value) {
        return new JAXBElement<JournalEntryCreateConfirmationBundleMessage>(_JournalEntryBundleCreateConfirmation_QNAME, JournalEntryCreateConfirmationBundleMessage.class, null, value);
    }

}
