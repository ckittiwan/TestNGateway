
package com.ntz.byd.gateway.managejournalentry.autogen;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.CollapsedStringAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for JournalEntryCreateRequestBundleJournalEntry complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="JournalEntryCreateRequestBundleJournalEntry">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ObjectNodeSenderTechnicalID" type="{http://sap.com/xi/AP/Common/GDT}ObjectNodePartyTechnicalID" minOccurs="0"/>
 *         &lt;element name="CompanyID" type="{http://sap.com/xi/AP/Common/GDT}OrganisationalCentreID"/>
 *         &lt;element name="OriginalEntryDocumentReferenceID" type="{http://sap.com/xi/Common/DataTypes}BusinessTransactionDocumentID"/>
 *         &lt;element name="OriginalEntryDocumentReferenceBusinessSystemID" type="{http://sap.com/xi/Common/DataTypes}CommunicationSystemParticipatingBusinessSystemID" minOccurs="0"/>
 *         &lt;element name="OriginalEntryDocumentExternalID" type="{http://sap.com/xi/Common/DataTypes}BusinessTransactionDocumentID" minOccurs="0"/>
 *         &lt;element name="DocumentDate" type="{http://sap.com/xi/BASIS/Global}Date" minOccurs="0"/>
 *         &lt;element name="AccountingBusinessTransactionDate" type="{http://sap.com/xi/BASIS/Global}Date"/>
 *         &lt;element name="AccountingBusinessTransactionTypeCode" type="{http://sap.com/xi/AP/FinancialAccounting/Global}AccountingBusinessTransactionTypeCode"/>
 *         &lt;element name="AccountingDocumentTypeCode" type="{http://sap.com/xi/AP/FinancialAccounting/Global}AccountingDocumentTypeCode" minOccurs="0"/>
 *         &lt;element name="Note" type="{http://sap.com/xi/AP/Common/GDT}LANGUAGEINDEPENDENT_SHORT_Note" minOccurs="0"/>
 *         &lt;element name="Item" type="{http://sap.com/xi/A1S/Global}JournalEntryCreateRequestBundleItem" maxOccurs="unbounded"/>
 *         &lt;element name="TaxItem" type="{http://sap.com/xi/A1S/Global}JournalEntryCreateRequestBundleTaxItem" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="DebtorItem" type="{http://sap.com/xi/A1S/Global}JournalEntryCreateRequestBundleDebtorItem" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="CreditorItem" type="{http://sap.com/xi/A1S/Global}JournalEntryCreateRequestBundleCreditorItem" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="CashItem" type="{http://sap.com/xi/A1S/Global}JournalEntryCreateRequestBundleCashItem" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "JournalEntryCreateRequestBundleJournalEntry", namespace = "http://sap.com/xi/A1S/Global", propOrder = {
    "objectNodeSenderTechnicalID",
    "companyID",
    "originalEntryDocumentReferenceID",
    "originalEntryDocumentReferenceBusinessSystemID",
    "originalEntryDocumentExternalID",
    "documentDate",
    "accountingBusinessTransactionDate",
    "accountingBusinessTransactionTypeCode",
    "accountingDocumentTypeCode",
    "note",
    "item",
    "taxItem",
    "debtorItem",
    "creditorItem",
    "cashItem"
})
public class JournalEntryCreateRequestBundleJournalEntry {

    @XmlElement(name = "ObjectNodeSenderTechnicalID")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String objectNodeSenderTechnicalID;
    @XmlElement(name = "CompanyID", required = true)
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String companyID;
    @XmlElement(name = "OriginalEntryDocumentReferenceID", required = true)
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String originalEntryDocumentReferenceID;
    @XmlElement(name = "OriginalEntryDocumentReferenceBusinessSystemID")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String originalEntryDocumentReferenceBusinessSystemID;
    @XmlElement(name = "OriginalEntryDocumentExternalID")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String originalEntryDocumentExternalID;
    @XmlElement(name = "DocumentDate")
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar documentDate;
    @XmlElement(name = "AccountingBusinessTransactionDate", required = true)
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar accountingBusinessTransactionDate;
    @XmlElement(name = "AccountingBusinessTransactionTypeCode", required = true)
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String accountingBusinessTransactionTypeCode;
    @XmlElement(name = "AccountingDocumentTypeCode")
    protected AccountingDocumentTypeCode accountingDocumentTypeCode;
    @XmlElement(name = "Note")
    protected String note;
    @XmlElement(name = "Item", required = true)
    protected List<JournalEntryCreateRequestBundleItem> item;
    @XmlElement(name = "TaxItem")
    protected List<JournalEntryCreateRequestBundleTaxItem> taxItem;
    @XmlElement(name = "DebtorItem")
    protected List<JournalEntryCreateRequestBundleDebtorItem> debtorItem;
    @XmlElement(name = "CreditorItem")
    protected List<JournalEntryCreateRequestBundleCreditorItem> creditorItem;
    @XmlElement(name = "CashItem")
    protected List<JournalEntryCreateRequestBundleCashItem> cashItem;

    /**
     * Gets the value of the objectNodeSenderTechnicalID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getObjectNodeSenderTechnicalID() {
        return objectNodeSenderTechnicalID;
    }

    /**
     * Sets the value of the objectNodeSenderTechnicalID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setObjectNodeSenderTechnicalID(String value) {
        this.objectNodeSenderTechnicalID = value;
    }

    /**
     * Gets the value of the companyID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCompanyID() {
        return companyID;
    }

    /**
     * Sets the value of the companyID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCompanyID(String value) {
        this.companyID = value;
    }

    /**
     * Gets the value of the originalEntryDocumentReferenceID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOriginalEntryDocumentReferenceID() {
        return originalEntryDocumentReferenceID;
    }

    /**
     * Sets the value of the originalEntryDocumentReferenceID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOriginalEntryDocumentReferenceID(String value) {
        this.originalEntryDocumentReferenceID = value;
    }

    /**
     * Gets the value of the originalEntryDocumentReferenceBusinessSystemID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOriginalEntryDocumentReferenceBusinessSystemID() {
        return originalEntryDocumentReferenceBusinessSystemID;
    }

    /**
     * Sets the value of the originalEntryDocumentReferenceBusinessSystemID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOriginalEntryDocumentReferenceBusinessSystemID(String value) {
        this.originalEntryDocumentReferenceBusinessSystemID = value;
    }

    /**
     * Gets the value of the originalEntryDocumentExternalID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOriginalEntryDocumentExternalID() {
        return originalEntryDocumentExternalID;
    }

    /**
     * Sets the value of the originalEntryDocumentExternalID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOriginalEntryDocumentExternalID(String value) {
        this.originalEntryDocumentExternalID = value;
    }

    /**
     * Gets the value of the documentDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDocumentDate() {
        return documentDate;
    }

    /**
     * Sets the value of the documentDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDocumentDate(XMLGregorianCalendar value) {
        this.documentDate = value;
    }

    /**
     * Gets the value of the accountingBusinessTransactionDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getAccountingBusinessTransactionDate() {
        return accountingBusinessTransactionDate;
    }

    /**
     * Sets the value of the accountingBusinessTransactionDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setAccountingBusinessTransactionDate(XMLGregorianCalendar value) {
        this.accountingBusinessTransactionDate = value;
    }

    /**
     * Gets the value of the accountingBusinessTransactionTypeCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccountingBusinessTransactionTypeCode() {
        return accountingBusinessTransactionTypeCode;
    }

    /**
     * Sets the value of the accountingBusinessTransactionTypeCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccountingBusinessTransactionTypeCode(String value) {
        this.accountingBusinessTransactionTypeCode = value;
    }

    /**
     * Gets the value of the accountingDocumentTypeCode property.
     * 
     * @return
     *     possible object is
     *     {@link AccountingDocumentTypeCode }
     *     
     */
    public AccountingDocumentTypeCode getAccountingDocumentTypeCode() {
        return accountingDocumentTypeCode;
    }

    /**
     * Sets the value of the accountingDocumentTypeCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link AccountingDocumentTypeCode }
     *     
     */
    public void setAccountingDocumentTypeCode(AccountingDocumentTypeCode value) {
        this.accountingDocumentTypeCode = value;
    }

    /**
     * Gets the value of the note property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNote() {
        return note;
    }

    /**
     * Sets the value of the note property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNote(String value) {
        this.note = value;
    }

    /**
     * Gets the value of the item property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the item property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getItem().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link JournalEntryCreateRequestBundleItem }
     * 
     * 
     */
    public List<JournalEntryCreateRequestBundleItem> getItem() {
        if (item == null) {
            item = new ArrayList<JournalEntryCreateRequestBundleItem>();
        }
        return this.item;
    }

    /**
     * Gets the value of the taxItem property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the taxItem property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getTaxItem().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link JournalEntryCreateRequestBundleTaxItem }
     * 
     * 
     */
    public List<JournalEntryCreateRequestBundleTaxItem> getTaxItem() {
        if (taxItem == null) {
            taxItem = new ArrayList<JournalEntryCreateRequestBundleTaxItem>();
        }
        return this.taxItem;
    }

    /**
     * Gets the value of the debtorItem property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the debtorItem property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDebtorItem().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link JournalEntryCreateRequestBundleDebtorItem }
     * 
     * 
     */
    public List<JournalEntryCreateRequestBundleDebtorItem> getDebtorItem() {
        if (debtorItem == null) {
            debtorItem = new ArrayList<JournalEntryCreateRequestBundleDebtorItem>();
        }
        return this.debtorItem;
    }

    /**
     * Gets the value of the creditorItem property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the creditorItem property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCreditorItem().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link JournalEntryCreateRequestBundleCreditorItem }
     * 
     * 
     */
    public List<JournalEntryCreateRequestBundleCreditorItem> getCreditorItem() {
        if (creditorItem == null) {
            creditorItem = new ArrayList<JournalEntryCreateRequestBundleCreditorItem>();
        }
        return this.creditorItem;
    }

    /**
     * Gets the value of the cashItem property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the cashItem property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCashItem().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link JournalEntryCreateRequestBundleCashItem }
     * 
     * 
     */
    public List<JournalEntryCreateRequestBundleCashItem> getCashItem() {
        if (cashItem == null) {
            cashItem = new ArrayList<JournalEntryCreateRequestBundleCashItem>();
        }
        return this.cashItem;
    }

}
