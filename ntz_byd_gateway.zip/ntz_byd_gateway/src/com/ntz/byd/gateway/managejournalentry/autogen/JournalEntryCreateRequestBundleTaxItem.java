
package com.ntz.byd.gateway.managejournalentry.autogen;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.CollapsedStringAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;


/**
 * <p>Java class for JournalEntryCreateRequestBundleTaxItem complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="JournalEntryCreateRequestBundleTaxItem">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ObjectNodeSenderTechnicalID" type="{http://sap.com/xi/AP/Common/GDT}ObjectNodePartyTechnicalID" minOccurs="0"/>
 *         &lt;element name="OriginalEntryDocumentItemReferenceItemID" type="{http://sap.com/xi/Common/DataTypes}BusinessTransactionDocumentItemID" minOccurs="0"/>
 *         &lt;element name="TaxCountryCode" type="{http://sap.com/xi/AP/Common/GDT}CountryCode"/>
 *         &lt;element name="ProductTaxationCharacteristicsCode" type="{http://sap.com/xi/AP/Common/GDT}ProductTaxationCharacteristicsCode" minOccurs="0"/>
 *         &lt;element name="DeferredIndicator" type="{http://sap.com/xi/AP/Common/GDT}Indicator" minOccurs="0"/>
 *         &lt;element name="TaxJurisdictionCode" type="{http://sap.com/xi/Common/DataTypes}TaxJurisdictionCode" minOccurs="0"/>
 *         &lt;element name="TaxRegionCode" type="{http://sap.com/xi/Common/DataTypes}RegionCode" minOccurs="0"/>
 *         &lt;element name="ProductTaxStandardClassificationSystemCode" type="{http://sap.com/xi/AP/Common/GDT}ProductTaxStandardClassificationSystemCode" minOccurs="0"/>
 *         &lt;element name="ProductTaxStandardClassificationCode" type="{http://sap.com/xi/AP/Common/GDT}ProductTaxStandardClassificationCode" minOccurs="0"/>
 *         &lt;element name="TaxReportingUnitID" type="{http://sap.com/xi/AP/Common/GDT}OrganisationalCentreID" minOccurs="0"/>
 *         &lt;element name="DueCategoryCode" type="{http://sap.com/xi/AP/Common/GDT}DueCategoryCode" minOccurs="0"/>
 *         &lt;element name="TaxTypeCode" type="{http://sap.com/xi/AP/Common/GDT}TaxTypeCode" minOccurs="0"/>
 *         &lt;element name="TaxRateTypeCode" type="{http://sap.com/xi/AP/Common/GDT}TaxRateTypeCode" minOccurs="0"/>
 *         &lt;element name="TaxDeductibilityCode" type="{http://sap.com/xi/AP/Common/GDT}TaxDeductibilityCode" minOccurs="0"/>
 *         &lt;element name="TaxItemGroupID" type="{http://sap.com/xi/AP/Common/GDT}BusinessTransactionDocumentItemGroupID" minOccurs="0"/>
 *         &lt;element name="Note" type="{http://sap.com/xi/AP/Common/GDT}LANGUAGEINDEPENDENT_SHORT_Note" minOccurs="0"/>
 *         &lt;element name="BusinessTransactionCurrencyAmount" type="{http://sap.com/xi/AP/Common/GDT}Amount"/>
 *         &lt;element name="BusinessTransactionCurrencyNonDeductibleAmount" type="{http://sap.com/xi/AP/Common/GDT}Amount" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "JournalEntryCreateRequestBundleTaxItem", namespace = "http://sap.com/xi/A1S/Global", propOrder = {
    "objectNodeSenderTechnicalID",
    "originalEntryDocumentItemReferenceItemID",
    "taxCountryCode",
    "productTaxationCharacteristicsCode",
    "deferredIndicator",
    "taxJurisdictionCode",
    "taxRegionCode",
    "productTaxStandardClassificationSystemCode",
    "productTaxStandardClassificationCode",
    "taxReportingUnitID",
    "dueCategoryCode",
    "taxTypeCode",
    "taxRateTypeCode",
    "taxDeductibilityCode",
    "taxItemGroupID",
    "note",
    "businessTransactionCurrencyAmount",
    "businessTransactionCurrencyNonDeductibleAmount"
})
public class JournalEntryCreateRequestBundleTaxItem {

    @XmlElement(name = "ObjectNodeSenderTechnicalID")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String objectNodeSenderTechnicalID;
    @XmlElement(name = "OriginalEntryDocumentItemReferenceItemID")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String originalEntryDocumentItemReferenceItemID;
    @XmlElement(name = "TaxCountryCode", required = true)
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String taxCountryCode;
    @XmlElement(name = "ProductTaxationCharacteristicsCode")
    protected ProductTaxationCharacteristicsCode productTaxationCharacteristicsCode;
    @XmlElement(name = "DeferredIndicator")
    protected Boolean deferredIndicator;
    @XmlElement(name = "TaxJurisdictionCode")
    protected TaxJurisdictionCode taxJurisdictionCode;
    @XmlElement(name = "TaxRegionCode")
    protected RegionCode taxRegionCode;
    @XmlElement(name = "ProductTaxStandardClassificationSystemCode")
    protected ProductTaxStandardClassificationSystemCode productTaxStandardClassificationSystemCode;
    @XmlElement(name = "ProductTaxStandardClassificationCode")
    protected ProductTaxStandardClassificationCode productTaxStandardClassificationCode;
    @XmlElement(name = "TaxReportingUnitID")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String taxReportingUnitID;
    @XmlElement(name = "DueCategoryCode")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String dueCategoryCode;
    @XmlElement(name = "TaxTypeCode")
    protected TaxTypeCode taxTypeCode;
    @XmlElement(name = "TaxRateTypeCode")
    protected TaxRateTypeCode taxRateTypeCode;
    @XmlElement(name = "TaxDeductibilityCode")
    protected TaxDeductibilityCode taxDeductibilityCode;
    @XmlElement(name = "TaxItemGroupID")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String taxItemGroupID;
    @XmlElement(name = "Note")
    protected String note;
    @XmlElement(name = "BusinessTransactionCurrencyAmount", required = true)
    protected Amount businessTransactionCurrencyAmount;
    @XmlElement(name = "BusinessTransactionCurrencyNonDeductibleAmount")
    protected Amount businessTransactionCurrencyNonDeductibleAmount;

    /**
     * Gets the value of the objectNodeSenderTechnicalID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getObjectNodeSenderTechnicalID() {
        return objectNodeSenderTechnicalID;
    }

    /**
     * Sets the value of the objectNodeSenderTechnicalID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setObjectNodeSenderTechnicalID(String value) {
        this.objectNodeSenderTechnicalID = value;
    }

    /**
     * Gets the value of the originalEntryDocumentItemReferenceItemID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOriginalEntryDocumentItemReferenceItemID() {
        return originalEntryDocumentItemReferenceItemID;
    }

    /**
     * Sets the value of the originalEntryDocumentItemReferenceItemID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOriginalEntryDocumentItemReferenceItemID(String value) {
        this.originalEntryDocumentItemReferenceItemID = value;
    }

    /**
     * Gets the value of the taxCountryCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTaxCountryCode() {
        return taxCountryCode;
    }

    /**
     * Sets the value of the taxCountryCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTaxCountryCode(String value) {
        this.taxCountryCode = value;
    }

    /**
     * Gets the value of the productTaxationCharacteristicsCode property.
     * 
     * @return
     *     possible object is
     *     {@link ProductTaxationCharacteristicsCode }
     *     
     */
    public ProductTaxationCharacteristicsCode getProductTaxationCharacteristicsCode() {
        return productTaxationCharacteristicsCode;
    }

    /**
     * Sets the value of the productTaxationCharacteristicsCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link ProductTaxationCharacteristicsCode }
     *     
     */
    public void setProductTaxationCharacteristicsCode(ProductTaxationCharacteristicsCode value) {
        this.productTaxationCharacteristicsCode = value;
    }

    /**
     * Gets the value of the deferredIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isDeferredIndicator() {
        return deferredIndicator;
    }

    /**
     * Sets the value of the deferredIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setDeferredIndicator(Boolean value) {
        this.deferredIndicator = value;
    }

    /**
     * Gets the value of the taxJurisdictionCode property.
     * 
     * @return
     *     possible object is
     *     {@link TaxJurisdictionCode }
     *     
     */
    public TaxJurisdictionCode getTaxJurisdictionCode() {
        return taxJurisdictionCode;
    }

    /**
     * Sets the value of the taxJurisdictionCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link TaxJurisdictionCode }
     *     
     */
    public void setTaxJurisdictionCode(TaxJurisdictionCode value) {
        this.taxJurisdictionCode = value;
    }

    /**
     * Gets the value of the taxRegionCode property.
     * 
     * @return
     *     possible object is
     *     {@link RegionCode }
     *     
     */
    public RegionCode getTaxRegionCode() {
        return taxRegionCode;
    }

    /**
     * Sets the value of the taxRegionCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link RegionCode }
     *     
     */
    public void setTaxRegionCode(RegionCode value) {
        this.taxRegionCode = value;
    }

    /**
     * Gets the value of the productTaxStandardClassificationSystemCode property.
     * 
     * @return
     *     possible object is
     *     {@link ProductTaxStandardClassificationSystemCode }
     *     
     */
    public ProductTaxStandardClassificationSystemCode getProductTaxStandardClassificationSystemCode() {
        return productTaxStandardClassificationSystemCode;
    }

    /**
     * Sets the value of the productTaxStandardClassificationSystemCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link ProductTaxStandardClassificationSystemCode }
     *     
     */
    public void setProductTaxStandardClassificationSystemCode(ProductTaxStandardClassificationSystemCode value) {
        this.productTaxStandardClassificationSystemCode = value;
    }

    /**
     * Gets the value of the productTaxStandardClassificationCode property.
     * 
     * @return
     *     possible object is
     *     {@link ProductTaxStandardClassificationCode }
     *     
     */
    public ProductTaxStandardClassificationCode getProductTaxStandardClassificationCode() {
        return productTaxStandardClassificationCode;
    }

    /**
     * Sets the value of the productTaxStandardClassificationCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link ProductTaxStandardClassificationCode }
     *     
     */
    public void setProductTaxStandardClassificationCode(ProductTaxStandardClassificationCode value) {
        this.productTaxStandardClassificationCode = value;
    }

    /**
     * Gets the value of the taxReportingUnitID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTaxReportingUnitID() {
        return taxReportingUnitID;
    }

    /**
     * Sets the value of the taxReportingUnitID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTaxReportingUnitID(String value) {
        this.taxReportingUnitID = value;
    }

    /**
     * Gets the value of the dueCategoryCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDueCategoryCode() {
        return dueCategoryCode;
    }

    /**
     * Sets the value of the dueCategoryCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDueCategoryCode(String value) {
        this.dueCategoryCode = value;
    }

    /**
     * Gets the value of the taxTypeCode property.
     * 
     * @return
     *     possible object is
     *     {@link TaxTypeCode }
     *     
     */
    public TaxTypeCode getTaxTypeCode() {
        return taxTypeCode;
    }

    /**
     * Sets the value of the taxTypeCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link TaxTypeCode }
     *     
     */
    public void setTaxTypeCode(TaxTypeCode value) {
        this.taxTypeCode = value;
    }

    /**
     * Gets the value of the taxRateTypeCode property.
     * 
     * @return
     *     possible object is
     *     {@link TaxRateTypeCode }
     *     
     */
    public TaxRateTypeCode getTaxRateTypeCode() {
        return taxRateTypeCode;
    }

    /**
     * Sets the value of the taxRateTypeCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link TaxRateTypeCode }
     *     
     */
    public void setTaxRateTypeCode(TaxRateTypeCode value) {
        this.taxRateTypeCode = value;
    }

    /**
     * Gets the value of the taxDeductibilityCode property.
     * 
     * @return
     *     possible object is
     *     {@link TaxDeductibilityCode }
     *     
     */
    public TaxDeductibilityCode getTaxDeductibilityCode() {
        return taxDeductibilityCode;
    }

    /**
     * Sets the value of the taxDeductibilityCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link TaxDeductibilityCode }
     *     
     */
    public void setTaxDeductibilityCode(TaxDeductibilityCode value) {
        this.taxDeductibilityCode = value;
    }

    /**
     * Gets the value of the taxItemGroupID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTaxItemGroupID() {
        return taxItemGroupID;
    }

    /**
     * Sets the value of the taxItemGroupID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTaxItemGroupID(String value) {
        this.taxItemGroupID = value;
    }

    /**
     * Gets the value of the note property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNote() {
        return note;
    }

    /**
     * Sets the value of the note property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNote(String value) {
        this.note = value;
    }

    /**
     * Gets the value of the businessTransactionCurrencyAmount property.
     * 
     * @return
     *     possible object is
     *     {@link Amount }
     *     
     */
    public Amount getBusinessTransactionCurrencyAmount() {
        return businessTransactionCurrencyAmount;
    }

    /**
     * Sets the value of the businessTransactionCurrencyAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link Amount }
     *     
     */
    public void setBusinessTransactionCurrencyAmount(Amount value) {
        this.businessTransactionCurrencyAmount = value;
    }

    /**
     * Gets the value of the businessTransactionCurrencyNonDeductibleAmount property.
     * 
     * @return
     *     possible object is
     *     {@link Amount }
     *     
     */
    public Amount getBusinessTransactionCurrencyNonDeductibleAmount() {
        return businessTransactionCurrencyNonDeductibleAmount;
    }

    /**
     * Sets the value of the businessTransactionCurrencyNonDeductibleAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link Amount }
     *     
     */
    public void setBusinessTransactionCurrencyNonDeductibleAmount(Amount value) {
        this.businessTransactionCurrencyNonDeductibleAmount = value;
    }

}
