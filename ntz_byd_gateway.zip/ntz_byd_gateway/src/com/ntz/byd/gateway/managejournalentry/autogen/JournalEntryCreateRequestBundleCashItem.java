
package com.ntz.byd.gateway.managejournalentry.autogen;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.CollapsedStringAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;


/**
 * <p>Java class for JournalEntryCreateRequestBundleCashItem complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="JournalEntryCreateRequestBundleCashItem">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ObjectNodeSenderTechnicalID" type="{http://sap.com/xi/AP/Common/GDT}ObjectNodePartyTechnicalID" minOccurs="0"/>
 *         &lt;element name="OriginalEntryDocumentItemReferenceItemID" type="{http://sap.com/xi/Common/DataTypes}BusinessTransactionDocumentItemID" minOccurs="0"/>
 *         &lt;element name="CashPayment" type="{http://sap.com/xi/AP/FinancialAccounting/Global}JournalEntryCashItemCashPayment" minOccurs="0"/>
 *         &lt;element name="PayerBusinessPartnerInternalID" type="{http://sap.com/xi/Common/DataTypes}BusinessPartnerInternalID" minOccurs="0"/>
 *         &lt;element name="PayeeBusinessPartnerInternalID" type="{http://sap.com/xi/Common/DataTypes}BusinessPartnerInternalID" minOccurs="0"/>
 *         &lt;element name="Note" type="{http://sap.com/xi/AP/Common/GDT}LANGUAGEINDEPENDENT_SHORT_Note" minOccurs="0"/>
 *         &lt;element name="BusinessTransactionCurrencyAmount" type="{http://sap.com/xi/AP/Common/GDT}Amount"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "JournalEntryCreateRequestBundleCashItem", namespace = "http://sap.com/xi/A1S/Global", propOrder = {
    "objectNodeSenderTechnicalID",
    "originalEntryDocumentItemReferenceItemID",
    "cashPayment",
    "payerBusinessPartnerInternalID",
    "payeeBusinessPartnerInternalID",
    "note",
    "businessTransactionCurrencyAmount"
})
public class JournalEntryCreateRequestBundleCashItem {

    @XmlElement(name = "ObjectNodeSenderTechnicalID")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String objectNodeSenderTechnicalID;
    @XmlElement(name = "OriginalEntryDocumentItemReferenceItemID")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String originalEntryDocumentItemReferenceItemID;
    @XmlElement(name = "CashPayment")
    protected JournalEntryCashItemCashPayment cashPayment;
    @XmlElement(name = "PayerBusinessPartnerInternalID")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String payerBusinessPartnerInternalID;
    @XmlElement(name = "PayeeBusinessPartnerInternalID")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String payeeBusinessPartnerInternalID;
    @XmlElement(name = "Note")
    protected String note;
    @XmlElement(name = "BusinessTransactionCurrencyAmount", required = true)
    protected Amount businessTransactionCurrencyAmount;

    /**
     * Gets the value of the objectNodeSenderTechnicalID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getObjectNodeSenderTechnicalID() {
        return objectNodeSenderTechnicalID;
    }

    /**
     * Sets the value of the objectNodeSenderTechnicalID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setObjectNodeSenderTechnicalID(String value) {
        this.objectNodeSenderTechnicalID = value;
    }

    /**
     * Gets the value of the originalEntryDocumentItemReferenceItemID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOriginalEntryDocumentItemReferenceItemID() {
        return originalEntryDocumentItemReferenceItemID;
    }

    /**
     * Sets the value of the originalEntryDocumentItemReferenceItemID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOriginalEntryDocumentItemReferenceItemID(String value) {
        this.originalEntryDocumentItemReferenceItemID = value;
    }

    /**
     * Gets the value of the cashPayment property.
     * 
     * @return
     *     possible object is
     *     {@link JournalEntryCashItemCashPayment }
     *     
     */
    public JournalEntryCashItemCashPayment getCashPayment() {
        return cashPayment;
    }

    /**
     * Sets the value of the cashPayment property.
     * 
     * @param value
     *     allowed object is
     *     {@link JournalEntryCashItemCashPayment }
     *     
     */
    public void setCashPayment(JournalEntryCashItemCashPayment value) {
        this.cashPayment = value;
    }

    /**
     * Gets the value of the payerBusinessPartnerInternalID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPayerBusinessPartnerInternalID() {
        return payerBusinessPartnerInternalID;
    }

    /**
     * Sets the value of the payerBusinessPartnerInternalID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPayerBusinessPartnerInternalID(String value) {
        this.payerBusinessPartnerInternalID = value;
    }

    /**
     * Gets the value of the payeeBusinessPartnerInternalID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPayeeBusinessPartnerInternalID() {
        return payeeBusinessPartnerInternalID;
    }

    /**
     * Sets the value of the payeeBusinessPartnerInternalID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPayeeBusinessPartnerInternalID(String value) {
        this.payeeBusinessPartnerInternalID = value;
    }

    /**
     * Gets the value of the note property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNote() {
        return note;
    }

    /**
     * Sets the value of the note property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNote(String value) {
        this.note = value;
    }

    /**
     * Gets the value of the businessTransactionCurrencyAmount property.
     * 
     * @return
     *     possible object is
     *     {@link Amount }
     *     
     */
    public Amount getBusinessTransactionCurrencyAmount() {
        return businessTransactionCurrencyAmount;
    }

    /**
     * Sets the value of the businessTransactionCurrencyAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link Amount }
     *     
     */
    public void setBusinessTransactionCurrencyAmount(Amount value) {
        this.businessTransactionCurrencyAmount = value;
    }

}
