
package com.ntz.byd.gateway.managejournalentry.autogen;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.CollapsedStringAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;


/**
 * <p>Java class for JournalEntryCreateRequestBundleItem complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="JournalEntryCreateRequestBundleItem">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ObjectNodeSenderTechnicalID" type="{http://sap.com/xi/AP/Common/GDT}ObjectNodePartyTechnicalID" minOccurs="0"/>
 *         &lt;element name="OriginalEntryDocumentItemReferenceItemID" type="{http://sap.com/xi/Common/DataTypes}BusinessTransactionDocumentItemID" minOccurs="0"/>
 *         &lt;element name="EntryQuantity" type="{http://sap.com/xi/Common/DataTypes}Quantity" minOccurs="0"/>
 *         &lt;element name="ProductInternalID" type="{http://sap.com/xi/Common/DataTypes}ProductInternalID" minOccurs="0"/>
 *         &lt;element name="ProductTypeCode" type="{http://sap.com/xi/AP/Common/GDT}ProductTypeCode" minOccurs="0"/>
 *         &lt;element name="Tax" type="{http://sap.com/xi/AP/Common/GDT}JournalEntryItemTax" minOccurs="0"/>
 *         &lt;element name="GeneralLedgerAccountAliasCode" type="{http://sap.com/xi/Common/DataTypes}GeneralLedgerAccountAliasCode" minOccurs="0"/>
 *         &lt;element name="AccountingCodingBlock" type="{http://sap.com/xi/AP/Common/GDT}JournalEntryItemAccountingCodingBlock" minOccurs="0"/>
 *         &lt;element name="Note" type="{http://sap.com/xi/AP/Common/GDT}LANGUAGEINDEPENDENT_SHORT_Note" minOccurs="0"/>
 *         &lt;element name="BusinessTransactionCurrencyAmount" type="{http://sap.com/xi/AP/Common/GDT}Amount"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "JournalEntryCreateRequestBundleItem", namespace = "http://sap.com/xi/A1S/Global", propOrder = {
    "objectNodeSenderTechnicalID",
    "originalEntryDocumentItemReferenceItemID",
    "entryQuantity",
    "productInternalID",
    "productTypeCode",
    "tax",
    "generalLedgerAccountAliasCode",
    "accountingCodingBlock",
    "note",
    "businessTransactionCurrencyAmount"
})
public class JournalEntryCreateRequestBundleItem {

    @XmlElement(name = "ObjectNodeSenderTechnicalID")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String objectNodeSenderTechnicalID;
    @XmlElement(name = "OriginalEntryDocumentItemReferenceItemID")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String originalEntryDocumentItemReferenceItemID;
    @XmlElement(name = "EntryQuantity")
    protected Quantity entryQuantity;
    @XmlElement(name = "ProductInternalID")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String productInternalID;
    @XmlElement(name = "ProductTypeCode")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String productTypeCode;
    @XmlElement(name = "Tax")
    protected JournalEntryItemTax tax;
    @XmlElement(name = "GeneralLedgerAccountAliasCode")
    protected GeneralLedgerAccountAliasCode generalLedgerAccountAliasCode;
    @XmlElement(name = "AccountingCodingBlock")
    protected JournalEntryItemAccountingCodingBlock accountingCodingBlock;
    @XmlElement(name = "Note")
    protected String note;
    @XmlElement(name = "BusinessTransactionCurrencyAmount", required = true)
    protected Amount businessTransactionCurrencyAmount;

    /**
     * Gets the value of the objectNodeSenderTechnicalID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getObjectNodeSenderTechnicalID() {
        return objectNodeSenderTechnicalID;
    }

    /**
     * Sets the value of the objectNodeSenderTechnicalID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setObjectNodeSenderTechnicalID(String value) {
        this.objectNodeSenderTechnicalID = value;
    }

    /**
     * Gets the value of the originalEntryDocumentItemReferenceItemID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOriginalEntryDocumentItemReferenceItemID() {
        return originalEntryDocumentItemReferenceItemID;
    }

    /**
     * Sets the value of the originalEntryDocumentItemReferenceItemID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOriginalEntryDocumentItemReferenceItemID(String value) {
        this.originalEntryDocumentItemReferenceItemID = value;
    }

    /**
     * Gets the value of the entryQuantity property.
     * 
     * @return
     *     possible object is
     *     {@link Quantity }
     *     
     */
    public Quantity getEntryQuantity() {
        return entryQuantity;
    }

    /**
     * Sets the value of the entryQuantity property.
     * 
     * @param value
     *     allowed object is
     *     {@link Quantity }
     *     
     */
    public void setEntryQuantity(Quantity value) {
        this.entryQuantity = value;
    }

    /**
     * Gets the value of the productInternalID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProductInternalID() {
        return productInternalID;
    }

    /**
     * Sets the value of the productInternalID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProductInternalID(String value) {
        this.productInternalID = value;
    }

    /**
     * Gets the value of the productTypeCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProductTypeCode() {
        return productTypeCode;
    }

    /**
     * Sets the value of the productTypeCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProductTypeCode(String value) {
        this.productTypeCode = value;
    }

    /**
     * Gets the value of the tax property.
     * 
     * @return
     *     possible object is
     *     {@link JournalEntryItemTax }
     *     
     */
    public JournalEntryItemTax getTax() {
        return tax;
    }

    /**
     * Sets the value of the tax property.
     * 
     * @param value
     *     allowed object is
     *     {@link JournalEntryItemTax }
     *     
     */
    public void setTax(JournalEntryItemTax value) {
        this.tax = value;
    }

    /**
     * Gets the value of the generalLedgerAccountAliasCode property.
     * 
     * @return
     *     possible object is
     *     {@link GeneralLedgerAccountAliasCode }
     *     
     */
    public GeneralLedgerAccountAliasCode getGeneralLedgerAccountAliasCode() {
        return generalLedgerAccountAliasCode;
    }

    /**
     * Sets the value of the generalLedgerAccountAliasCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link GeneralLedgerAccountAliasCode }
     *     
     */
    public void setGeneralLedgerAccountAliasCode(GeneralLedgerAccountAliasCode value) {
        this.generalLedgerAccountAliasCode = value;
    }

    /**
     * Gets the value of the accountingCodingBlock property.
     * 
     * @return
     *     possible object is
     *     {@link JournalEntryItemAccountingCodingBlock }
     *     
     */
    public JournalEntryItemAccountingCodingBlock getAccountingCodingBlock() {
        return accountingCodingBlock;
    }

    /**
     * Sets the value of the accountingCodingBlock property.
     * 
     * @param value
     *     allowed object is
     *     {@link JournalEntryItemAccountingCodingBlock }
     *     
     */
    public void setAccountingCodingBlock(JournalEntryItemAccountingCodingBlock value) {
        this.accountingCodingBlock = value;
    }

    /**
     * Gets the value of the note property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNote() {
        return note;
    }

    /**
     * Sets the value of the note property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNote(String value) {
        this.note = value;
    }

    /**
     * Gets the value of the businessTransactionCurrencyAmount property.
     * 
     * @return
     *     possible object is
     *     {@link Amount }
     *     
     */
    public Amount getBusinessTransactionCurrencyAmount() {
        return businessTransactionCurrencyAmount;
    }

    /**
     * Sets the value of the businessTransactionCurrencyAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link Amount }
     *     
     */
    public void setBusinessTransactionCurrencyAmount(Amount value) {
        this.businessTransactionCurrencyAmount = value;
    }

}
