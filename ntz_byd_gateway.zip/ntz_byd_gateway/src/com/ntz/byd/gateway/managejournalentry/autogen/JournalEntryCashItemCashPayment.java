
package com.ntz.byd.gateway.managejournalentry.autogen;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.CollapsedStringAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;


/**
 * <p>Java class for JournalEntryCashItemCashPayment complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="JournalEntryCashItemCashPayment">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="CashStorageID" type="{http://sap.com/xi/Common/DataTypes}CashStorageID"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "JournalEntryCashItemCashPayment", namespace = "http://sap.com/xi/AP/FinancialAccounting/Global", propOrder = {
    "cashStorageID"
})
public class JournalEntryCashItemCashPayment {

    @XmlElement(name = "CashStorageID", required = true)
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String cashStorageID;

    /**
     * Gets the value of the cashStorageID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCashStorageID() {
        return cashStorageID;
    }

    /**
     * Sets the value of the cashStorageID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCashStorageID(String value) {
        this.cashStorageID = value;
    }

}
