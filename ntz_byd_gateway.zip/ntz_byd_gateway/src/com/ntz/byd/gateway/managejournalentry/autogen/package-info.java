@javax.xml.bind.annotation.XmlSchema(namespace = "http://sap.com/xi/AP/Common/GDT")
package com.ntz.byd.gateway.managejournalentry.autogen;
