/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ntz.byd.gateway.managejournalentry;

import com.google.gson.Gson;
import com.ntz.byd.gateway.ExternalRestCaller;
import com.ntz.byd.gateway.db.MySQLDB;
import com.ntz.byd.gateway.managejournalentry.autogen.AccountingDocumentTypeCode;
import com.ntz.byd.gateway.managejournalentry.autogen.Amount;
import com.ntz.byd.gateway.managejournalentry.autogen.BusinessDocumentBasicMessageHeader;
import com.ntz.byd.gateway.managejournalentry.autogen.GeneralLedgerAccountAliasCode;
import com.ntz.byd.gateway.managejournalentry.autogen.JournalEntryCreateConfirmationBundleMessage;
import com.ntz.byd.gateway.managejournalentry.autogen.JournalEntryCreateRequestBundleItem;
import com.ntz.byd.gateway.managejournalentry.autogen.JournalEntryCreateRequestBundleJournalEntry;
import com.ntz.byd.gateway.managejournalentry.autogen.JournalEntryCreateRequestBundleMessage;
import com.ntz.byd.gateway.managejournalentry.autogen.JournalEntryItemAccountingCodingBlock;
import com.ntz.byd.gateway.managejournalentry.autogen.ManageJournalEntryIn;
import com.ntz.byd.gateway.managejournalentry.autogen.StandardFaultMessage_Exception;
import java.math.BigDecimal;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.ws.BindingProvider;

/**
 *
 * @author NTZ_Admin
 */
public class ManageJournalEntryRunner implements Runnable{
    
    private Hashtable _systemht = null;
    
    public ManageJournalEntryRunner(Hashtable _ht)
    {
        this._systemht = _ht;
    }

    @Override
    public void run() {
        ArrayList<Hashtable> journal_doc_list = null;
        try {
             journal_doc_list = get_journal_doc_list();
        } catch (Exception ex) {
            Logger.getLogger(ManageJournalEntryRunner.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        
        
        for(int i = 0 ; i < journal_doc_list.size();i++ )
        {
            Hashtable doc_ht = journal_doc_list.get(i);
            
            String sap_interface_status = "S";
            String external_interface_status = "N";
            String sap_error_msg = "";
            
            try 
            {
                JournalEntryCreateConfirmationBundleMessage resp = interfaceSAP(composeMessage(doc_ht));
                System.out.println(resp.getLog());
                if(resp.getLog().getMaximumLogItemSeverityCode() != null && resp.getLog().getMaximumLogItemSeverityCode().equals("3"))
                {
                   sap_interface_status = "E";
                   external_interface_status = "W";
                   
                   for(int j = 0 ; j < resp.getLog().getItem().size(); j++)
                   {
                       if(!sap_error_msg.equals("")) sap_error_msg += ", ";
                       
                       sap_error_msg += resp.getLog().getItem().get(j).getNote();
                   }
                }
                
            }
            catch (StandardFaultMessage_Exception ex) 
            {
                sap_interface_status = "E";
                external_interface_status = "W";
                Logger.getLogger(ManageJournalEntryRunner.class.getName()).log(Level.SEVERE, null, ex);
            } 
            catch (Exception ex) 
            {
                sap_interface_status = "E";
                external_interface_status = "W";
                Logger.getLogger(ManageJournalEntryRunner.class.getName()).log(Level.SEVERE, null, ex);
            } 
            finally
            {
                try {
                    update_interface_status(sap_interface_status,external_interface_status,sap_error_msg, (String) doc_ht.get("doc_id"));
                } catch (Exception ex) {
                    Logger.getLogger(ManageJournalEntryRunner.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
           
        
        }
        
        
        
        try {
            //send_error_doc_to_external_system
            send_error_doc_to_external_system();
        } catch (Exception ex) {
            Logger.getLogger(ManageJournalEntryRunner.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    private void update_interface_status(String sap_interface_status,String external_interface_status, String sap_error_msg, String id) throws Exception {
        MySQLDB db = new MySQLDB();
        db.connect();
        String sql = "update t_journal_entry set sap_interface_status = ? , sap_interface_error_msg = ? , external_interface_status = ? ,sap_interface_datetime = NOW() "
                + " where doc_id = ? ";
        
        db.createPrepareStatement(sql);
        db.bindValue(1, sap_interface_status);
        db.bindValue(2, sap_error_msg);
        db.bindValue(3, external_interface_status);
        db.bindValue(4, id);
        db.executeUpdate();
        
        
        db.disconnect();
    }

    private ArrayList<Hashtable> get_journal_doc_list() throws Exception {
       String sql = "select * from t_journal_entry where sap_interface_status = 'W' AND system_id = ? ";
       MySQLDB db = new MySQLDB();
       db.connect();
       db.createPrepareStatement(sql);
       db.bindValue(1, (String) this._systemht.get("system_id"));
       
       ResultSet res = db.executeQuery();
       
       ArrayList list = db.buildList(res);
       
       db.disconnect();
       
       return list;
    }
    
    private ArrayList<Hashtable<String, String>> get_journal_doc_items(String doc_id) throws Exception {
       String sql = "select * from t_journal_entry_item where doc_id = ? ";
       MySQLDB db = new MySQLDB();
       db.connect();
       db.createPrepareStatement(sql);
       db.bindValue(1, doc_id);
       
       ResultSet res = db.executeQuery();
       
       ArrayList list = db.buildList(res);
       
       db.disconnect();
       
       return list;
    }
    
    
    private JournalEntryCreateRequestBundleMessage composeMessage(Hashtable<String, String> ht) throws DatatypeConfigurationException, Exception
    {
        JournalEntryCreateRequestBundleMessage request = new JournalEntryCreateRequestBundleMessage();
        request.setBasicMessageHeader(new BusinessDocumentBasicMessageHeader());
        JournalEntryCreateRequestBundleJournalEntry jv = new JournalEntryCreateRequestBundleJournalEntry();
        request.getJournalEntry().add(jv);
        
        jv.setCompanyID(ht.get("company_id"));
        jv.setOriginalEntryDocumentReferenceID(ht.get("original_entry_document_reference_id"));
        jv.setOriginalEntryDocumentReferenceBusinessSystemID(ht.get("original_entry_document_reference_business_system_id"));
        jv.setAccountingBusinessTransactionDate(DatatypeFactory.newInstance().newXMLGregorianCalendar(ht.get("accounting_business_transaction_date")));
        jv.setAccountingBusinessTransactionTypeCode("701");
        jv.setAccountingDocumentTypeCode(new AccountingDocumentTypeCode());
        jv.getAccountingDocumentTypeCode().setValue("00047");
        
        
        //get doc item
        ArrayList<Hashtable<String, String>> list_items = get_journal_doc_items(ht.get("doc_id"));
        
        for(int i = 0 ; i < list_items.size(); i++)
        {   
            Hashtable<String, String> ht_item = list_items.get(i);
            JournalEntryCreateRequestBundleItem it = new JournalEntryCreateRequestBundleItem();
            it.setGeneralLedgerAccountAliasCode(new GeneralLedgerAccountAliasCode());
            it.getGeneralLedgerAccountAliasCode().setValue(ht_item.get("general_ledger_account_alias_code"));
            it.setBusinessTransactionCurrencyAmount(new Amount());
            it.getBusinessTransactionCurrencyAmount().setValue(BigDecimal.valueOf(Double.parseDouble(ht_item.get("amount"))));
            it.getBusinessTransactionCurrencyAmount().setCurrencyCode(ht_item.get("currency_code"));
            it.setNote(ht_item.get("note"));
            
            
            if(!ht_item.get("cost_center_id").equals("") || !ht_item.get("profit_center_id").equals(""))
            {
                it.setAccountingCodingBlock(new JournalEntryItemAccountingCodingBlock());
                
                if(!ht_item.get("cost_center_id").equals(""))
                    it.getAccountingCodingBlock().setCostCentreID(ht_item.get("cost_center_id"));
                
                if(!ht_item.get("profit_center_id").equals(""))
                    it.getAccountingCodingBlock().setCostCentreID(ht_item.get("profit_center_id"));
            }
            
            jv.getItem().add(it);
        }
        
        
        
        return request;
    }
    
    
    
     private  JournalEntryCreateConfirmationBundleMessage interfaceSAP(JournalEntryCreateRequestBundleMessage request) throws StandardFaultMessage_Exception {
        com.ntz.byd.gateway.managejournalentry.autogen.Service service = new com.ntz.byd.gateway.managejournalentry.autogen.Service();
        com.ntz.byd.gateway.managejournalentry.autogen.ManageJournalEntryIn port = service.getBinding();       
        BindingProvider provider = (BindingProvider) port;
        provider.getRequestContext().put(BindingProvider.USERNAME_PROPERTY, this._systemht.get("system_ws_username"));
        provider.getRequestContext().put(BindingProvider.PASSWORD_PROPERTY, this._systemht.get("system_ws_password"));
        provider.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, this._systemht.get("system_url").toString() + this._systemht.get("service_url_path").toString());
        return port.createBundle(request);
    }
     
     
     
     
     
     //===================================================
    private void send_error_doc_to_external_system() throws Exception {
       if(this._systemht.get("callback_url").equals(""))
       {
           return;
       }
       
       String sql = "select * from t_journal_entry where system_id = ? AND external_interface_status IN ('W','E')";
       MySQLDB db = new MySQLDB();
       db.connect();
       db.createPrepareStatement(sql);
       db.bindValue(1, (String) this._systemht.get("system_id"));
       
       ResultSet res = db.executeQuery();
       
       ArrayList doc_list = db.buildList(res);
       
       db.disconnect();
       
       
       if(doc_list.size() == 0) return;
       
       
       ArrayList list_json = new ArrayList();
       for(int i = 0 ; i < doc_list.size() ; i++)
       {
           Hashtable doc_ht = (Hashtable) doc_list.get(i);
           Hashtable ht_json = new Hashtable();
           ht_json.put("company_id", doc_ht.get("company_id"));
           ht_json.put("original_entry_document_reference_id", doc_ht.get("original_entry_document_reference_id"));
           ht_json.put("original_entry_document_reference_business_system_id", doc_ht.get("original_entry_document_reference_business_system_id"));
           ht_json.put("accounting_business_transaction_date", doc_ht.get("accounting_business_transaction_date"));
           ht_json.put("sap_error_msg", doc_ht.get("sap_interface_error_msg"));
           ht_json.put("external_reference_text", doc_ht.get("external_reference_text"));
           ht_json.put("items", get_error_item_list((String) doc_ht.get("doc_id")));
           
           list_json.add(ht_json);
       }
       
       Gson gson = new Gson();
       String dataSent = gson.toJson(list_json);
       System.out.println(dataSent);

       String[] ret =  ExternalRestCaller.call((String) this._systemht.get("callback_url"), (String)this._systemht.get("callback_apikey"),(String) this._systemht.get("callback_username"), (String)this._systemht.get("callback_password"), ExternalRestCaller.METHOD_POST, dataSent);


       if(ret[0].equals("200")) //OK
       {
            update_external_callback_status(doc_list,"S");
       }
       else
       {
           update_external_callback_status(doc_list,"E");
       }
           
       
       
       

    }

    private ArrayList get_error_item_list(String doc_id) throws Exception {
        String sql = "select general_ledger_account_alias_code,amount,currency_code,note,cost_center_id,profit_center_id from t_journal_entry_item where doc_id = ?";
        MySQLDB db = new MySQLDB();
        db.connect();
        db.createPrepareStatement(sql);
        db.bindValue(1, doc_id);
        ResultSet res = db.executeQuery();
        
        ArrayList list = db.buildList(res);
        
        db.disconnect();
        
        return list;
    }

    private void update_external_callback_status(ArrayList doc_list, String status) throws Exception {
        MySQLDB db = new MySQLDB();
        db.connect();
        String sql = "UPDATE t_journal_entry set external_interface_status = ? , external_interface_datetime = NOW() where doc_id =  ? ";
        db.createPrepareStatement(sql);
        db.bindValue(1, status);
        for(int i = 0 ; i < doc_list.size(); i++)
        {
            Hashtable<String, String> ht = (Hashtable<String, String>) doc_list.get(i);       
            db.bindValue(2, ht.get("doc_id"));
            db.executeUpdate();
        }
        db.disconnect();
    }
}
