
package com.ntz.byd.gateway.managejournalentry.autogen;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.CollapsedStringAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;


/**
 * <p>Java class for FinancialAccountingViewOfCostObjectKey complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="FinancialAccountingViewOfCostObjectKey">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="CostObjectTypeCode" type="{http://sap.com/xi/AP/Common/GDT}CostObjectTypeCode"/>
 *         &lt;element name="CostObjectID" type="{http://sap.com/xi/AP/Common/GDT}FinancialAccountingViewOfCostObjectID"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FinancialAccountingViewOfCostObjectKey", namespace = "http://sap.com/xi/AP/Common/Global", propOrder = {
    "costObjectTypeCode",
    "costObjectID"
})
public class FinancialAccountingViewOfCostObjectKey {

    @XmlElement(name = "CostObjectTypeCode", required = true)
    protected CostObjectTypeCode costObjectTypeCode;
    @XmlElement(name = "CostObjectID", required = true)
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String costObjectID;

    /**
     * Gets the value of the costObjectTypeCode property.
     * 
     * @return
     *     possible object is
     *     {@link CostObjectTypeCode }
     *     
     */
    public CostObjectTypeCode getCostObjectTypeCode() {
        return costObjectTypeCode;
    }

    /**
     * Sets the value of the costObjectTypeCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link CostObjectTypeCode }
     *     
     */
    public void setCostObjectTypeCode(CostObjectTypeCode value) {
        this.costObjectTypeCode = value;
    }

    /**
     * Gets the value of the costObjectID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCostObjectID() {
        return costObjectID;
    }

    /**
     * Sets the value of the costObjectID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCostObjectID(String value) {
        this.costObjectID = value;
    }

}
