
package com.ntz.byd.gateway.managejournalentry.autogen;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.CollapsedStringAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for JournalEntryCreateRequestBundleDebtorItem complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="JournalEntryCreateRequestBundleDebtorItem">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ObjectNodeSenderTechnicalID" type="{http://sap.com/xi/AP/Common/GDT}ObjectNodePartyTechnicalID" minOccurs="0"/>
 *         &lt;element name="OriginalEntryDocumentItemReferenceItemID" type="{http://sap.com/xi/Common/DataTypes}BusinessTransactionDocumentItemID" minOccurs="0"/>
 *         &lt;element name="BusinessPartnerInternalID" type="{http://sap.com/xi/Common/DataTypes}BusinessPartnerInternalID"/>
 *         &lt;element name="CashDiscountTerms" type="{http://sap.com/xi/AP/Common/GDT}JournalEntryItemCashDiscountTerms" minOccurs="0"/>
 *         &lt;element name="FullPaymentEndDate" type="{http://sap.com/xi/AP/Common/GDT}Date" minOccurs="0"/>
 *         &lt;element name="AccountsReceivableDueItemTypeCode" type="{http://sap.com/xi/AP/Common/GDT}AccountsReceivableDueItemTypeCode" minOccurs="0"/>
 *         &lt;element name="PaymentControl" type="{http://sap.com/xi/AP/Common/GDT}JournalEntryItemPaymentControl" minOccurs="0"/>
 *         &lt;element name="Note" type="{http://sap.com/xi/AP/Common/GDT}LANGUAGEINDEPENDENT_SHORT_Note" minOccurs="0"/>
 *         &lt;element name="BusinessTransactionCurrencyAmount" type="{http://sap.com/xi/AP/Common/GDT}Amount"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "JournalEntryCreateRequestBundleDebtorItem", namespace = "http://sap.com/xi/A1S/Global", propOrder = {
    "objectNodeSenderTechnicalID",
    "originalEntryDocumentItemReferenceItemID",
    "businessPartnerInternalID",
    "cashDiscountTerms",
    "fullPaymentEndDate",
    "accountsReceivableDueItemTypeCode",
    "paymentControl",
    "note",
    "businessTransactionCurrencyAmount"
})
public class JournalEntryCreateRequestBundleDebtorItem {

    @XmlElement(name = "ObjectNodeSenderTechnicalID")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String objectNodeSenderTechnicalID;
    @XmlElement(name = "OriginalEntryDocumentItemReferenceItemID")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String originalEntryDocumentItemReferenceItemID;
    @XmlElement(name = "BusinessPartnerInternalID", required = true)
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String businessPartnerInternalID;
    @XmlElement(name = "CashDiscountTerms")
    protected JournalEntryItemCashDiscountTerms cashDiscountTerms;
    @XmlElement(name = "FullPaymentEndDate")
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar fullPaymentEndDate;
    @XmlElement(name = "AccountsReceivableDueItemTypeCode")
    protected AccountsReceivableDueItemTypeCode accountsReceivableDueItemTypeCode;
    @XmlElement(name = "PaymentControl")
    protected JournalEntryItemPaymentControl paymentControl;
    @XmlElement(name = "Note")
    protected String note;
    @XmlElement(name = "BusinessTransactionCurrencyAmount", required = true)
    protected Amount businessTransactionCurrencyAmount;

    /**
     * Gets the value of the objectNodeSenderTechnicalID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getObjectNodeSenderTechnicalID() {
        return objectNodeSenderTechnicalID;
    }

    /**
     * Sets the value of the objectNodeSenderTechnicalID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setObjectNodeSenderTechnicalID(String value) {
        this.objectNodeSenderTechnicalID = value;
    }

    /**
     * Gets the value of the originalEntryDocumentItemReferenceItemID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOriginalEntryDocumentItemReferenceItemID() {
        return originalEntryDocumentItemReferenceItemID;
    }

    /**
     * Sets the value of the originalEntryDocumentItemReferenceItemID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOriginalEntryDocumentItemReferenceItemID(String value) {
        this.originalEntryDocumentItemReferenceItemID = value;
    }

    /**
     * Gets the value of the businessPartnerInternalID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBusinessPartnerInternalID() {
        return businessPartnerInternalID;
    }

    /**
     * Sets the value of the businessPartnerInternalID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBusinessPartnerInternalID(String value) {
        this.businessPartnerInternalID = value;
    }

    /**
     * Gets the value of the cashDiscountTerms property.
     * 
     * @return
     *     possible object is
     *     {@link JournalEntryItemCashDiscountTerms }
     *     
     */
    public JournalEntryItemCashDiscountTerms getCashDiscountTerms() {
        return cashDiscountTerms;
    }

    /**
     * Sets the value of the cashDiscountTerms property.
     * 
     * @param value
     *     allowed object is
     *     {@link JournalEntryItemCashDiscountTerms }
     *     
     */
    public void setCashDiscountTerms(JournalEntryItemCashDiscountTerms value) {
        this.cashDiscountTerms = value;
    }

    /**
     * Gets the value of the fullPaymentEndDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getFullPaymentEndDate() {
        return fullPaymentEndDate;
    }

    /**
     * Sets the value of the fullPaymentEndDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setFullPaymentEndDate(XMLGregorianCalendar value) {
        this.fullPaymentEndDate = value;
    }

    /**
     * Gets the value of the accountsReceivableDueItemTypeCode property.
     * 
     * @return
     *     possible object is
     *     {@link AccountsReceivableDueItemTypeCode }
     *     
     */
    public AccountsReceivableDueItemTypeCode getAccountsReceivableDueItemTypeCode() {
        return accountsReceivableDueItemTypeCode;
    }

    /**
     * Sets the value of the accountsReceivableDueItemTypeCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link AccountsReceivableDueItemTypeCode }
     *     
     */
    public void setAccountsReceivableDueItemTypeCode(AccountsReceivableDueItemTypeCode value) {
        this.accountsReceivableDueItemTypeCode = value;
    }

    /**
     * Gets the value of the paymentControl property.
     * 
     * @return
     *     possible object is
     *     {@link JournalEntryItemPaymentControl }
     *     
     */
    public JournalEntryItemPaymentControl getPaymentControl() {
        return paymentControl;
    }

    /**
     * Sets the value of the paymentControl property.
     * 
     * @param value
     *     allowed object is
     *     {@link JournalEntryItemPaymentControl }
     *     
     */
    public void setPaymentControl(JournalEntryItemPaymentControl value) {
        this.paymentControl = value;
    }

    /**
     * Gets the value of the note property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNote() {
        return note;
    }

    /**
     * Sets the value of the note property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNote(String value) {
        this.note = value;
    }

    /**
     * Gets the value of the businessTransactionCurrencyAmount property.
     * 
     * @return
     *     possible object is
     *     {@link Amount }
     *     
     */
    public Amount getBusinessTransactionCurrencyAmount() {
        return businessTransactionCurrencyAmount;
    }

    /**
     * Sets the value of the businessTransactionCurrencyAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link Amount }
     *     
     */
    public void setBusinessTransactionCurrencyAmount(Amount value) {
        this.businessTransactionCurrencyAmount = value;
    }

}
