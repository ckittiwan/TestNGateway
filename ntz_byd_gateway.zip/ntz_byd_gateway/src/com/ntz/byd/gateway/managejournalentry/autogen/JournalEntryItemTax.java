
package com.ntz.byd.gateway.managejournalentry.autogen;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.CollapsedStringAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;


/**
 * <p>Java class for JournalEntryItemTax complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="JournalEntryItemTax">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="TaxCountryCode" type="{http://sap.com/xi/AP/Common/GDT}CountryCode" minOccurs="0"/>
 *         &lt;element name="ProductTaxationCharacteristicsCode" type="{http://sap.com/xi/AP/Common/GDT}ProductTaxationCharacteristicsCode"/>
 *         &lt;element name="DeferredIndicator" type="{http://sap.com/xi/AP/Common/GDT}Indicator" minOccurs="0"/>
 *         &lt;element name="TaxJurisdictionCode" type="{http://sap.com/xi/Common/DataTypes}TaxJurisdictionCode" minOccurs="0"/>
 *         &lt;element name="TaxRegionCode" type="{http://sap.com/xi/AP/Common/GDT}RegionCode" minOccurs="0"/>
 *         &lt;element name="ProductTaxStandardClassificationSystemCode" type="{http://sap.com/xi/AP/Common/GDT}ProductTaxStandardClassificationSystemCode" minOccurs="0"/>
 *         &lt;element name="ProductTaxStandardClassificationCode" type="{http://sap.com/xi/AP/Common/GDT}ProductTaxStandardClassificationCode" minOccurs="0"/>
 *         &lt;element name="TaxReportingUnitID" type="{http://sap.com/xi/AP/Common/GDT}OrganisationalCentreID" minOccurs="0"/>
 *         &lt;element name="TaxItemGroupID" type="{http://sap.com/xi/AP/Common/GDT}BusinessTransactionDocumentItemGroupID" minOccurs="0"/>
 *         &lt;element name="BusinessTransactionCurrencyNonDeductibleAmount" type="{http://sap.com/xi/AP/Common/GDT}Amount" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "JournalEntryItemTax", propOrder = {
    "taxCountryCode",
    "productTaxationCharacteristicsCode",
    "deferredIndicator",
    "taxJurisdictionCode",
    "taxRegionCode",
    "productTaxStandardClassificationSystemCode",
    "productTaxStandardClassificationCode",
    "taxReportingUnitID",
    "taxItemGroupID",
    "businessTransactionCurrencyNonDeductibleAmount"
})
public class JournalEntryItemTax {

    @XmlElement(name = "TaxCountryCode")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String taxCountryCode;
    @XmlElement(name = "ProductTaxationCharacteristicsCode", required = true)
    protected ProductTaxationCharacteristicsCode productTaxationCharacteristicsCode;
    @XmlElement(name = "DeferredIndicator")
    protected Boolean deferredIndicator;
    @XmlElement(name = "TaxJurisdictionCode")
    protected TaxJurisdictionCode taxJurisdictionCode;
    @XmlElement(name = "TaxRegionCode")
    protected RegionCode2 taxRegionCode;
    @XmlElement(name = "ProductTaxStandardClassificationSystemCode")
    protected ProductTaxStandardClassificationSystemCode productTaxStandardClassificationSystemCode;
    @XmlElement(name = "ProductTaxStandardClassificationCode")
    protected ProductTaxStandardClassificationCode productTaxStandardClassificationCode;
    @XmlElement(name = "TaxReportingUnitID")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String taxReportingUnitID;
    @XmlElement(name = "TaxItemGroupID")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String taxItemGroupID;
    @XmlElement(name = "BusinessTransactionCurrencyNonDeductibleAmount")
    protected Amount businessTransactionCurrencyNonDeductibleAmount;

    /**
     * Gets the value of the taxCountryCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTaxCountryCode() {
        return taxCountryCode;
    }

    /**
     * Sets the value of the taxCountryCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTaxCountryCode(String value) {
        this.taxCountryCode = value;
    }

    /**
     * Gets the value of the productTaxationCharacteristicsCode property.
     * 
     * @return
     *     possible object is
     *     {@link ProductTaxationCharacteristicsCode }
     *     
     */
    public ProductTaxationCharacteristicsCode getProductTaxationCharacteristicsCode() {
        return productTaxationCharacteristicsCode;
    }

    /**
     * Sets the value of the productTaxationCharacteristicsCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link ProductTaxationCharacteristicsCode }
     *     
     */
    public void setProductTaxationCharacteristicsCode(ProductTaxationCharacteristicsCode value) {
        this.productTaxationCharacteristicsCode = value;
    }

    /**
     * Gets the value of the deferredIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isDeferredIndicator() {
        return deferredIndicator;
    }

    /**
     * Sets the value of the deferredIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setDeferredIndicator(Boolean value) {
        this.deferredIndicator = value;
    }

    /**
     * Gets the value of the taxJurisdictionCode property.
     * 
     * @return
     *     possible object is
     *     {@link TaxJurisdictionCode }
     *     
     */
    public TaxJurisdictionCode getTaxJurisdictionCode() {
        return taxJurisdictionCode;
    }

    /**
     * Sets the value of the taxJurisdictionCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link TaxJurisdictionCode }
     *     
     */
    public void setTaxJurisdictionCode(TaxJurisdictionCode value) {
        this.taxJurisdictionCode = value;
    }

    /**
     * Gets the value of the taxRegionCode property.
     * 
     * @return
     *     possible object is
     *     {@link RegionCode2 }
     *     
     */
    public RegionCode2 getTaxRegionCode() {
        return taxRegionCode;
    }

    /**
     * Sets the value of the taxRegionCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link RegionCode2 }
     *     
     */
    public void setTaxRegionCode(RegionCode2 value) {
        this.taxRegionCode = value;
    }

    /**
     * Gets the value of the productTaxStandardClassificationSystemCode property.
     * 
     * @return
     *     possible object is
     *     {@link ProductTaxStandardClassificationSystemCode }
     *     
     */
    public ProductTaxStandardClassificationSystemCode getProductTaxStandardClassificationSystemCode() {
        return productTaxStandardClassificationSystemCode;
    }

    /**
     * Sets the value of the productTaxStandardClassificationSystemCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link ProductTaxStandardClassificationSystemCode }
     *     
     */
    public void setProductTaxStandardClassificationSystemCode(ProductTaxStandardClassificationSystemCode value) {
        this.productTaxStandardClassificationSystemCode = value;
    }

    /**
     * Gets the value of the productTaxStandardClassificationCode property.
     * 
     * @return
     *     possible object is
     *     {@link ProductTaxStandardClassificationCode }
     *     
     */
    public ProductTaxStandardClassificationCode getProductTaxStandardClassificationCode() {
        return productTaxStandardClassificationCode;
    }

    /**
     * Sets the value of the productTaxStandardClassificationCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link ProductTaxStandardClassificationCode }
     *     
     */
    public void setProductTaxStandardClassificationCode(ProductTaxStandardClassificationCode value) {
        this.productTaxStandardClassificationCode = value;
    }

    /**
     * Gets the value of the taxReportingUnitID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTaxReportingUnitID() {
        return taxReportingUnitID;
    }

    /**
     * Sets the value of the taxReportingUnitID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTaxReportingUnitID(String value) {
        this.taxReportingUnitID = value;
    }

    /**
     * Gets the value of the taxItemGroupID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTaxItemGroupID() {
        return taxItemGroupID;
    }

    /**
     * Sets the value of the taxItemGroupID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTaxItemGroupID(String value) {
        this.taxItemGroupID = value;
    }

    /**
     * Gets the value of the businessTransactionCurrencyNonDeductibleAmount property.
     * 
     * @return
     *     possible object is
     *     {@link Amount }
     *     
     */
    public Amount getBusinessTransactionCurrencyNonDeductibleAmount() {
        return businessTransactionCurrencyNonDeductibleAmount;
    }

    /**
     * Sets the value of the businessTransactionCurrencyNonDeductibleAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link Amount }
     *     
     */
    public void setBusinessTransactionCurrencyNonDeductibleAmount(Amount value) {
        this.businessTransactionCurrencyNonDeductibleAmount = value;
    }

}
