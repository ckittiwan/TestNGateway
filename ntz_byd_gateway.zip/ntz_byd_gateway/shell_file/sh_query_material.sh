cd /home/tdi_infra/Desktop/java
java -jar NTZ_BYD_GATEWAY_BG.jar QUERY_MATERIAL > Logs/query_material/log.$(date +"%Y%m%d_%H%M%S").txt
