find /home/tdi_infra/Desktop/java/Logs/manage_od_in/ -type f -name '*.txt' -mtime +1 -exec rm {} \;
find /home/tdi_infra/Desktop/java/Logs/manage_site_logistic_task/ -type f -name '*.txt' -mtime +1 -exec rm {} \;
find /home/tdi_infra/Desktop/java/Logs/manage_site_logistic_task_callback/ -type f -name '*.txt' -mtime +1 -exec rm {} \;
find /home/tdi_infra/Desktop/java/Logs/query_account/ -type f -name '*.txt' -mtime +1 -exec rm {} \;
find /home/tdi_infra/Desktop/java/Logs/query_material/ -type f -name '*.txt' -mtime +1 -exec rm {} \;
find /home/tdi_infra/Desktop/java/Logs/query_outbound_delivery/ -type f -name '*.txt' -mtime +1 -exec rm {} \;
find /home/tdi_infra/Desktop/java/Logs/query_site_logistic_task/ -type f -name '*.txt' -mtime +1 -exec rm {} \;
find /home/tdi_infra/Desktop/java/Logs/manage_exchange_rate/ -type f -name '*.txt' -mtime +1 -exec rm {} \;


find /home/tdi_infra/Desktop/stockcount/trandar/test/Logs/ -type f -name '*.txt' -mtime +1 -exec rm {} \;
find /home/tdi_infra/Desktop/stockcount/trandar/prd/Logs/ -type f -name '*.txt' -mtime +1 -exec rm {} \;

find /home/tdi_infra/Desktop/stockcount/thaikk/test/Logs/ -type f -name '*.txt' -mtime +1 -exec rm {} \;
find /home/tdi_infra/Desktop/stockcount/thaikk/prd/Logs/ -type f -name '*.txt' -mtime +1 -exec rm {} \;