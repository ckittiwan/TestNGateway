cd /home/tdi_infra/Desktop/java
java -jar NTZ_BYD_GATEWAY_BG.jar MANAGE_OD_IN > Logs/manage_od_in/log.$(date +"%Y%m%d_%H%M%S").txt
