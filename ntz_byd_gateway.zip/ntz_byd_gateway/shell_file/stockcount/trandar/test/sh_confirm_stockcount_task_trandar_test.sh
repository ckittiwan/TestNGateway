cd /home/tdi_infra/Desktop/stockcount/trandar/test
java -jar NTZ_MCS_STOCKCOUNT.jar CONFIRM_STOCK_COUNT_TASK > Logs/confirm.log.$(date +"%Y%m%d_%H%M%S").txt
