cd /home/tdi_infra/Desktop/stockcount/thaikk/test
java -jar NTZ_MCS_STOCKCOUNT.jar QUERY_STOCK_COUNT_TASK > Logs/query.log.$(date +"%Y%m%d_%H%M%S").txt
