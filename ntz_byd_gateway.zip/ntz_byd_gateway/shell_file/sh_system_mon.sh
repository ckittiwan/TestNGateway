cd /home/tdi_infra/Desktop/java
java -jar NTZ_BYD_GATEWAY_BG.jar SYSTEM_MON