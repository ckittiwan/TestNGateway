cd /home/tdi_infra/Desktop/java
java -jar NTZ_BYD_GATEWAY_BG.jar QUERY_OUTBOUND_DELIVERY > Logs/query_outbound_delivery/log.$(date +"%Y%m%d_%H%M%S").txt
