cd /home/tdi_infra/Desktop/java
java -jar NTZ_BYD_GATEWAY_BG.jar MANAGE_SITE_LOGISTICS_TASK > Logs/manage_site_logistic_task/log.$(date +"%Y%m%d_%H%M%S").txt
