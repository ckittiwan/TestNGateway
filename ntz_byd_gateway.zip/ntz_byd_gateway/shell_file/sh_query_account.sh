cd /home/tdi_infra/Desktop/java
java -jar NTZ_BYD_GATEWAY_BG.jar QUERY_ACCOUNT > Logs/query_account/log.$(date +"%Y%m%d_%H%M%S").txt
